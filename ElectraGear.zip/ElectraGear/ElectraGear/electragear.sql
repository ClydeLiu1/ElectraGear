/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80300 (8.3.0)
 Source Host           : localhost:3306
 Source Schema         : untitled

 Target Server Type    : MySQL
 Target Server Version : 80300 (8.3.0)
 File Encoding         : 65001

 Date: 22/05/2024 21:32:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins`  (
  `admin_id` int NOT NULL,
  `admin_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `admin_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `admin_phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`admin_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES (1, 'admin', '123@qq.com', NULL, 'e10adc3949ba59abbe56e057f20f883e');

-- ----------------------------
-- Table structure for contact
-- ----------------------------
DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact`  (
  `contact_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `reply` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `reply_time` datetime NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`contact_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contact
-- ----------------------------
INSERT INTO `contact` VALUES (1, '111', '11', '1', '1233', '2024-05-21 16:21:54', '2024-05-22 13:01:09', 1, NULL);
INSERT INTO `contact` VALUES (2, '11', '11', '11', NULL, '2024-05-21 16:23:51', NULL, 1, NULL);
INSERT INTO `contact` VALUES (3, '12', '12', '12', NULL, '2024-05-21 16:24:36', NULL, 1, NULL);

-- ----------------------------
-- Table structure for invoices
-- ----------------------------
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices`  (
  `invoice_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `order_id` int NULL DEFAULT NULL,
  `invoice_content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL,
  `invoice_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`invoice_id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of invoices
-- ----------------------------
INSERT INTO `invoices` VALUES (5, 1, 10, 'alibaba', '2024-05-21');

-- ----------------------------
-- Table structure for order_product
-- ----------------------------
DROP TABLE IF EXISTS `order_product`;
CREATE TABLE `order_product`  (
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `num` int NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order_product
-- ----------------------------
INSERT INTO `order_product` VALUES (10, 4, '2024-05-15 15:00:35', 2);
INSERT INTO `order_product` VALUES (10, 7, '2024-05-15 15:00:35', 1);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `order_id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int NOT NULL COMMENT '用户ID',
  `order_date` date NULL DEFAULT NULL COMMENT '下单日期',
  `order_status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT '1' COMMENT '订单状态 1：已支付  2：已发货  3：已送达',
  `subtotal` decimal(10, 2) NULL DEFAULT NULL COMMENT '订单金额',
  `delivery_address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '邮寄地址',
  `payment_info_id` int NULL DEFAULT NULL COMMENT '支付方式',
  `free_shipping` tinyint(1) NULL DEFAULT NULL COMMENT '包邮 1：包邮  2：不包邮',
  `first_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`order_id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (10, 1, '2024-05-13', '3', 165.00, 'BeiJing', 6, 1, 'zhang', 'san', '18500741666', 'no');

-- ----------------------------
-- Table structure for payment_info
-- ----------------------------
DROP TABLE IF EXISTS `payment_info`;
CREATE TABLE `payment_info`  (
  `payment_info_id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int NULL DEFAULT NULL COMMENT '用户ID',
  `card_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '银行卡类型',
  `card_number` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '卡号',
  `expiration_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '过期日期',
  `security_code` varchar(4) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '安全码',
  PRIMARY KEY (`payment_info_id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `payment_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of payment_info
-- ----------------------------
INSERT INTO `payment_info` VALUES (6, 1, NULL, '1234123412341234', '2025/10', '1233');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products`  (
  `product_id` bigint NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `product_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `stock_quantity` int NULL DEFAULT NULL,
  `category` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '型号',
  `image_path` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `brand_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '品牌名称',
  PRIMARY KEY (`product_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES (1, 'Rear Seat Back Protector', 'Designed to fit the rear seatback of BYD Atto 3 Prevent damage to the back of your second-row seats Durable and Lightweight Flexi rubber (TPE) material Especially helpful when transporting large items or dirty cargo Non-slip textured surface 100% waterproof Attach to the seatback by velcro Easy to clean, simply wipe off the dirt and you are good to go', 18.50, -122, 'ATTO3', 'E:\\end\\untitled-end\\untitled\\image\\be7ed046-cc9f-48b8-aee3-c860b5139019.jpg', 'BYD');
INSERT INTO `products` VALUES (3, 'Mud Flaps', 'Our mud flaps are tailored to fit BYD ATTO 3 perfectly.\n\nProtect your BYD ATTO 3’s doors and rear quarter panels from road debris.\n\nDurable thermoplastic material holds up against weather, rocks, and debris. It creates a finished look for any colour BYD ATTO 3.', 14.92, -115, 'MG4', 'E:\\end\\untitled-end\\untitled\\image\\06a86be0-4e9e-4c83-9870-eeed5eae35d6.jpg', 'MG');
INSERT INTO `products` VALUES (4, 'Armrest Organiser Tray', 'Custom design Armrest Storage Tray for BYD Atto 3\nOrganise or store small items inside the armrest console\nDesigned to allow easy access to your keys, sunglasses, coins and any small items\nNo more messy storage', 10.00, 4, 'ATTO3', 'E:\\end\\untitled-end\\untitled\\image\\b180e1e8-79d9-4b95-86c5-d254bc48b411.jpg', 'BYD');
INSERT INTO `products` VALUES (5, '3D All-Weather Floor Mats', 'Perfectly moulded to fit the footwell of your Right-hand Drive BYD ATTO 3 for maximum protection against dirt, liquid, spills, snow and more.\n\nThe bucket design ensures everything remains within the floor mats.\n\n3D All-Weather Rubber Floor Mats\nDurable and Lightweight\nFlexi rubber (TPE) material\nNon-slip textured surface\nAll-weather raised edge bucket design\n100% waterproof\nEasy to clean, simply hose off or wipe off the dirt and you are good to go', 95.00, 4, 'DOLPHIN', 'E:\\end\\untitled-end\\untitled\\image\\c9d7c67f-8070-4afe-aefc-a73117f4b3f0.jpg', 'BYD');
INSERT INTO `products` VALUES (6, '55', 'Made for BYD Key Fobs\n\nProtect and prevent wear from everyday use. Simply slide the jacket over your key fob for long lasting protection.', 1.95, 5, 'MODEL Y', 'E:\\end\\untitled-end\\untitled\\image\\9c2b1687-7741-4b59-b610-ac018a65f4d0.jpg', 'TESLA');
INSERT INTO `products` VALUES (7, 'Bundle', 'BYD Atto 3 – All-Weather Floor Mats\nBYD Atto 3 – Boot Liner\nBYD Atto 3 – Rear Seat Back Protector', 145.00, 3, 'ATTO3', 'E:\\end\\untitled-end\\untitled\\image\\dcdc5acf-51cf-44a9-9203-c829f62c4e7d.jpg', 'BYD');

-- ----------------------------
-- Table structure for shopping_cart
-- ----------------------------
DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE `shopping_cart`  (
  `cart_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `product_id` int NULL DEFAULT NULL,
  `quantity` int NULL DEFAULT NULL,
  PRIMARY KEY (`cart_id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `product_id`(`product_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of shopping_cart
-- ----------------------------
INSERT INTO `shopping_cart` VALUES (5, 1, 4, 2);
INSERT INTO `shopping_cart` VALUES (6, 1, 7, 1);
INSERT INTO `shopping_cart` VALUES (7, 1, 1, 1);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `is_member` tinyint(1) NULL DEFAULT NULL,
  `member_discount` decimal(5, 2) NULL DEFAULT NULL,
  `registration_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'test', 'e10adc3949ba59abbe56e057f20f883e', '123@qq.com', '18500741633', 'China', 1, NULL, '2024-04-27');
INSERT INTO `users` VALUES (3, 'test1', 'e10adc3949ba59abbe56e057f20f883e', '123@qq.com', '18500741666', NULL, NULL, NULL, '2024-05-02');

SET FOREIGN_KEY_CHECKS = 1;
