import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/login', component: () => import('@/views/login.vue') },
    { path: '/homePage', component: () => import('@/views/homepage.vue') },
    {
      path: '/',
      component: () => import('@/views/layout/LayoutContainer.vue'),
      redirect: '/user/userlist',
      children: [
        {
          path: '/products/list',
          component: () => import('@/views/products/index.vue')
        },
        {
          path: '/user/userlist',
          component: () => import('@/views/user/UserList.vue')
        },
        {
          path: '/orders/list',
          component: () => import('@/views/orders/index.vue')
        },
        {
          path: '/contact/list',
          component: () => import('@/views/contact/index.vue')
        }
      ]
    }
  ]
})

// Login access interception
router.beforeEach((to) => {
  // If there is no token and the page being visited is not a login page, intercept the login request. Otherwise, allow the request to proceed normally.
  const userStore = useUserStore()
  console.log("token", userStore.token)
  if (!userStore.token && to.path !== '/login') return 'login'
})
export default router
