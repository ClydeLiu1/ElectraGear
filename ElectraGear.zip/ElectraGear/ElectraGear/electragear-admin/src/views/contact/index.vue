<template>
  <div class="app-container">


    <el-table v-loading="loading" :data="contactList" @selection-change="handleSelectionChange">

      <el-table-column label="Phone" align="center" prop="phone" />
      <el-table-column label="Email" align="center" prop="email" />
      <el-table-column label="Message" align="center" prop="message" />
      <el-table-column label="Reply" align="center" prop="reply" />
      <el-table-column label="Create Time" align="center" prop="createTime" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Reply Time" align="center" prop="replyTime" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.replyTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Operation" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)">Reply</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />


    <el-dialog :title="title" v-model="open" width="700px" append-to-body>
      <el-form ref="contactRef" :model="form" :rules="rules" label-width="100px">
    
        <el-form-item label="Reply" prop="reply">
          <el-input v-model="form.reply" type="textarea" :rows="6" :cols="30"/>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Contact">
import { listContact, getContact, delContact, addContact, updateContact } from "@/api/contact";
import { ref,reactive, toRefs, getCurrentInstance, watch } from 'vue'
const { proxy } = getCurrentInstance();
const contactList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
        userId: null,    replyTime: null,    reply: null,    message: null,    phone: null,    email: null,  },
  rules: {
    reply: [
      { required: true, message: 'This field is required.', trigger: "blur" }
    ],  }
});

const { queryParams, form, rules } = toRefs(data);


function getList() {
  loading.value = true;
  listContact(queryParams.value).then(response => {
    contactList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}


function cancel() {
  open.value = false;
  reset();
}


function reset() {
  form.value = {
    userId: null,    replyTime: null,    createTime: null,    reply: null,    message: null,    phone: null,    email: null,    contactId: null  };
  resetForm("contactRef");
}
function resetForm(refName) {
  if (proxy.$refs[refName]) {
    proxy.$refs[refName].resetFields();
  }
}

function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}


function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}


function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.contactId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}


function handleAdd() {
  reset();
  open.value = true;
  title.value = "Add Contact Us";
}


function handleUpdate(row) {
  reset();
  const _contactId = row.contactId || ids.value
  getContact(_contactId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Reply";
  });
}


function submitForm() {
  proxy.$refs["contactRef"].validate(valid => {
    if (valid) {
      if (form.value.contactId != null) {
        updateContact(form.value).then(response => {
          ElMessage.success("Update successful");
          open.value = false;
          getList();
        });
      } else {
        addContact(form.value).then(response => {
          proxy.$modal.msgSuccess("added successfully");
          open.value = false;
          getList();
        });
      }
    }
  });
}


function handleDelete(row) {
  const _contactIds = row.contactId || ids.value;
  ElMessageBox.confirm('Do you want to delete this record?').then(function() {
    return delContact(_contactIds);
  }).then(() => {
    getList();
    ElMessage.success("Delete successful");
  }).catch(() => {});
}


function handleExport() {
  proxy.download('ty/contact/export', {
    ...queryParams.value
  }, `contact_${new Date().getTime()}.xlsx`)
}
function parseTime(time, pattern) {
  if (arguments.length === 0 || !time) {
    return null
  }
  time = new Date(time)
  const format = pattern || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if ((typeof time === 'string') && (/^[0-9]+$/.test(time))) {
      time = parseInt(time)
    } else if (typeof time === 'string') {
      time = time.replace(new RegExp(/-/gm), '/').replace('T', ' ').replace(new RegExp(/\.[\d]{3}/gm), '');
    }
    if ((typeof time === 'number') && (time.toString().length === 10)) {
      time = time * 1000
    }
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    // Note: getDay() returns 0 on Sunday
    if (key === 'a') { return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][value] }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return time_str
}
getList();
</script>
