<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="Security Code" prop="securityCode">
        <el-input
          v-model="queryParams.securityCode"
          placeholder="Enter Security Code"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="Expiration Date" prop="expirationDate">
        <el-date-picker clearable
                        v-model="queryParams.expirationDate"
                        type="date"
                        value-format="YYYY-MM-DD"
                        placeholder="Select Expiration Date">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="Card Number" prop="cardNumber">
        <el-input
          v-model="queryParams.cardNumber"
          placeholder="Enter Card Number"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="Card Type" prop="cardType">
        <el-select v-model="queryParams.cardType" placeholder="Select Card Type" clearable>
          <el-option label="Please Select" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="User ID" prop="userId">
        <el-input
          v-model="queryParams.userId"
          placeholder="Enter User ID"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">Search</el-button>
        <el-button icon="Refresh" @click="resetQuery">Reset</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['payment:info:add']"
        >Add</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['payment:info:edit']"
        >Edit</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['payment:info:remove']"
        >Delete</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['payment:info:export']"
        >Export</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="infoList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="Security Code" align="center" prop="securityCode" />
      <el-table-column label="Expiration Date" align="center" prop="expirationDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.expirationDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Card Number" align="center" prop="cardNumber" />
      <el-table-column label="Card Type" align="center" prop="cardType" />
      <el-table-column label="User ID" align="center" prop="userId" />
      <el-table-column label="Payment Info ID" align="center" prop="paymentInfoId" />
      <el-table-column label="Actions" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['payment:info:edit']">Edit</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['payment:info:remove']">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- Add or Edit Payment Method Dialog -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="infoRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="Security Code" prop="securityCode">
          <el-input v-model="form.securityCode" placeholder="Enter Security Code" />
        </el-form-item>
        <el-form-item label="Expiration Date" prop="expirationDate">
          <el-date-picker clearable
                          v-model="form.expirationDate"
                          type="date"
                          value-format="YYYY-MM-DD"
                          placeholder="Select Expiration Date">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="Card Number" prop="cardNumber">
          <el-input v-model="form.cardNumber" placeholder="Enter Card Number" />
        </el-form-item>
        <el-form-item label="Card Type" prop="cardType">
          <el-select v-model="form.cardType" placeholder="Select Card Type">
            <el-option label="Please Select" value="" />
          </el-select>
        </el-form-item>
        <el-form-item label="User ID" prop="userId">
          <el-input v-model="form.userId" placeholder="Enter User ID" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Info">
import { listInfo, getInfo, delInfo, addInfo, updateInfo } from "@/api/payment";
import { ref, reactive, toRefs, getCurrentInstance, watch } from 'vue'
const { proxy } = getCurrentInstance();

const infoList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    securityCode: null,
    expirationDate: null,
    cardNumber: null,
    cardType: null,
    userId: null,
  },
  rules: {}
});

const { queryParams, form, rules } = toRefs(data);

/** Get the list of payment methods */
function getList() {
  loading.value = true;
  listInfo(queryParams.value).then(response => {
    infoList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// Cancel button
function cancel() {
  open.value = false;
  reset();
}

// Reset form
function reset() {
  form.value = {
    securityCode: null,
    expirationDate: null,
    cardNumber: null,
    cardType: null,
    userId: null,
    paymentInfoId: null
  };
  proxy.resetForm("infoRef");
}

/** Search button operation */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** Reset button operation */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// Selected data in the checkbox
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.paymentInfoId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** Add button operation */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "Add Payment Method";
}

/** Edit button operation */
function handleUpdate(row) {
  reset();
  const _paymentInfoId = row.paymentInfoId || ids.value;
  getInfo(_paymentInfoId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Edit Payment Method";
  });
}

/** Submit button */
function submitForm() {
  proxy.$refs["infoRef"].validate(valid => {
    if (valid) {
      if (form.value.paymentInfoId != null) {
        updateInfo(form.value).then(response => {
          proxy.$modal.msgSuccess("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addInfo(form.value).then(response => {
          proxy.$modal.msgSuccess("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** Delete button operation */
function handleDelete(row) {
  const _paymentInfoIds = row.paymentInfoId || ids.value;
  proxy.$modal.confirm('Are you sure you want to delete the payment method with ID "' + _paymentInfoIds + '"?').then(function() {
    return delInfo(_paymentInfoIds);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("Delete successful");
  }).catch(() => {});
}

/** Export button operation */
function handleExport() {
  proxy.download('payment/info/export', {
    ...queryParams.value
  }, `info_${new Date().getTime()}.xlsx`)
}

getList();
</script>