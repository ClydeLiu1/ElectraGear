<template>
  <div class="app-container">

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
        >Add</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="productsList" @selection-change="handleSelectionChange">
      <el-table-column label="ProductName" align="center" prop="productName" />
      <el-table-column label="BrandName" align="center" prop="brandName" />
      <el-table-column label="SeriesName" align="center" prop="category" />
      <el-table-column label="Stock" align="center" prop="stockQuantity" />
      <el-table-column label="Price" align="center" prop="price" />
      <el-table-column label="Picture" align="center" prop="imagePath" >
        <template #default="scope">
          <img :src="getImageURL(scope.base64str)" width="80px" height="80px" />
        </template>
      </el-table-column>
      <el-table-column label="Description" align="center" prop="productDescription" />
      <el-table-column label="Operation" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['products:products:edit']">Modify</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['products:products:remove']">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />


    <el-dialog :title="title" v-model="open" width="750px" append-to-body  class="modalStyle">
      <el-form ref="productsRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="ProductName" prop="productName">
          <el-input v-model="form.productName"/>
        </el-form-item>
        <el-form-item label="BrandName" prop="brandName">
          <el-select v-model="form.brandName" placeholder="Options">
            <el-option
              v-for="item in brandNames"
              :key="item"
              :label="item"
              :value="item">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="SeriesName" prop="category">
          <el-select v-model="form.category" placeholder="Options">
            <el-option v-if="form.brandName == 'BYD'" key="ATTO3" label="ATTO3" value="ATTO3"></el-option>
            <el-option v-if="form.brandName == 'BYD'" key="DOLPHIN" label="DOLPHIN" value="DOLPHIN"></el-option>
            <el-option v-if="form.brandName == 'MG'" key="MG4" label="MG4" value="MG4"></el-option>
            <el-option v-if="form.brandName == 'MG'" key="MGZSEV" label="MGZSEV" value="MGZSEV"></el-option>
            <el-option v-if="form.brandName == 'KIA'" key="KIA" label="KIA" value="KIA"></el-option>
            <el-option v-if="form.brandName == 'TESLA'" key="MODEL Y" label="MODEL Y" value="MODEL Y"></el-option>
            <el-option v-if="form.brandName == 'TESLA'" key="MODEL 3" label="MODEL 3" value="MODEL 3"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Stock" prop="stockQuantity">
          <el-input v-model="form.stockQuantity"  />
        </el-form-item>
        <el-form-item label="Price" prop="price">
          <el-input v-model="form.price"  />
        </el-form-item>
        <el-form-item label="Picture" prop="imagePath">
          <el-upload v-model="form.imagePath" ref="addupload" name="file" :headers="upload.headers" :action="upload.url" accept=".jpg, .png, .jpeg"  :auto-upload="true" :on-exceed="handleExceed"
            :before-upload="beforeUpload" :on-success="handleSuccess" :on-error="handleUploadError" :before-remove="beforeRemove" :multiple="false" :limit="1" list-type="picture" :disabled="upload.open"
            :file-list="fileList">
            <el-col>
              <el-row>
                <el-button size="small" type="primary" @click="handleUpload">Upload</el-button>
              </el-row>
              <el-row>
                <span style="font-size:xx-small"> File format is：.jpg，.png，.jpeg</span>
              </el-row>
            </el-col>
          </el-upload>
           <img v-if="form.base64str != null && form.base64str.length > 0" :src="getImageURL(form.base64str)" width="80px" height="80px" />
        </el-form-item>
        <el-form-item label="Description" prop="productDescription">
          <el-input  type="textarea" :rows="5" v-model="form.productDescription" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Products">
import { listProducts, getProducts, delProducts, addProducts, updateProducts } from "@/api/products";
import { ref,reactive, toRefs, getCurrentInstance, watch } from 'vue'
const { proxy } = getCurrentInstance();
import { useUserStore } from '@/stores'
import request from "@/utils/request";

const userStore = useUserStore()
const productsList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");
const fileList = ref([])
const currentFile = ref()
const addupload = ref()
const brandNames = reactive(['BYD', 'MG', 'KIA', 'TESLA'])

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
        carCompatibility: null,    category: null,    stockQuantity: null,    price: null,    productDescription: null,    productName: null,  },
    rules: {
      productName: [
        { required: true, rigger: "blur" }
      ],
      stockQuantity: [
        { required: true, trigger: "blur" }
      ],
      price: [
        { required: true, trigger: "blur" }
      ],
      productDescription: [
        { required: true, trigger: "blur" }
      ],
    },
    upload: {

      open: true,

      title: '',

      headers: { Authorization: 'Bearer ' + userStore.token },

      url: request.defaults.baseURL + '/file/upload',
      fileName: '',
      fileId: ''
    }
});

const { queryParams, form, rules, upload } = toRefs(data);


function getList() {
  loading.value = true;
  listProducts(queryParams.value).then(response => {
    productsList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}


function cancel() {
  open.value = false;
  reset();
}


function reset() {
  form.value = {
    carCompatibility: null,    category: null,    stockQuantity: null,    price: null,    productDescription: null,    productName: null,    productId: null  };
  resetForm("productsRef");
}


function resetForm(refName) {
  if (proxy.$refs[refName]) {
    proxy.$refs[refName].resetFields();
  }
}


function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}


function resetQuery() {
  resetForm("queryRef");
  handleQuery();
}


function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.productId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}


function handleAdd() {
  fileList.value = []
  reset();
  open.value = true;
  title.value = "Add";
}


function handleUpdate(row) {
  fileList.value = []
  reset();
  const _productId = row.productId || ids.value
  getProducts(_productId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Modify";
  });
}


function submitForm() {
  proxy.$refs["productsRef"].validate(valid => {
    if (valid) {
      if (form.value.productId != null) {
        updateProducts(form.value).then(response => {
          ElMessage.success("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addProducts(form.value).then(response => {
          ElMessage.success("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}

function confirm(content) {
  return ElMessageBox.confirm(content, "Warm Prompt", {
    confirmButtonText: 'Confirm',
    cancelButtonText: 'Cancel',
    type: "warning",
  })
}


function handleDelete(row) {
  const _productIds = row.productId || ids.value;
  confirm('Do you want to delete this record?').then(function() {
    return delProducts(_productIds);
  }).then(() => {
    getList();
    ElMessage.success("Delete successful");
  }).catch(() => {});
}


function handleExport() {
  proxy.download('products/products/export', {
    ...queryParams.value
  }, `products_${new Date().getTime()}.xlsx`)
}

function handleExceed(files, fileList) {
  proxy.$modal.msgWarning(
    `Currently limited to 1 file selection, ${files.length} files selected this time, ${files.length + fileList.length
    } files selected in total`
  )
}

//delete
function beforeRemove(file) {
  if (file && file.status === 'success') {
    return ElMessageBox.confirm(`Confirm removal ${file.name}？`)

  }
}

function beforeUpload(file) {
  if (checkFileType(file.name, ['jpg', 'png', 'jpeg'])) {
    currentFile.value = file
    return true
  }
  ElMessageBox.error('File format error, please upload image')
  return false
}

function checkFileType(fileName, fileTypes) {
    if (fileName == undefined || fileName == '' || fileName == null) {
        return false
    }
    //Get the location of the file extension
    var index = fileName.lastIndexOf('.')
    if (index == -1) {
        return false
    }

    var isnext = false
    var type = fileName.substring(index + 1)
    if (fileTypes && fileTypes.length > 0) {
        for (let i = 0; i < fileTypes.length; i++) {
            if (type == fileTypes[i]) {
                isnext = true
                break
            }
        }
    }
    return isnext
}


function handleSuccess(response, file) {
  form.value.base64str = undefined
  console.log(response)
  let value = response.msg
  if (response.code === 200) {
    ElMessage.success('Upload successful')
    form.value.imagePath = value
  } else {
    ElMessage.error(value)
    // addupload?.value?.clearFiles()
  }
}


function handleUpload() {
  upload.value.open = false
}
// fail upload
function handleUploadError() {
  proxy.$modal.msgError({
    type: 'error',
    message: 'Please upload the file'
  })
  addupload?.value?.clearFiles()
}


function delOperationInstruction() {
  ElMessageBox.confirm('Do you want to delete this record??', 'warning', {
    confirmButtonText: 'Confirm',
    cancelButtonText: 'Cancel',
    type: 'warning'
  })
    .then(() => {
      form.value.operationInstructionUrl = undefined;
    })
    .catch(function () {
    })
}

function getImageURL(path) {
    return "data:image/jpeg;base64," + path
}
getList();
</script>
