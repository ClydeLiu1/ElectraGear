<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="Number of Products" prop="quantity">
        <el-input
          v-model="queryParams.quantity"
          placeholder="Please Enter Number of Products"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="ItemID" prop="productId">
        <el-input
          v-model="queryParams.productId"
          placeholder="Please Enter ItemID"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="UserID" prop="userId">
        <el-input
          v-model="queryParams.userId"
          placeholder="Please Enter UserID"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">Search</el-button>
        <el-button icon="Refresh" @click="resetQuery">Reset</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['ty:cart:add']"
        >ADD</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['ty:cart:edit']"
        >Change</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['ty:cart:remove']"
        >Delete</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['ty:cart:export']"
        >Export</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="cartList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="Number of Products" align="center" prop="quantity" />
      <el-table-column label="ItemID" align="center" prop="productId" />
      <el-table-column label="UserID" align="center" prop="userId" />
      <el-table-column label="MainKey" align="center" prop="cartId" />
      <el-table-column label="Operate" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['ty:cart:edit']">Change</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['ty:cart:remove']">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />


    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="cartRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="Number of Products" prop="quantity">
          <el-input v-model="form.quantity" placeholder="Please Enter Number of Products" />
        </el-form-item>
        <el-form-item label="ItemID" prop="productId">
          <el-input v-model="form.productId" placeholder="Please Enter ItemID" />
        </el-form-item>
        <el-form-item label="UserID" prop="userId">
          <el-input v-model="form.userId" placeholder="Please Enter UserID" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Cart">
import { listCart, getCart, delCart, addCart, updateCart } from "@/api/ty/cart";

const { proxy } = getCurrentInstance();
const { ${dictsNoSymbol} } = proxy.useDict(${dicts});

const cartList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
        quantity: null,    productId: null,    userId: null,  },
  rules: {
      }
});

const { queryParams, form, rules } = toRefs(data);


function getList() {
  loading.value = true;
  listCart(queryParams.value).then(response => {
    cartList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// cancel button
function cancel() {
  open.value = false;
  reset();
}

// Form Reset
function reset() {
  form.value = {
    quantity: null,    productId: null,    userId: null,    cartId: null  };
  proxy.resetForm("cartRef");
}

/** Search button operation */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}
/** Reset button operation */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

//Multiple selection box selects data
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.cartId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}


function handleAdd() {
  reset();
  open.value = true;
  title.value = "Add shopping cart management";
}

/** Modify button operation */
function handleUpdate(row) {
  reset();
  const _cartId = row.cartId || ids.value
  getCart(_cartId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Modify shopping cart management";
  });
}


function submitForm() {
  proxy.$refs["cartRef"].validate(valid => {
    if (valid) {
      if (form.value.cartId != null) {
        updateCart(form.value).then(response => {
          proxy.$modal.msgSuccess("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addCart(form.value).then(response => {
          proxy.$modal.msgSuccess("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}
/** Delete button operation **/
function handleDelete(row) {
  const _cartIds = row.cartId || ids.value;
  proxy.$modal.confirm('Are you sure to delete the shopping cart management number"' + _cartIds + '"data？').then(function() {
    return delCart(_cartIds);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("Delete successful");
  }).catch(() => {});
}

/** Export button action */
function handleExport() {
  proxy.download('ty/cart/export', {
    ...queryParams.value
  }, `cart_${new Date().getTime()}.xlsx`)
}

getList();
</script>
