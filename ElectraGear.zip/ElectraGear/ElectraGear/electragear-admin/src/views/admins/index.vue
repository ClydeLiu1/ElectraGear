<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="User Name" prop="adminName">
        <el-input
          v-model="queryParams.adminName"
          placeholder="Enter User Name"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="Email" prop="adminEmail">
        <el-input
          v-model="queryParams.adminEmail"
          placeholder="Enter Your Email"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="Phone Number" prop="adminPhone">
        <el-input
          v-model="queryParams.adminPhone"
          placeholder="Please Enter Phone Number"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">Search</el-button>
        <el-button icon="Refresh" @click="resetQuery">Reload</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['ty:admins:add']"
        >ADD</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['ty:admins:edit']"
        >Change</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['ty:admins:remove']"
        >Delete</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['ty:admins:export']"
        >Export</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="adminsList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="MainKey" align="center" prop="adminId" />
      <el-table-column label="User Name" align="center" prop="adminName" />
      <el-table-column label="Email" align="center" prop="adminEmail" />
      <el-table-column label="Phone Number" align="center" prop="adminPhone" />
      <el-table-column label="Operate" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['ty:admins:edit']">Change</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['ty:admins:remove']">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- Add or modify administrator information management dialog box -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="adminsRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="User Name" prop="adminName">
          <el-input v-model="form.adminName" placeholder="please enter user name" />
        </el-form-item>
        <el-form-item label="Email" prop="adminEmail">
          <el-input v-model="form.adminEmail" placeholder="please input your email" />
        </el-form-item>
        <el-form-item label="Phone Number" prop="adminPhone">
          <el-input v-model="form.adminPhone" placeholder="Please enter phone number" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">confirm</el-button>
          <el-button @click="cancel">cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Admins">
import { listAdmins, getAdmins, delAdmins, addAdmins, updateAdmins } from "@/api/ty/admins";

const { proxy } = getCurrentInstance();
const { ${dictsNoSymbol} } = proxy.useDict(${dicts});

const adminsList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
        adminName: null,    adminEmail: null,    adminPhone: null  },
  rules: {
      }
});

const { queryParams, form, rules } = toRefs(data);


function getList() {
  loading.value = true;
  listAdmins(queryParams.value).then(response => {
    adminsList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// cancel button
function cancel() {
  open.value = false;
  reset();
}

// Reset the form
function reset() {
  form.value = {
    adminId: null,    adminName: null,    adminEmail: null,    adminPhone: null  };
  proxy.resetForm("adminsRef");
}
/** Search button operation */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** reset button operation */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

//Multiple selection box selects data
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.adminId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** Add button operation */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "Add administrator information management";
}
/** Modify button operation */
function handleUpdate(row) {
  reset();
  const _adminId = row.adminId || ids.value
  getAdmins(_adminId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Add administrator information management";
  });
}


function submitForm() {
  proxy.$refs["adminsRef"].validate(valid => {
    if (valid) {
      if (form.value.adminId != null) {
        updateAdmins(form.value).then(response => {
          ElMessage.success("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addAdmins(form.value).then(response => {
          ElMessage.success("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** Delete button operation */
function handleDelete(row) {
  const _adminIds = row.adminId || ids.value;
  proxy.$modal.confirm('Are you sure to delete the administrator information?"' + _adminIds + '"data？').then(function() {
    return delAdmins(_adminIds);
  }).then(() => {
    getList();
    ElMessage.success("Delete successful");
  }).catch(() => {});
}

/** Export button action */
function handleExport() {
  proxy.download('ty/admins/export', {
    ...queryParams.value
  }, `admins_${new Date().getTime()}.xlsx`)
}

getList();
</script>
