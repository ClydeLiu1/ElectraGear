
/* resources
https://www.iconfont.cn/search/index?searchType=icon&q=%E6%98%9F%E6%98%9F

https://www.youtube.com/watch?v=NUDBj7uJygI
*/


<template>
  <div class="wrap">
    <div class="middle">
      <div class="frame">
        <div class="overlap-group">
          <div class="rectangle" />
          <div class="div" />
          <div class="text-wrapper">ElectraGear</div>
          <div class="text-wrapper-2">BYD</div>
          <div class="text-wrapper-3">MG</div>
          <div class="text-wrapper-4">TESLA</div>
          <div class="text-wrapper-5">EV Service</div>
          <div class="text-wrapper-6">CONTACT US</div>
          <div class="text-wrapper-7">
            <img src=".././assets/shop.png" alt="">
          </div>
          <div class="text-wrapper-8">NZ EV accessories</div>
        </div>
      </div>
    </div>
    <div class="middle-frame">
      <div class="top-font">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="top-font2">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="top-font3">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="top-font4">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="img-content">
        <div class="img-blur"></div>
        <div class="img-size">
          <div class="img-blur"></div>
        </div>
        <div class="img-size">
          <div class="img-blur"></div>
        </div>
        <div class="img-size">
          <div class="img-blur"></div>
        </div>
      </div>
    </div>
    <div class="middle-frame2">
      <div class="top-font">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="top-font2">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="top-font3">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="top-font4">
        <p class="text-style">BYD</p>
        <P>Atto 3</P>
        <div class="shop">Shop Now</div>
      </div>
      <div class="img-content">
        <div class="img-blur"></div>

        <div class="img-size">
          <div class="img-blur"></div>
        </div>
        <div class="img-size">
          <div class="img-blur"></div>
        </div>
        <div class="img-size">
          <div class="img-blur"></div>
        </div>
      </div>
    </div>

    <div class="bottom">
      <div class="box">
        <div class="bottom-one">
          <p class="one-style">EV Models</p>
          <p>BYD Atto3</p>
          <p>MG4</p>
          <P>MG ZS EV</P>
          <P>Kia EV6</P>
          <p>Tesia ModelY / Model3</p>
        </div>
        <div class="bottom-two">
          <p class="two-style">EV Charging</p>
          <p>Charging Cabies</p>
          <p>Charging Accesscries</p>
        </div>
        <div class="bottom-three">
          <p class="three-style">Info & Help</p>
          <p>Sipping</p>
          <p>Click & Collect</p>
          <p>Returns & Refunds</p>
          <p>Privacy Policy</p>
          <p>Terns & Conditions</p>
          <p>Contact Us</p>
        </div>
        <div class="bottom-four">
          <div class="font-top">
            <p>Free shipping for order</p>
            <p>over $99 new Zealand wide</p>
          </div>
          <div class="three-img">
            <img src=".././assets/heart.png" alt="">
          </div>
        </div>
      </div>
    </div>

  </div>

</template>

<script>
export default {
  name: "Frame",
};
</script>

<style>
.wrap {
  width: 1520px;
  height: 1200px;
  background-color: #f5f5f5;
}
.frame {
  height: 364px;
  overflow: hidden;
  width: 1024px;
  background-image: url('.././assets/p1.jpg');
  background-size: cover;
  margin: 0 auto;
}
.frame .overlap-group {
  height: 463px;
  left: -97px;
  position: relative;
  top: -89px;
  width: 1237px;
}
.frame .img {
  height: 364px;
  left: 97px;
  object-fit: cover;
  position: absolute;
  top: 89px;
  width: 1021px;
}
.frame .rectangle {
  background-color: #5f5f5f87;
  height: 463px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1199px;
}
.frame .div {
  background-color: #595959a6;
  height: 115px;
  left: 24px;
  position: absolute;
  top: 30px;
  width: 1213px;
}
.frame .text-wrapper {
  color: #ffffff;
  font-family: "Inter-Black", Helvetica;
  font-size: 16px;
  font-weight: 900;
  left: 211px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 105px;
  white-space: nowrap;
}
.frame .text-wrapper-2 {
  color: #ffffff;
  font-family: "Inika-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 519px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 106px;
}
.frame .text-wrapper-3 {
  color: #ffffff;
  font-family: "Inika-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 579px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 106px;
}
.frame .text-wrapper-4 {
  color: #ffffff;
  font-family: "Inika-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 639px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 106px;
}
.frame .text-wrapper-5 {
  color: #ffffff;
  font-family: "Inika-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 737px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 107px;
}
.frame .text-wrapper-6 {
  color: #ffffff;
  font-family: "Inika-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 859px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 108px;
}

.frame .text-wrapper-7 {
  left: 1010px;
  position: absolute;
  top: 100px;
}

.frame .vector {
  height: 15px;
  left: 494px;
  position: absolute;
  top: 109px;
  width: 15px;
}

.frame .icon-chevron-bottom {
  height: 10px;
  left: 554px;
  position: absolute;
  top: 112px;
  width: 15px;
}

.frame .icon-chevron-bottom-2 {
  height: 11px;
  left: 614px;
  position: absolute;
  top: 112px;
  width: 95px;
}

.frame .vector-2 {
  height: 17px;
  left: 1033px;
  position: absolute;
  top: 111px;
  width: 23px;
}

.frame .text-wrapper-8 {
  color: #ffffff;
  font-family: "Inika-Regular", Helvetica;
  font-size: 48px;
  font-weight: 400;
  left: 211px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 230px;
}

.middle-frame {
  width: 1024px;
  height: 180px;
  background-color: #fff;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
}

.img-content {
  width: 900px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  position: relative;
  right: 35px;
}

.img-size img {
  width: 200px;
}

.img-blur {
  width: 200px;
  height: 150px;
  background-image: url('.././assets/p2.jpg');
  background-size: cover;
  background-position: center;
  filter: blur(1px);

}

.middle-frame2 {
  width: 1024px;
  height: 180px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
}

.top-font {
  z-index: 1000;
  color: #fff;
  position: relative;
  left: 65px;
  font-size: 25px;
  font-weight: 800;
}

.top-font2 {
  z-index: 1000;
  color: #fff;
  position: absolute;
  left: 570px;
  font-size: 25px;
  font-weight: 800;
}

.top-font3 {
  z-index: 1000;
  color: #fff;
  position: absolute;
  left: 795px;
  font-size: 25px;
  font-weight: 800;
}

.top-font4 {
  z-index: 1000;
  color: #fff;
  position: absolute;
  left: 1020px;
  font-size: 25px;
  font-weight: 800;
}

.shop {
  width: 75px;
  text-align: center;
  font-size: 12px;
  color: #000;
  font-weight: 800;
  position: relative;
  bottom: 20px;
  background-color: #fff;
}

.text-style {
  position: relative;
  top: 30px;
}

.img-content2 {
  width: 900px;
  display: flex;
  align-items: center;
  justify-content: space-around;
}

.middle-frame2 {
  background-color: #efefef;
}

.bottom {
  width: 1024px;
  height: 320px;
  margin: 0 auto;
  background-color: #fff;
}

.box {
  width: 96%;
  margin: 0 auto;
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.bottom-one {
  width: 150px;
  height: 260px;
  font-size: 14px;
  font-weight: bold;
  color: gray;
}

.one-style {
  font-size: 18px;
  font-family: "Inter-Black", Helvetica;
}

.two-style {
  font-size: 18px;
  color: #000;
  font-family: "Inter-Black", Helvetica;
}

.bottom-two {
  width: 130px;
  height: 260px;
  font-size: 14px;
  color: gray;
  font-weight: 400;
  /* border: 1px red; */
}

.bottom-three {
  width: 140px;
  height: 260px;
  font-size: 14px;
  color: gray;
  font-weight: bold;
}

.three-style {
  font-size: 18px;
  color: #000;
  font-family: "Inter-Black", Helvetica;

}

.bottom-four {
  width: 170px;
  height: 260px;
  font-size: 14px;
  color: gray;
  font-weight: bold;
}

.font-top {
  position: relative;
  top: 20px;
}

.three-img {
  width: 100%;
  display: flex;
  justify-content: center;
  position: relative;
  top: 20px;
}
</style>
