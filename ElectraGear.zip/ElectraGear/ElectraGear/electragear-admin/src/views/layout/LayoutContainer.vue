<script setup>
import { User, Position, Promotion } from '@element-plus/icons-vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores'
const router = useRouter()
const userStore = useUserStore()

const toLogin = async () => {
  // exit
  await ElMessageBox.confirm('Are you sure you want to exit', 'Warm Prompt', {
    type: 'warning',
    confirmButtonText: 'Confirm',
    cancelButtonText: 'Cancel'
  })
// Clear local data (token + user information)
  userStore.removeToken()
  userStore.setUser = null
  router.push('/login')
}
</script>

<template>
  <el-container class="layout-container">
    <el-aside width="12.5rem">
      <div class="manage"><span style="color: white">Manage</span></div>
      <el-menu
        active-text-color="#ffd04b"
        background-color="#232323"
        :default-active="$route.path"
        text-color="#fff"
        router
      >
      <el-menu-item index="/products/list">
        <el-icon><Promotion /></el-icon>
        <span>Products</span>
      </el-menu-item>
      <el-menu-item index="/orders/list">
        <el-icon><Promotion /></el-icon>
        <span>Orders</span>
      </el-menu-item>
      <el-menu-item index="/contact/list">
        <el-icon><Promotion /></el-icon>
        <span>Contact Us</span>
      </el-menu-item>

        <el-menu-item index="/user/userlist">
          <el-icon><User /></el-icon>
          <span>Members</span>
        </el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header>
        <div>USER：<strong>Admin</strong></div>
        <el-button type="primary" @click="toLogin">Log Out</el-button>
      </el-header>
      <el-main>
        <router-view></router-view>
      </el-main>

    </el-container>
  </el-container>
</template>

<style lang="scss" scoped>
.layout-container {
  height: 100vh;
  .el-aside {
    background-color: #232323;
    .manage {
      display: flex;
      height: 7.5rem;
      justify-content: center;
      align-items: center;
      font-size: 1.875rem;
    }
    .el-menu {
      border-right: none;
    }
  }
  .el-header {
    background-color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .el-dropdown__box {
      display: flex;
      align-items: center;
      .el-icon {
        color: #999;
        margin-left: 0.625rem;
      }

      &:active,
      &:focus {
        outline: none;
      }
    }
  }
  .el-footer {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.875rem;
    color: #666;
  }
}
</style>
