<script setup>
import { ref,reactive, toRefs, getCurrentInstance } from 'vue'
import { Delete } from '@element-plus/icons-vue'
import { listUser, getUser, delUser, addUser, updateUser  } from '@/api/user'
const { proxy } = getCurrentInstance();
import UserAdd from './components/UserAdd.vue'

const userList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    username: null,    
    password: null,    
    nickname: null,    
    phone: null,    
    services: null,    
    evaluation: null  
  },
  rules: {
        username: [
      { required: true,trigger: "blur" }
    ],   
      email: [
      { required: true, trigger: "blur" }
    ],    phone: [
      { required: true, trigger: "blur" }
    ],  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询用户列表 */
function getList() {
  loading.value = true;
  listUser(queryParams.value).then(response => {
    userList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// 取消按钮
function cancel() {
  open.value = false;
  reset();
}

// 表单重置
function reset() {
  form.value = {
    id: null,    
    username: null,    
    password: null,    
    eamil: null,    
    mobile: null,    
    isMember: null,    
    memberDiscount: null
  };
  resetForm("userRef");
}

// 表单重置
function resetForm(refName) {
  if (proxy.$refs[refName]) {
    proxy.$refs[refName].resetFields();
  }
}


/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 修改按钮操作 */
function handleUpdate(row) {
  console.log(row.userId)
  reset();
  const _id = row.userId || ids.value
  getUser(_id).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Modify";
  });
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["userRef"].validate(valid => {
    if (valid) {
      if (form.value.userId != null) {
        updateUser(form.value).then(response => {
          ElMessage.success("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addUser(form.value).then(response => {
          ElMessage.success("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.userId || ids.value;
  confirm('Do you want to delete this record?').then(function() {
    return delUser(_ids);
  }).then(() => {
    getList();
    ElMessage.success("Delete successful");
  }).catch(() => {});
}

 function confirm(content) {
    return ElMessageBox.confirm(content, "Warm Prompt", {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: "warning",
    })
  }
// 日期格式化
function parseTime(time, pattern) {
  if (arguments.length === 0 || !time) {
    return null
  }
  time = new Date(time)
  const format = pattern || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if ((typeof time === 'string') && (/^[0-9]+$/.test(time))) {
      time = parseInt(time)
    } else if (typeof time === 'string') {
      time = time.replace(new RegExp(/-/gm), '/').replace('T', ' ').replace(new RegExp(/\.[\d]{3}/gm), '');
    }
    if ((typeof time === 'number') && (time.toString().length === 10)) {
      time = time * 1000
    }
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    // Note: getDay() returns 0 on Sunday
    if (key === 'a') { return ['日', '一', '二', '三', '四', '五', '六'][value] }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return time_str
}
getList();
</script>

<template>
 <!-- <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="用户名" prop="username">
        <el-input
          v-model="queryParams.username"
          placeholder="请输入用户名"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input
          v-model="queryParams.phone"
          placeholder="请输入手机号"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
    
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form> -->
  <page-container>
     <el-table v-loading="loading" :data="userList" @selection-change="handleSelectionChange">
      <el-table-column label="UserName" align="center" prop="username" />
      <el-table-column label="Mobile" align="center" prop="phone" />
      <el-table-column label="Email" align="center" prop="email" />
      <el-table-column label="Address" align="center" prop="address" />
      <el-table-column label="Member" align="center" prop="isMember" />
      <el-table-column label="RegistrationDate" align="center" prop="registrationDate">
        <template #default="scope">
          <span>{{ parseTime(scope.row.registrationDate ) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Operation" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)">Modify</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改用户对话框 -->
    <el-dialog :title="title" v-model="open" width="800px" append-to-body class="modalStyle">
      <el-form ref="userRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="UserName" prop="username">
          <el-input v-model="form.username" readonly  />
        </el-form-item>
        <el-form-item label="Email" prop="email">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item label="Phone" prop="phone">
          <el-input v-model="form.phone"  />
        </el-form-item>
        <el-form-item label="Address" prop="address">
          <el-input v-model="form.address" />
        </el-form-item>、
        <el-form-item label="Member" prop="isMember">
          <el-radio-group v-model="form.isMember">
            <el-radio :label="1">Yes</el-radio>
            <el-radio :label="2">No</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 抽屉 -->
    <!-- <user-add ref="userEditRef" @success="onSuccess"></user-add> -->
  </page-container>
</template>

<style scoped>

</style>
