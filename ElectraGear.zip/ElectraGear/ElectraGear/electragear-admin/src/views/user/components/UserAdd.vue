<script setup>
import { ref } from 'vue'

// 控制抽屉显示
const visibleDrawer = ref(false)

// 默认数据
const defaultForm = {
  username: '',
  nickname: '',
  mobile: '',
  evalution: '',
  services: ''
}

// 准备数据
const formModel = ref({ ...defaultForm })

//校验规则
const rules = {}

// 提交

// 组件对外暴露一个方法open，
// open({}) => 表单无需渲染
// open({id,...,...}) => 表单需要渲染，说明是编辑
// open调用后,可以打开抽屉
const open = async () => {
  visibleDrawer.value = true
}

//提交
const emit = defineEmits(['Success'])
const testdriveAdd = async () => {
  // 注意：当前接口，需要的是formData对象
  // 将普通对象 => 转换成 => formData对象
  const fd = new FormData()
  for (let key in formModel.value) {
    fd.append(key, formModel.value[key])
  }

  // 发请求
  if (formModel.value.id) {
    // 编辑操作
    await ElMessage.success('Modified successfully')
    visibleDrawer.value = false
    // 通知父组件添加成功
    emit('success', 'edit')
  } else {
    // 添加操作
    await ElMessage.success('添加成功')
    visibleDrawer.value = false
    // 通知父组件添加成功
    emit('success', 'add')
  }
}

defineExpose({
  open
})
</script>

<!-- 抽屉 -->
<template>
  <el-drawer v-model="visibleDrawer" :title="订购" direction="rtl" size="50%">
    <!-- 发表文章表单 -->
    <el-form :model="formModel" :rules="rules" ref="formRef" label-width="6.25rem">
      <el-form-item label="型号" prop="car_name">
        <el-input v-model="formModel.car_name" placeholder="请输入型号"></el-input>
      </el-form-item>
      <el-form-item label="车型" prop="car_name">
        <el-input v-model="formModel.car_type" placeholder="请输入车型"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="testdriveAdd">提交</el-button>
      </el-form-item>
    </el-form>
  </el-drawer>
</template>

<style lang="scss" scoped></style>
