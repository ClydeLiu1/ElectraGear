<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="UserID" prop="userId">
        <el-input
          v-model="queryParams.userId"
          placeholder="Please Enter OrderID"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="OrderID" prop="orderId">
        <el-input
          v-model="queryParams.orderId"
          placeholder="Please Enter OrderID"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="Invoice Content" prop="invoiceContent">
        <el-input
          v-model="queryParams.invoiceContent"
          placeholder="Please Enter Invoice Content"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="Invoice Date" prop="invoiceDate">
        <el-date-picker clearable
          v-model="queryParams.invoiceDate"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="Please Select Invoice Date">
        </el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">Search</el-button>
        <el-button icon="Refresh" @click="resetQuery">Reset</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['ty:invoices:add']"
        >ADD</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['ty:invoices:edit']"
        >Change</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['ty:invoices:remove']"
        >Delete</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['ty:invoices:export']"
        >Export</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="invoicesList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="InvoiceDate" align="center" prop="invoiceId" />
      <el-table-column label="UserID" align="center" prop="userId" />
      <el-table-column label="OrderID" align="center" prop="orderId" />
      <el-table-column label="InvoiceContent" align="center" prop="invoiceContent" />
      <el-table-column label="InvoiceDate" align="center" prop="invoiceDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.invoiceDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Operate" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['ty:invoices:edit']">Change</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['ty:invoices:remove']">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="invoicesRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="UserId" prop="userId">
          <el-input v-model="form.userId" placeholder="Please enter UserId" />
        </el-form-item>
        <el-form-item label="orderId" prop="orderId">
          <el-input v-model="form.orderId" placeholder="Please enter orderId" />
        </el-form-item>
        <el-form-item label="InvoiceContent" prop="invoiceContent">
          <el-input v-model="form.invoiceContent" placeholder="Please Enter InvoiceContent" />
        </el-form-item>
        <el-form-item label="InvoiceDate" prop="invoiceDate">
          <el-date-picker clearable
            v-model="form.invoiceDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="Please select an invoice date">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Invoices">
import { listInvoices, getInvoices, delInvoices, addInvoices, updateInvoices } from "@/api/invoices";

const { proxy } = getCurrentInstance();
const { ${dictsNoSymbol} } = proxy.useDict(${dicts});

const invoicesList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
        userId: null,    orderId: null,    invoiceContent: null,    invoiceDate: null  },
  rules: {
      }
});

const { queryParams, form, rules } = toRefs(data);


function getList() {
  loading.value = true;
  listInvoices(queryParams.value).then(response => {
    invoicesList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}


function cancel() {
  open.value = false;
  reset();
}


function reset() {
  form.value = {
    invoiceId: null,    userId: null,    orderId: null,    invoiceContent: null,    invoiceDate: null  };
  proxy.resetForm("invoicesRef");
}


function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}


function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}


function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.invoiceId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}


function handleAdd() {
  reset();
  open.value = true;
  title.value = "Add invoice info";
}

function handleUpdate(row) {
  reset();
  const _invoiceId = row.invoiceId || ids.value
  getInvoices(_invoiceId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "Fix invoice";
  });
}


function submitForm() {
  proxy.$refs["invoicesRef"].validate(valid => {
    if (valid) {
      if (form.value.invoiceId != null) {
        updateInvoices(form.value).then(response => {
          proxy.$modal.msgSuccess("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addInvoices(form.value).then(response => {
          proxy.$modal.msgSuccess("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}


function handleDelete(row) {
  const _invoiceIds = row.invoiceId || ids.value;
  proxy.$modal.confirm('Are you sure to delete the invoice management number?"' + _invoiceIds + '"data？').then(function() {
    return delInvoices(_invoiceIds);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("Delete successful");
  }).catch(() => {});
}


function handleExport() {
  proxy.download('ty/invoices/export', {
    ...queryParams.value
  }, `invoices_${new Date().getTime()}.xlsx`)
}

getList();
</script>
