<template>
  <div class="app-container">
    <!-- <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['orders:orders:add']"
        >Add</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row> -->

    <el-table v-loading="loading" :data="ordersList" @selection-change="handleSelectionChange">
      <el-table-column label="User Name" align="center" prop="userName" />
      <el-table-column label="Free Shipping" align="center" prop="freeShipping" />
      <el-table-column label="Delivery Address" align="center" prop="deliveryAddress" />
      <el-table-column label="Subtotal" align="center" prop="subtotal" />
      <el-table-column label="Card Number" align="center" prop="cardNumber" />
      <el-table-column label="Expiration Date" align="center" prop="expirationDate" />
      <el-table-column label="Security Code" align="center" prop="securityCode" />
      <el-table-column label="Order Status" align="center" prop="orderStatus" >
        <template #default="scope">
          <span v-if="scope.row.orderStatus == '1'">Payment</span>
          <span v-if="scope.row.orderStatus == '2'">Delivered</span>
          <span v-if="scope.row.orderStatus == '3'">Completed</span>
        </template>
      </el-table-column>
      <el-table-column label="Order Date" align="center" prop="orderDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.orderDate) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Operation" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row, '2')">Deliver</el-button>
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row, '3')">Complete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- Add or Edit Order Management Dialog -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="ordersRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="Product Name" prop="productsName">
          <el-input v-model="form.productsName" />
        </el-form-item>
        <el-form-item label="Stock Quantity" prop="num">
          {{form.num}}
        </el-form-item>
        <el-form-item label="User" prop="userName">
          {{form.userName}}
        </el-form-item>
        <el-form-item label="Free Shipping" prop="freeShipping">
          <el-input v-model="form.freeShipping" />
          <span v-if="form.freeShipping == 1">Yes</span>
          <span v-if="form.freeShipping == 2">No</span>
        </el-form-item>
        <el-form-item label="Payment Type" prop="paymentInfoId">
          {{form.paymentInfoId}}
        </el-form-item>
        <el-form-item label="Delivery Address" prop="deliveryAddress">
          {{form.deliveryAddress}}
        </el-form-item>
        <el-form-item label="Subtotal" prop="subtotal">
          {{form.subtotal}}
        </el-form-item>
        <el-form-item label="Order Date" prop="orderDate">
          {{form.orderDate}}
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">Confirm</el-button>
          <el-button @click="cancel">Cancel</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Orders">
import { listOrders, getOrders, delOrders, addOrders, updateOrders } from "@/api/orders";
import { ref, reactive, toRefs, getCurrentInstance, watch } from 'vue'
const { proxy } = getCurrentInstance();

const ordersList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    num: null, productsId: null, freeShipping: null, paymentInfoId: null, deliveryAddress: null, subtotal: null, orderStatus: null, orderDate: null, userId: null,  },
  rules: {
    productsId: [
      { required: true, message: "Product ID cannot be empty", trigger: "blur" }
    ], userId: [
      { required: true, message: "User ID cannot be empty", trigger: "blur" }
    ],  }
});

const { queryParams, form, rules } = toRefs(data);

/** Get the order management list */
function getList() {
  loading.value = true;
  listOrders(queryParams.value).then(response => {
    ordersList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// Cancel button
function cancel() {
  open.value = false;
  reset();
}

// Reset form
function reset() {
  form.value = {
    num: null, productsId: null, freeShipping: null, paymentInfoId: null, deliveryAddress: null, subtotal: null, orderStatus: null, orderDate: null, userId: null, orderId: null  };
  proxy.resetForm("ordersRef");
}

/** Search button operation */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** Reset button operation */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// Selected data in the checkbox
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.orderId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** Add button operation */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "Add Order Management";
}

/** Edit button operation */
function handleUpdate(row, state) {
  const _orderId = row.orderId || ids.value
  getOrders(_orderId).then(response => {
    form.value = response.data;
    form.value.orderStatus = state
    updateOrders(form.value).then(response => {
      ElMessage.success("Modified successfully");
      getList();
    });
  });
}

/** Submit button */
function submitForm() {
  proxy.$refs["ordersRef"].validate(valid => {
    if (valid) {
      if (form.value.orderId != null) {
        updateOrders(form.value).then(response => {
          proxy.$modal.msgSuccess("Modified successfully");
          open.value = false;
          getList();
        });
      } else {
        addOrders(form.value).then(response => {
          proxy.$modal.msgSuccess("Update successful");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** Delete button operation */
function handleDelete(row) {
  const _orderIds = row.orderId || ids.value;
  proxy.$modal.confirm('Do you want to delete this record?').then(function() {
    return delOrders(_orderIds);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("Delete successful");
  }).catch(() => {});
}

/** Export button operation */
function handleExport() {
  proxy.download('orders/orders/export', {
    ...queryParams.value
  }, `orders_${new Date().getTime()}.xlsx`)
}
// Date formatting
function parseTime(time, pattern) {
  if (arguments.length === 0 || !time) {
    return null
  }
  time = new Date(time)
  const format = pattern || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if ((typeof time === 'string') && (/^[0-9]+$/.test(time))) {
      time = parseInt(time)
    } else if (typeof time === 'string') {
      time = time.replace(new RegExp(/-/gm), '/').replace('T', ' ').replace(new RegExp(/\.[\d]{3}/gm), '');
    }
    if ((typeof time === 'number') && (time.toString().length === 10)) {
      time = time * 1000
    }
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    // Note: getDay() returns 0 on Sunday
    if (key === 'a') { return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][value] }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return time_str
}
getList();
</script>
