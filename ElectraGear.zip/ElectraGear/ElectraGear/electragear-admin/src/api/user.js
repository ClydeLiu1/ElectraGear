import request from '@/utils/request'

//Registration interface
export const userRegisterService = ({ username, password, repassword }) =>
  request.post('/api/reg', { username, password, repassword })

// Login interface
export function userLoginService({ username, password }) {
  return request({
    url: '/login',
    method: 'post',
    params: {
      username,
      password
    }
  })
}

export const userGetListService = (params) =>
  request.get('/user/list', {
    params
  })

//add user
export const userAddService = (data) => request.post('/user/add', data)


export const userGetInfoService = (id) =>
  request.get('/user/getInfo', {
    params: { id }
  })

// delete user
export const userDelService = (id) =>
  request.delete('/user', { params: { id } })

// edit user
export const userEditService = (data) => request.put('/user/edit', data)

// renew password
export const userUpdatePasswordService = ({ old_pwd, new_pwd, re_pwd }) =>
  request.patch('/my/updatepwd', { old_pwd, new_pwd, re_pwd })


// search user list
export function listUser(query) {
  return request({
    url: '/user/list',
    method: 'get',
    params: query
  })
}

// search user detail
export function getUser(id) {
  return request({
    url: '/user/getInfo/' + id,
    method: 'get'
  })
}

// add user
export function addUser(data) {
  return request({
    url: '/user/add',
    method: 'post',
    data: data
  })
}

// change user
export function updateUser(data) {
  return request({
    url: '/user/edit',
    method: 'put',
    data: data
  })
}

// delete user
export function delUser(id) {
  return request({
    url: '/user/' + id,
    method: 'delete'
  })
}
// change password
export function updatePwd({ userId, password, oldPassword }) {
  return request({
    url: '/user/updatePwd',
    method: 'post',
    params: {
      userId,
      password,
      oldPassword
    }
  })
}