import request from '@/utils/request'


export function userLoginService({ username, password }) {
  return request({
    url: '/admins/login',
    method: 'post',
    params: {
      username,
      password
    }
  })
}


export function listAdmins(query) {
  return request({
    url: '/ty/admins/list',
    method: 'get',
    params: query
  })
}

export function getAdmins(adminId) {
  return request({
    url: '/ty/admins/' + adminId,
    method: 'get'
  })
}


export function addAdmins(data) {
  return request({
    url: '/ty/admins',
    method: 'post',
    data: data
  })
}


export function updateAdmins(data) {
  return request({
    url: '/ty/admins',
    method: 'put',
    data: data
  })
}


export function delAdmins(adminId) {
  return request({
    url: '/ty/admins/' + adminId,
    method: 'delete'
  })
}


export function exportAdmins(query) {
  return request({
    url: '/ty/admins/export',
    method: 'get',
    params: query
  })
}