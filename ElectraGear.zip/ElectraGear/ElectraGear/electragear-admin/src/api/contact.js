import request from '@/utils/request'

// Query Contact Us List
export function listContact(query) {
  return request({
    url: '/ty/contact/list',
    method: 'get',
    params: query
  })
}

// Query Contact Us detail
export function getContact(contactId) {
  return request({
    url: '/ty/contact/' + contactId,
    method: 'get'
  })
}

// add Contact Us
export function addContact(data) {
  return request({
    url: '/ty/contact',
    method: 'post',
    data: data
  })
}

// fix Contact Us
export function updateContact(data) {
  return request({
    url: '/ty/contact',
    method: 'put',
    data: data
  })
}
// delete Contact Us
export function delContact(contactId) {
  return request({
    url: '/ty/contact/' + contactId,
    method: 'delete'
  })
}

// export Contact Us
export function exportContact(query) {
  return request({
    url: '/ty/contact/export',
    method: 'get',
    params: query
  })
}