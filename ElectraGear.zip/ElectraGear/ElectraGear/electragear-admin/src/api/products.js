import request from '@/utils/request'

// Query the product management list
export function listProducts(query) {
  return request({
    url: '/products/list',
    method: 'get',
    params: query
  })
}

// Query the product management list
export function getProducts(productId) {
  return request({
    url: '/products/' + productId,
    method: 'get'
  })
}

// add to product management
export function addProducts(data) {
  return request({
    url: '/products',
    method: 'post',
    data: data
  })
}

// // fix product management
export function updateProducts(data) {
  return request({
    url: '/products',
    method: 'put',
    data: data
  })
}

// // delete product management
export function delProducts(productId) {
  return request({
    url: '/products/' + productId,
    method: 'delete'
  })
}

// export product management
export function exportProducts(query) {
  return request({
    url: '/products/export',
    method: 'get',
    params: query
  })
}