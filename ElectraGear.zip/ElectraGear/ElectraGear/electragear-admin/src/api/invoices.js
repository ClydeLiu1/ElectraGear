import request from '@/utils/request'


export function listInvoices(query) {
  return request({
    url: '/ty/invoices/list',
    method: 'get',
    params: query
  })
}

export function getInvoices(invoiceId) {
  return request({
    url: '/ty/invoices/' + invoiceId,
    method: 'get'
  })
}

export function addInvoices(data) {
  return request({
    url: '/ty/invoices',
    method: 'post',
    data: data
  })
}


export function updateInvoices(data) {
  return request({
    url: '/ty/invoices',
    method: 'put',
    data: data
  })
}


export function delInvoices(invoiceId) {
  return request({
    url: '/ty/invoices/' + invoiceId,
    method: 'delete'
  })
}

export function exportInvoices(query) {
  return request({
    url: '/ty/invoices/export',
    method: 'get',
    params: query
  })
}