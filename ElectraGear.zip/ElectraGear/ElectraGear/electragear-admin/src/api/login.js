import request from '@/utils/request'

// Login method
export function login(phoneNumber,  verfifyCode) {
  const data = {
    phoneNumber,
    verfifyCode
  }
  return request({
    url: '/login',
    method: 'post',
    params: data
  })
}

// Get user details
export function getInfo() {
  return request({
    url: '/getInfo',
    method: 'get'
  })
}

// exit
export function logout() {
  return request({
    url: '/logout',
    method: 'post'
  })
}

// get verification code
export function getCodeImg() {
  return request({
    url: '/captchaImage',
    method: 'get'
  })
}

export function getUrlKey(name, url) {
  return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(url) || [, ""])[1].replace(/\+/g, '%20')) || null
}

export function getUserByUsername(userName) {
  const data = {
    userName
  }
  return request({
    url: '/system/user/getUserByUsername',
    method: 'put',
    params: data
  })
}
