import request from '@/utils/request'

// Query the payment method list
export function listInfo(query) {
  return request({
    url: '/payment/info/list',
    method: 'get',
    params: query
  })
}

// Query the payment method detail
export function getInfo(paymentInfoId) {
  return request({
    url: '/payment/info/' + paymentInfoId,
    method: 'get'
  })
}

//add payment method
export function addInfo(data) {
  return request({
    url: '/payment/info',
    method: 'post',
    data: data
  })
}

// change the payment method
export function updateInfo(data) {
  return request({
    url: '/payment/info',
    method: 'put',
    data: data
  })
}

// delete the payment method
export function delInfo(paymentInfoId) {
  return request({
    url: '/payment/info/' + paymentInfoId,
    method: 'delete'
  })
}

// export the payment method
export function exportInfo(query) {
  return request({
    url: '/payment/info/export',
    method: 'get',
    params: query
  })
}