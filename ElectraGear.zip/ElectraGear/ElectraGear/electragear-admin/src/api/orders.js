import request from '@/utils/request'

// Query the order management list
export function listOrders(query) {
  return request({
    url: '/orders/list',
    method: 'get',
    params: query
  })
}

// Query the order management detail
export function getOrders(orderId) {
  return request({
    url: '/orders/' + orderId,
    method: 'get'
  })
}

// Add order management
export function addOrders(data) {
  return request({
    url: '/orders',
    method: 'post',
    data: data
  })
}

// fix order management
export function updateOrders(data) {
  return request({
    url: '/orders',
    method: 'put',
    data: data
  })
}
// delete order management
export function delOrders(orderId) {
  return request({
    url: '/orders/' + orderId,
    method: 'delete'
  })
}

// export  order management
export function exportOrders(query) {
  return request({
    url: '/orders/export',
    method: 'get',
    params: query
  })
}