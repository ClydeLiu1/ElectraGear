import request from '@/utils/request'

// check shopping cart management
export function listCart(query) {
  return request({
    url: '/ty/cart/list',
    method: 'get',
    params: query
  })
}

// search shopping cart management
export function getCart(cartId) {
  return request({
    url: '/ty/cart/' + cartId,
    method: 'get'
  })
}

// add shopping cart management
export function addCart(data) {
  return request({
    url: '/ty/cart',
    method: 'post',
    data: data
  })
}

// fix shopping cart management
export function updateCart(data) {
  return request({
    url: '/ty/cart',
    method: 'put',
    data: data
  })
}

// Delete shopping cart management
export function delCart(cartId) {
  return request({
    url: '/ty/cart/' + cartId,
    method: 'delete'
  })
}

// 导出购物车管理
export function exportCart(query) {
  return request({
    url: '/ty/cart/export',
    method: 'get',
    params: query
  })
}