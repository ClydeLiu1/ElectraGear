import { defineStore } from "pinia";

const routerParams = defineStore("params", {
  state: () => ({
    map: new Map(),
    initializeMap: { pageNum: 1, pageSize: 10 },
    tempMap: new Map(),
  }),
  actions: {
    set(key, value) {
      this.map.set(key, value);
    },
    get(key) {
      let value = this.map.get(key);
      return value ? value : this.initializeMap;
    },
    delete(key) {
      this.map.set(key, this.initializeMap);
    },

    tempSet(key, value) {
      this.tempMap.set(key, value);
    },
    tempGet(key) {
      let value = this.tempMap.get(key);
      return value ? value : new Map();
    },
    tempDelete(key) {
      this.tempMap.set(key, "");
    },
  },
});

const tempFlag = defineStore("temp", {
  state: () => ({
    map: new Map(),
  }),
  actions: {
    set(key, value) {
      this.map.set(key, value);
    },
    get(key) {
      let value = this.map.get(key);
      return value ? value : {};
    },
    delete(key) {
      this.map.set(key, "");
    },
  },
});

export default routerParams;
