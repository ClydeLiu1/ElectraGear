import {login, logout, getInfo} from '@/api/login'
import {getToken, setToken, removeToken} from '@/utils/auth'
import defAva from '../../assets/userNull.png'
import {defineStore} from "pinia";

const useUserStore = defineStore(
    'user',
    {
        state: () => ({
            token: getToken(),
            name: '',
            avatar: '',
            roles: [],
            permissions: [],
            userId: 0,
            userName: undefined,
            orgId: 0,
            org: undefined,
            type: {},
            getters: undefined,
        }),
        actions: {
            // login
            login(userInfo) {
                const phoneNumber = userInfo.phone
                const verifyCode = userInfo.sms_code
                return new Promise((resolve, reject) => {
                    login(phoneNumber, verifyCode).then(res => {
                        setToken(res.token)
                        this.token = res.token
                        resolve()
                    }).catch(error => {
                        reject(error)
                    })
                })
            },

            // Get user information
            getInfo() {
                return new Promise((resolve, reject) => {
                    getInfo().then(res => {
                        const user = res.user
                        const avatar = (user.avatarPath == "" || user.avatarPath == null) ? defAva : user.avatarPath;
                        if (res.roles && res.roles.length > 0) { // Verify that the returned roles is a non-empty array
                            this.roles = res.roles
                            this.permissions = res.permissions
                        } else {
                            this.roles = ['ROLE_DEFAULT']
                        }
                        this.name = user.userName
                        this.userId = user.id,
                        this.orgId = user.orgId,
                        this.org = user.org,
                        this.type = user.type
                        this.avatar = avatar;
                        resolve(res)
                    }).catch(error => {
                        reject(error)
                    })
                })
            },
            // exit system
            logOut() {
                return new Promise((resolve, reject) => {
                    logout(this.token).then(() => {
                        this.token = ''
                        this.roles = []
                        this.permissions = []
                        removeToken()
                        resolve()
                    }).catch(error => {
                        reject(error)
                    })
                })
            }
        }
    })

export default useUserStore
