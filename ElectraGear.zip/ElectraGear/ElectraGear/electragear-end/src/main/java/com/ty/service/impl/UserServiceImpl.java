package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.ty.domain.User;
import com.ty.domain.web.AjaxResult;
import com.ty.mapper.UsersMapper;
import com.ty.redis.RedisCache;
import com.ty.service.IUsersService;
import com.ty.utils.Md5Utils;

import cn.hutool.core.lang.UUID;
/**
 * 用户管理Service业务层处理
 * 
 * @date 2024-04-11
 */
@Service
public class UserServiceImpl implements IUsersService {
    @Autowired
    private UsersMapper userMapper;
    
    @Autowired
    private RedisCache redisCache;

    /**
     * 查询用户管理
     * 
     * @param id 用户管理ID
     * @return 用户管理
     */
    @Override
    public User selectUserById(Integer id) {
        return userMapper.selectById(id);
    }

    /**
     * 查询用户管理列表
     * 
     * @param user 用户管理
     * @return 用户管理
     */
    @Override
    public List<User> selectUserList(User user) {
    	QueryWrapper<User> wrapper = new QueryWrapper<>();
    	if (StringUtils.isNotEmpty(user.getUsername())) {
    		wrapper.like("username", user.getUsername());
    	}
    	
    	if (StringUtils.isNotEmpty(user.getPhone())) {
    		wrapper.like("phone", user.getPhone());
    	} 
        return userMapper.selectList(wrapper);
    }

    /**
     * 新增用户管理
     * 
     * @param user 用户管理
     * @return 结果
     */
    @Override
    public int insertUser(User user) {
    	user.setPassword(Md5Utils.hash(user.getPassword()));
    	user.setRegistrationDate(new Date());
        return userMapper.insert(user);
    }

    /**
     * 修改用户管理
     * 
     * @param user 用户管理
     * @return 结果
     */
    @Override
    public int updateUser(User user) {
        return userMapper.updateById(user);
    }

    /**
     * 批量删除用户管理
     * 
     * @param ids 需要删除的用户管理ID
     * @return 结果
     */
    @Override
    public int deleteUserByIds(Integer[] ids) {
    	List<Long> idList = new ArrayList(Arrays.asList(ids));
        return userMapper.deleteBatchIds(idList);
    }

    /**
     * 删除用户管理信息
     * 
     * @param id 用户管理ID
     * @return 结果
     */
    @Override
    public int deleteUserById(Integer id) {
        return userMapper.deleteById(id);
    }
    
    /**
     * 登录
     * @param username
     * @param password
     * @return
     */
    public AjaxResult login(String username, String password) {
    	AjaxResult ajax = AjaxResult.success();
    	QueryWrapper<User> wrapper = new QueryWrapper<>();
    	wrapper.eq("username", username);
    	wrapper.eq("password", Md5Utils.hash(password));
    	User user = userMapper.selectOne(wrapper);
    	if (user == null) {
    		return AjaxResult.error("username or password is incorrect");
    	}
    	
    	String token = UUID.fastUUID().toString();
    	//redisCache.setCacheObject("login_" + username, token, 30, TimeUnit.DAYS);
    	ajax.put("token", token);
    	ajax.put("user", user);
    	return ajax;
    }
    
    public AjaxResult updatePwd(Integer userId, String password, String oldPassword) {
    	AjaxResult ajax = AjaxResult.success();
    	User user = selectUserById(userId);
    	if (user != null) {
    		if (!user.getPassword().equals(Md5Utils.hash(oldPassword))) {
    			return AjaxResult.error("The original password is incorrect");
    		}
    		user.setPassword(Md5Utils.hash(password));
    		int i = updateUser(user);
    		if (i > 0) {
    			return ajax;
    		}
    	}
    	return AjaxResult.error();
    }
}
