package com.ty.service;

import java.util.List;

import com.ty.domain.Car;


public interface ICarService {

    public Car selectCarById(Integer id);


    public List<Car> selectCarList(Car car);


    public int insertCar(Car car);


    public int updateCar(Car car);

    public int deleteCarById(Integer id);
}
