package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.Contact;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IContactService;

/**
 * 联系我们Controller
 * 
 * @author ty
 * @date 2024-05-21
 */
@RestController
@RequestMapping("/ty/contact")
public class ContactController extends BaseController {
    @Autowired
    private IContactService contactService;

    /**
     * 查询联系我们列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Contact contact) {
        startPage();
        List<Contact> list = contactService.selectContactList(contact);
        return getDataTable(list);
    }


    /**
     * 获取联系我们详细信息
     */
    @GetMapping(value = "/{contactId}")
    public AjaxResult getInfo(@PathVariable("contactId") Integer contactId) {
        return AjaxResult.success(contactService.selectContactById(contactId));
    }

    /**
     * 新增联系我们
     */
    @PostMapping
    public AjaxResult add(@RequestBody Contact contact) {
        return toAjax(contactService.insertContact(contact));
    }

    /**
     * 修改联系我们
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Contact contact) {
        return toAjax(contactService.updateContact(contact));
    }

    /**
     * 删除联系我们
     */
	@DeleteMapping("/{contactIds}")
    public AjaxResult remove(@PathVariable Long[] contactIds) {
        return toAjax(contactService.deleteContactByIds(contactIds));
    }
}
