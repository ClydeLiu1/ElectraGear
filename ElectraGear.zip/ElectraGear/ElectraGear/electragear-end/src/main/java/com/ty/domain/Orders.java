package com.ty.domain;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;

/**
 * orders
 *
 * @date 2024-05-01
 */
@TableName(value = "orders")
@Data
public class Orders{
    private static final long serialVersionUID = 1L;

    private Integer freeShipping;


    private Long paymentInfoId;


    private String deliveryAddress;


    private Double subtotal;


    private String orderStatus;


    private Date orderDate;


    private Long userId;


    @TableId(value="order_id", type=IdType.AUTO)
    private Long orderId;
    
    private String firstName;
    
    private String lastName;
    
    private String phone;
    
    private String remark;
    
    

    private transient List<Map<String, Object>> productsCartList;
    
    private transient String cardNumber;
    private transient String expirationDate;
    private transient String securityCode;

    private transient String invoiceContent;
    private transient Date invoiceDate;
    private transient String userName;

}
