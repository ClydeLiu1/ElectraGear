package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ty.domain.CarTestDrive;
import com.ty.mapper.CarTestDriveMapper;
import com.ty.service.ICarTestDriveService;
import com.ty.utils.DateUtils;

/**
 * 预约试驾管理Service业务层处理
 * 
 * @date 2024-04-11
 */
@Service
public class CarTestDriveServiceImpl implements ICarTestDriveService {
    @Autowired
    private CarTestDriveMapper carTestDriveMapper;

    /**
     * 查询预约试驾管理
     * 
     * @param id 预约试驾管理ID
     * @return 预约试驾管理
     */
    @Override
    public CarTestDrive selectCarTestDriveById(Integer id) {
        return carTestDriveMapper.selectCarTestDriveById(id);
    }

    /**
     * 查询预约试驾管理列表
     * 
     * @param carTestDrive 预约试驾管理
     * @return 预约试驾管理
     */
    @Override
    public List<CarTestDrive> selectCarTestDriveList(CarTestDrive carTestDrive) {
        return carTestDriveMapper.selectCarTestDriveList(carTestDrive);
    }

    /**
     * 新增预约试驾管理
     * 
     * @param carTestDrive 预约试驾管理
     * @return 结果
     */
    @Override
    public int insertCarTestDrive(CarTestDrive carTestDrive) {
        return carTestDriveMapper.insert(carTestDrive);
    }

    /**
     * 修改预约试驾管理
     * 
     * @param carTestDrive 预约试驾管理
     * @return 结果
     */
    @Override
    public int updateCarTestDrive(CarTestDrive carTestDrive) {
        return carTestDriveMapper.updateById(carTestDrive);
    }


    /**
     * 删除预约试驾管理信息
     * 
     * @param id 预约试驾管理ID
     * @return 结果
     */
    @Override
    public int deleteCarTestDriveById(Integer id) {
        return carTestDriveMapper.deleteById(id);
    }
}
