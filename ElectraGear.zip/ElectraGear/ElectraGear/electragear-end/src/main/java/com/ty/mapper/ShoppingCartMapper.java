package com.ty.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.ShoppingCart;


@Mapper
@Repository
public interface ShoppingCartMapper extends BaseMapper<ShoppingCart> {
	
	Integer getNumByUserId(Integer userId);
}
