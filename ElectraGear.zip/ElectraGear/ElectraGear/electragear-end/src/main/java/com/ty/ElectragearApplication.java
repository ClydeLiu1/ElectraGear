package com.ty;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.ty.mapper")
public class ElectragearApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectragearApplication.class, args);
		System.out.println("running");
	}

}
