package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ty.mapper.OrderProductMapper;
import com.ty.mapper.OrdersMapper;
import com.ty.domain.OrderProduct;
import com.ty.domain.Orders;
import com.ty.domain.Products;
import com.ty.service.IOrderProductService;
import com.ty.service.IOrdersService;
import com.ty.service.IProductsService;

/**
 * 
 * @author ty
 * @date 2024-05-01
 */
@Service
public class OrderProductServiceImpl implements IOrderProductService {
    @Autowired
    private OrderProductMapper orderProductMapper;

    
    /**
     * 新增订单管理
     * 
     * @param orders 订单管理
     * @return 结果
     */
    @Override
    @Transactional
    public int insertOrders(OrderProduct orderProduct) {
    	int row = orderProductMapper.insert(orderProduct);
        return row;
    }

  

    @Override
    public int deleteByIds(Long[] orderIds) {
    	List<Long> idList = new ArrayList<>(Arrays.asList(orderIds));
        return orderProductMapper.deleteBatchIds(idList);
    }

    /**
     * 删除订单管理信息
     * 
     * @param orderId 订单管理ID
     * @return 结果
     */
    @Override
    public int deleteOrdersById(Long orderId) {
        return orderProductMapper.deleteById(orderId);
    }
}
