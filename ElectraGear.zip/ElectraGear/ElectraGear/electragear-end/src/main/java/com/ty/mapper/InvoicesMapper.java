package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.Invoices;


public interface InvoicesMapper extends BaseMapper<Invoices> {
}
