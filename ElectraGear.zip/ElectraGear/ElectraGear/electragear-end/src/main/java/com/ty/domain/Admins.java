package com.ty.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ty.domain.web.BaseEntity;

import lombok.Data;


@TableName(value = "admins")
@Data
public class Admins {
    private static final long serialVersionUID = 1L;


    @TableId(value="admin_id", type=IdType.AUTO)
    private Long adminId;


    private String adminName;
    
    private String password;


    private String adminEmail;


    private String adminPhone;
}
