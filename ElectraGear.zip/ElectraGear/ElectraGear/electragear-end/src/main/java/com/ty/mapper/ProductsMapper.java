package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.Products;


public interface ProductsMapper extends BaseMapper<Products> {
}
