package com.ty.service;

import java.util.List;

import com.ty.domain.CarTestDrive;

public interface ICarTestDriveService {

    public CarTestDrive selectCarTestDriveById(Integer id);


    public List<CarTestDrive> selectCarTestDriveList(CarTestDrive carTestDrive);


    public int insertCarTestDrive(CarTestDrive carTestDrive);

    public int updateCarTestDrive(CarTestDrive carTestDrive);

    public int deleteCarTestDriveById(Integer id);
}
