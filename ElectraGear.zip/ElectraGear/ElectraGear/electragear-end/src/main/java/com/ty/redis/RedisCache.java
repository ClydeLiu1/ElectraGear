package com.ty.redis;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.BoundSetOperations;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;


@SuppressWarnings(value = { "unchecked", "rawtypes" })
@Component
public class RedisCache {
	@Autowired
	public RedisTemplate redisTemplate;
	
	//@Value("${redis.bucket}")
    private String redisBuckey;


	public <T> ValueOperations<String, T> setCacheObject(String key, T value) {
		ValueOperations<String, T> operation = redisTemplate.opsForValue();
		String redisKey = redisKey(key);
		operation.set(redisKey, value);
		return operation;
	}

	public <T> ValueOperations<String, T> setCacheObject(String key, T value, Integer timeout, TimeUnit timeUnit) {
		ValueOperations<String, T> operation = redisTemplate.opsForValue();
		String redisKey = redisKey(key);
		operation.set(redisKey, value, timeout, timeUnit);
		return operation;
	}


	public <T> T getCacheObject(String key) {
		ValueOperations<String, T> operation = redisTemplate.opsForValue();
		String redisKey = redisKey(key);
		return operation.get(redisKey);
	}


	public void deleteObject(String key) {
		String redisKey = redisKey(key);
		redisTemplate.delete(redisKey);
	}

	public void deleteObject(Collection collection) {
		redisTemplate.delete(collection);
	}


	public <T> ListOperations<String, T> setCacheList(String key, List<T> dataList) {
		ListOperations listOperation = redisTemplate.opsForList();
		String redisKey = redisKey(key);
		if (null != dataList) {
			int size = dataList.size();
			for (int i = 0; i < size; i++) {
				listOperation.leftPush(redisKey, dataList.get(i));
			}
		}
		return listOperation;
	}

	public <T> List<T> getCacheList(String key) {
		List<T> dataList = new ArrayList<T>();
		ListOperations<String, T> listOperation = redisTemplate.opsForList();
		Long size = listOperation.size(key);
		String redisKey = redisKey(key);
		for (int i = 0; i < size; i++) {
			dataList.add(listOperation.index(redisKey, i));
		}
		return dataList;
	}


	public <T> BoundSetOperations<String, T> setCacheSet(String key, Set<T> dataSet) {
		String redisKey = redisKey(key);
		BoundSetOperations<String, T> setOperation = redisTemplate.boundSetOps(redisKey);
		Iterator<T> it = dataSet.iterator();
		
		while (it.hasNext()) {
			setOperation.add(it.next());
		}
		return setOperation;
	}


	public <T> Set<T> getCacheSet(String key) {
		Set<T> dataSet = new HashSet<T>();
		String redisKey = redisKey(key);
		BoundSetOperations<String, T> operation = redisTemplate.boundSetOps(redisKey);
		dataSet = operation.members();
		return dataSet;
	}

	public <T> HashOperations<String, String, T> setCacheMap(String key, Map<String, T> dataMap) {
		HashOperations hashOperations = redisTemplate.opsForHash();
		String redisKey = redisKey(key);
		if (null != dataMap) {
			for (Map.Entry<String, T> entry : dataMap.entrySet()) {
				hashOperations.put(redisKey, entry.getKey(), entry.getValue());
			}
		}
		return hashOperations;
	}


	public <T> Map<String, T> getCacheMap(String key) {
		String redisKey = redisKey(key);
		Map<String, T> map = redisTemplate.opsForHash().entries(redisKey);
		return map;
	}


	public Collection<String> keys(String pattern) {
		return redisTemplate.keys(pattern);
	}
	


	public boolean hasKey(String key) {
		String redisKey = redisKey(key);
		return redisTemplate.hasKey(redisKey);
	}


	public String redisKey(String key) {
		return DataDictUtil.getRedisBucket() + key;
	}
}
