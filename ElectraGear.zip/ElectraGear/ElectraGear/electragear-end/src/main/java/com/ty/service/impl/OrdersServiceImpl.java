package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ty.mapper.OrdersMapper;
import com.ty.domain.Invoices;
import com.ty.domain.OrderProduct;
import com.ty.domain.Orders;
import com.ty.domain.PaymentInfo;
import com.ty.domain.Products;
import com.ty.service.IInvoicesService;
import com.ty.service.IOrderProductService;
import com.ty.service.IOrdersService;
import com.ty.service.IPaymentInfoService;
import com.ty.service.IProductsService;
import com.ty.utils.DateUtils;

/**
 * 订单管理Service业务层处理
 * 
 * @author ty
 * @date 2024-05-01
 */
@Service
public class OrdersServiceImpl implements IOrdersService {
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private IProductsService productsService;
    @Autowired
    private IOrderProductService orderProductService;
    @Autowired
    private IPaymentInfoService paymentInfoService;
    @Autowired
    private IInvoicesService invoicesService;

    /**
     * 查询订单管理
     * 
     * @param orderId 订单管理ID
     * @return 订单管理
     */
    @Override
    public Orders selectOrdersById(Long orderId) {
        return ordersMapper.selectById(orderId);
    }

    /**
     * 查询订单管理列表
     * 
     * @param orders 订单管理
     * @return 订单管理
     */
    @Override
    public List<Orders> selectOrdersList(Orders orders) {
        return ordersMapper.selectOrdersList(orders);
    }

    /**
     * 新增订单管理
     * 
     * @param orders 订单管理
     * @return 结果
     */
    @Override
    @Transactional
    public int insertOrders(Orders orders) {
    	PaymentInfo info = new PaymentInfo();
    	info.setSecurityCode(orders.getSecurityCode());
    	info.setCardNumber(orders.getCardNumber());
    	info.setExpirationDate(orders.getExpirationDate());
    	info.setUserId(orders.getUserId());
    	paymentInfoService.insertPaymentInfo(info);
    	
    	orders.setOrderDate(DateUtils.getNowDate());
    	orders.setPaymentInfoId(info.getPaymentInfoId());
    	int row = ordersMapper.insert(orders);
    	
    	Invoices invoices = new Invoices();
    	invoices.setInvoiceContent(orders.getInvoiceContent());
    	invoices.setInvoiceDate(orders.getInvoiceDate());
    	invoices.setOrderId(orders.getOrderId());
    	invoices.setUserId(orders.getUserId());
    	invoicesService.insertInvoices(invoices);
    	
    	if (orders.getProductsCartList() != null && orders.getProductsCartList().size() > 0) {
    		orders.getProductsCartList().forEach(item -> {
    			long productId = Long.parseLong(item.get("productId").toString());
    			int num = Integer.parseInt(item.get("num").toString());
    			Products products = productsService.selectProductsById(productId);
    	    	products.setStockQuantity(products.getStockQuantity() - num);
    	    	productsService.updateProducts(products);
    			
    			OrderProduct op = new OrderProduct();
    			op.setOrderId(orders.getOrderId());
    			op.setProductId(productId);
    			op.setCreateTime(new Date());
    			op.setNum(num);
    			orderProductService.insertOrders(op);
    		});
    	}
        return row;
    }

    /**
     * 修改订单管理
     * 
     * @param orders 订单管理
     * @return 结果
     */
    @Override
    public int updateOrders(Orders orders) {
        return ordersMapper.updateById(orders);
    }

    /**
     * 批量删除订单管理
     * 
     * @param orderIds 需要删除的订单管理ID
     * @return 结果
     */
    @Override
    public int deleteOrdersByIds(Long[] orderIds) {
    	List<Long> idList = new ArrayList<>(Arrays.asList(orderIds));
        return ordersMapper.deleteBatchIds(idList);
    }

    /**
     * 删除订单管理信息
     * 
     * @param orderId 订单管理ID
     * @return 结果
     */
    @Override
    public int deleteOrdersById(Long orderId) {
        return ordersMapper.deleteById(orderId);
    }
}
