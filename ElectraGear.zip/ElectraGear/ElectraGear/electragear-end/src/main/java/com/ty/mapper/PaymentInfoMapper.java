package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.PaymentInfo;


public interface PaymentInfoMapper extends BaseMapper<PaymentInfo> {
}
