package com.ty.service;

import java.util.List;

import com.ty.domain.CarOrderInfo;


public interface ICarOrderInfoService {

    public CarOrderInfo selectCarOrderInfoById(Integer id);


    public List<CarOrderInfo> selectCarOrderInfoList(CarOrderInfo carOrderInfo);


    public int insertCarOrderInfo(CarOrderInfo carOrderInfo);

    public int updateCarOrderInfo(CarOrderInfo carOrderInfo);


    public int deleteCarOrderInfoById(Integer id);
}
