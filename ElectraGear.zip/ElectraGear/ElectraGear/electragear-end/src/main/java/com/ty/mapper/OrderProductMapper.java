package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.OrderProduct;

public interface OrderProductMapper extends BaseMapper<OrderProduct> {
}
