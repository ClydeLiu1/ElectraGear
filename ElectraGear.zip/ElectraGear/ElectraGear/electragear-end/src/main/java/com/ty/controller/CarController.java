package com.ty.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ty.domain.Car;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.ICarService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 汽车信息管理Controller
 * 
 * @date 2024-04-11
 */
@RestController
@RequestMapping("/car")
@Api(tags = "汽车管理")
public class CarController extends BaseController {
    @Autowired
    private ICarService carService;

    /**
     * 查询汽车信息列表
     */
    @ApiOperation("汽车列表")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "pageNum", value = "页码", required = true, dataType = "Integer"),
        @ApiImplicitParam(name = "pageSize", value = "页容量", required = true, dataType = "Integer")})
    @GetMapping("/list")
    public TableDataInfo list(Car car) {
        startPage();
        List<Car> list = carService.selectCarList(car);
        return getDataTable(list);
    }

    /**
     * 获取汽车信息详细信息
     */
    @ApiOperation("根据id获取汽车信息")
    @ApiImplicitParam(name = "id", value = "id", required = true, dataType = "Integer")
    @GetMapping(value = "/getInfo/{id}")
    public AjaxResult getInfo(@PathVariable("id") Integer id) {
        return AjaxResult.success(carService.selectCarById(id));
    }

    /**
     * 新增汽车信息
     */
    @ApiOperation("新增汽车")
    @PostMapping("/add")
    public AjaxResult add(@RequestBody Car car) {
        return toAjax(carService.insertCar(car));
    }

    /**
     * 修改汽车信息
     */
    @ApiOperation("修改汽车")
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody Car car) {
        return toAjax(carService.updateCar(car));
    }

    /**
     * 删除汽车信息
     */
    @ApiOperation("删除记录")
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer")
	@DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Integer id) {
        return toAjax(carService.deleteCarById(id));
    }
    
    @PostMapping("upload")
    public AjaxResult upload(@RequestParam("file") MultipartFile file) {
        String dir = System.getProperty("user.dir");
        try {
            String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
            suffix = suffix.toLowerCase();
            File path = new File(dir, "image");
            if (!path.exists()) {
                path.mkdirs();
            }

            File uploadDir = new File(path, UUID.randomUUID().toString() + "." + suffix);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            file.transferTo(uploadDir);
            System.out.println();
            return AjaxResult.success("上传成功", uploadDir.getAbsolutePath());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return AjaxResult.error("上传失败");
    }
}
