package com.ty.service;

import java.util.List;
import com.ty.domain.Invoices;

public interface IInvoicesService {

    public Invoices selectInvoicesById(Long invoiceId);


    public List<Invoices> selectInvoicesList(Invoices invoices);

    public int insertInvoices(Invoices invoices);

    public int updateInvoices(Invoices invoices);

//    public int deleteInvoicesByIds(Long[] invoiceIds);

    public int deleteInvoicesById(Long invoiceId);
}
