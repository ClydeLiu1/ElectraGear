package com.ty.service;

import com.ty.domain.OrderProduct;

public interface IOrderProductService {
	
	public int deleteOrdersById(Long orderId);
	
	
	 public int deleteByIds(Long[] orderIds);
	 
	 public int insertOrders(OrderProduct orderProduct);

}
