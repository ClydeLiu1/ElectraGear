package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.Orders;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IOrdersService;

import cn.hutool.poi.excel.ExcelUtil;
import lombok.extern.java.Log;

/**
 * 订单管理Controller
 * 
 * @author ty
 * @date 2024-05-01
 */
@RestController
@RequestMapping("/orders")
public class OrdersController extends BaseController {
    @Autowired
    private IOrdersService ordersService;

    /**
     * 查询订单管理列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Orders orders) {
        startPage();
        List<Orders> list = ordersService.selectOrdersList(orders);
        return getDataTable(list);
    }

    /**
     * 获取订单管理详细信息
     */
    @GetMapping(value = "/{orderId}")
    public AjaxResult getInfo(@PathVariable("orderId") Long orderId) {
        return AjaxResult.success(ordersService.selectOrdersById(orderId));
    }

    /**
     * 新增订单管理
     */
    @PostMapping
    public AjaxResult add(@RequestBody Orders orders) {
        return toAjax(ordersService.insertOrders(orders));
    }

    /**
     * 修改订单管理
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Orders orders) {
        return toAjax(ordersService.updateOrders(orders));
    }

    /**
     * 删除订单管理
     */
	@DeleteMapping("/{orderIds}")
    public AjaxResult remove(@PathVariable Long[] orderIds) {
        return toAjax(ordersService.deleteOrdersByIds(orderIds));
    }
}
