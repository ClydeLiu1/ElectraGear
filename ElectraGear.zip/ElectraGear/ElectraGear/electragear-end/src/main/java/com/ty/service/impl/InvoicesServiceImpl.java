package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ty.domain.Invoices;
import com.ty.mapper.InvoicesMapper;
import com.ty.service.IInvoicesService;

/**
 * 发票管理Service业务层处理
 * 
 * @author ty
 * @date 2024-05-07
 */
@Service
public class InvoicesServiceImpl implements IInvoicesService {
    @Autowired
    private InvoicesMapper invoicesMapper;

    /**
     * 查询发票管理
     * 
     * @param invoiceId 发票管理ID
     * @return 发票管理
     */
    @Override
    public Invoices selectInvoicesById(Long invoiceId) {
        return invoicesMapper.selectById(invoiceId);
    }

    /**
     * 查询发票管理列表
     * 
     * @param invoices 发票管理
     * @return 发票管理
     */
    @Override
    public List<Invoices> selectInvoicesList(Invoices invoices) {
    	QueryWrapper<Invoices> wrapper = new QueryWrapper<>(invoices);
        return invoicesMapper.selectList(wrapper);
    }

    /**
     * 新增发票管理
     * 
     * @param invoices 发票管理
     * @return 结果
     */
    @Override
    public int insertInvoices(Invoices invoices) {
        return invoicesMapper.insert(invoices);
    }

    /**
     * 修改发票管理
     * 
     * @param invoices 发票管理
     * @return 结果
     */
    @Override
    public int updateInvoices(Invoices invoices) {
        return invoicesMapper.updateById(invoices);
    }

    /**
     * 批量删除发票管理
     * 
     * @param invoiceIds 需要删除的发票管理ID
     * @return 结果
     */
//    @Override
//    public int deleteInvoicesByIds(Long[] invoiceIds) {
//    	List<Long> idList = new ArrayList<>(Arrays.asList(invoiceIds));
//        return invoicesMapper.deleteBatchIds(idList);
//    }

    /**
     * 删除发票管理信息
     * 
     * @param invoiceId 发票管理ID
     * @return 结果
     */
    @Override
    public int deleteInvoicesById(Long invoiceId) {
        return invoicesMapper.deleteById(invoiceId);
    }
}
