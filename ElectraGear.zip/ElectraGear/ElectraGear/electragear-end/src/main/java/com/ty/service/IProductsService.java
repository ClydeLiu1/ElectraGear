package com.ty.service;

import java.util.List;

import com.ty.domain.Products;


public interface IProductsService {

    public Products selectProductsById(Long productId);


    public List<Products> selectProductsList(Products products);


    public int insertProducts(Products products);

    public int updateProducts(Products products);

    public int deleteProductsByIds(Long[] productIds);

    public int deleteProductsById(Long productId);
}
