package com.ty.utils;

import org.springframework.stereotype.Service;
import com.alibaba.fastjson.JSONObject;


@Service
public class MessageUtil {

	public static Messages getSuccessMessage() {
		Messages message = new Messages();
		message.setCode(Messages.SUCCESS);
		return message;
	}



	public static Messages getErrorDebugInfoMessage(String debugInfoFieldName) {
		Messages message = new Messages();
		message.setCode(Messages.FAILURE);
		return message;
	}


	public static Messages getSuccessMsg(String msg) {
		Messages message = new Messages();
		message.setCode(Messages.SUCCESS);
		message.setMsg(msg);
		return message;
	}

	public static Messages getErrorMsg(String msg) {
		Messages message = new Messages();
		message.setCode(Messages.FAILURE);
		message.setMsg(msg);
		return message;
	}
	

	public static Messages getSuccessMsg(JSONObject data) {
		Messages message = new Messages();
		message.setCode(Messages.SUCCESS);
		message.setData(data);
		return message;
	}
}
