//package com.ty.config;
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.Ordered;
//
//import com.ty.interceptor.TokenInterceptor;
//
//@Configuration
//public class WebConfig {
//
//	@Bean
//    public FilterRegistrationBean<TokenInterceptor> tokenFilterRegistration() {
//        FilterRegistrationBean<TokenInterceptor> registrationBean = new FilterRegistrationBean<>();
//        registrationBean.setFilter(new TokenInterceptor());
//        registrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE)
//        registrationBean.addUrlPatterns("/car/*");
//        registrationBean.addUrlPatterns("/user/*");
//        return registrationBean;
//    }
//}
