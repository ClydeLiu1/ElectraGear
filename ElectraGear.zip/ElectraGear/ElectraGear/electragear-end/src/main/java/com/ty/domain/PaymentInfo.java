package com.ty.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**payment_info
 * 

 */
@TableName(value = "payment_info")
@Data
public class PaymentInfo {
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    @TableId(value="payment_info_id", type=IdType.AUTO)
    private Long paymentInfoId;


    private Long userId;


    private String cardType;


    private String cardNumber;


    private String expirationDate;

    private String securityCode;



}
