package com.ty.service;

import java.util.List;
import com.ty.domain.PaymentInfo;


public interface IPaymentInfoService {

    public PaymentInfo selectPaymentInfoById(Long paymentInfoId);


    public List<PaymentInfo> selectPaymentInfoList(PaymentInfo paymentInfo);


    public int insertPaymentInfo(PaymentInfo paymentInfo);


    public int updatePaymentInfo(PaymentInfo paymentInfo);


//    public int deletePaymentInfoByIds(Long[] paymentInfoIds);


    public int deletePaymentInfoById(Long paymentInfoId);
}
