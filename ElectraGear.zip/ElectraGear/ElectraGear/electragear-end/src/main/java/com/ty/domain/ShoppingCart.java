package com.ty.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ty.domain.web.BaseEntity;

import lombok.Data;

/**
 * 购物车管理对象 shopping_cart
 * 
 *
 */
@TableName(value = "shopping_cart")
@Data
public class ShoppingCart {
    private static final long serialVersionUID = 1L;


    private Integer quantity;


    private Long productId;


    private Integer userId;


    @TableId(value="cart_id", type=IdType.AUTO)
    private Integer cartId;
    
    private transient Products products;

}
