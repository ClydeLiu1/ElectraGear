package com.ty.service;

import java.util.List;
import com.ty.domain.Admins;
import com.ty.domain.web.AjaxResult;


public interface IAdminsService {

    public Admins selectAdminsById(Long adminId);


    public List<Admins> selectAdminsList(Admins admins);

    public int insertAdmins(Admins admins);


    public int updateAdmins(Admins admins);


    public int deleteAdminsByIds(Long[] adminIds);


    public int deleteAdminsById(Long adminId);
    
    public AjaxResult login(String adminName, String password);
}
