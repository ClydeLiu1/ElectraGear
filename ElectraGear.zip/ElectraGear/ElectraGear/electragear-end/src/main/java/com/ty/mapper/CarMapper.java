package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.Car;


public interface CarMapper extends BaseMapper<Car> {
}
