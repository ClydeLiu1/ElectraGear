package com.ty.service;

import java.util.List;
import com.ty.domain.Orders;


public interface IOrdersService {

    public Orders selectOrdersById(Long orderId);


    public List<Orders> selectOrdersList(Orders orders);

    public int insertOrders(Orders orders);

    public int updateOrders(Orders orders);

    public int deleteOrdersByIds(Long[] orderIds);

    public int deleteOrdersById(Long orderId);
}
