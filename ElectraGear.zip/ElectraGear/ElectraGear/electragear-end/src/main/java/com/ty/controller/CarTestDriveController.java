package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.CarTestDrive;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.ICarTestDriveService;

import cn.hutool.poi.excel.ExcelUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 预约试驾管理Controller
 * 
 * @date 2024-04-11
 */
@RestController
@RequestMapping("/testDrive")
@Api(tags = "预约试驾管理")
public class CarTestDriveController extends BaseController {
    @Autowired
    private ICarTestDriveService carTestDriveService;

    /**
     * 查询预约试驾管理列表
     */
    @ApiOperation("预约试驾列表")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "pageNum", value = "页码", required = true, dataType = "Integer"),
        @ApiImplicitParam(name = "pageSize", value = "页容量", required = true, dataType = "Integer")})
    @GetMapping(value = "/list")
    public TableDataInfo list(CarTestDrive carTestDrive) {
        startPage();
        List<CarTestDrive> list = carTestDriveService.selectCarTestDriveList(carTestDrive);
        return getDataTable(list);
    }

    /**
     * 获取预约试驾管理详细信息
     */
    @ApiOperation("获取预约试驾管理详细信息")
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer")
    @GetMapping(value = "/getInfo/{id}")
    public AjaxResult getInfo(@PathVariable("id") Integer id) {
        return AjaxResult.success(carTestDriveService.selectCarTestDriveById(id));
    }

    /**
     * 新增预约试驾管理
     */
    @ApiOperation("新增预约试驾")
    @PostMapping("/add")
    public AjaxResult add(@RequestBody CarTestDrive carTestDrive) {
        return toAjax(carTestDriveService.insertCarTestDrive(carTestDrive));
    }

    /**
     * 修改预约试驾管理
     */
    @ApiOperation("修改预约试驾")
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody CarTestDrive carTestDrive) {
        return toAjax(carTestDriveService.updateCarTestDrive(carTestDrive));
    }

    /**
     * 删除预约试驾管理
     */
    @ApiOperation("删除记录")
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer")
	@DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Integer id) {
        return toAjax(carTestDriveService.deleteCarTestDriveById(id));
    }
}
