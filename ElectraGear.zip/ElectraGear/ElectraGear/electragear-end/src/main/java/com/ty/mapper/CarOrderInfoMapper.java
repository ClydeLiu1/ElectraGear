package com.ty.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.CarOrderInfo;


public interface CarOrderInfoMapper extends BaseMapper<CarOrderInfo> {
	
	public List<CarOrderInfo> selectCarOrderInfoList(CarOrderInfo carOrderInfo);
	
	public CarOrderInfo selectCarOrderInfoById(Integer id);
	
}
