package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.User;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IUsersService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * User Management Controller
 * 
 * @date 2024-04-11
 */
@Api(tags = "User Management")
@RestController
@RequestMapping("/user")
public class UserController extends BaseController {
    @Autowired
    private IUsersService userService;


    @ApiOperation("UserList")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "pageNum", value = "page number", required = true, dataType = "Integer"),
        @ApiImplicitParam(name = "pageSize", value = "Page capacity", required = true, dataType = "Integer")})
    @GetMapping(value = "/list")
    public TableDataInfo list(User user) {
        startPage();
        List<User> list = userService.selectUserList(user);
        return getDataTable(list);
    }



    @ApiOperation("Get user information based on user id")
    @ApiImplicitParam(name = "id", value = "UserId", required = true, dataType = "Integer")
    @GetMapping(value = "/getInfo/{id}")
    public AjaxResult getInfo(@PathVariable("id") Integer id) {
        return AjaxResult.success(userService.selectUserById(id));
    }


    @ApiOperation("addUser")
    @PostMapping("/add")
    public AjaxResult add(@RequestBody User user) {
        return toAjax(userService.insertUser(user));
    }


    @ApiOperation("changeUser")
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody User user) {
        return toAjax(userService.updateUser(user));
    }


    @ApiOperation("DeleteUser")
    @ApiImplicitParam(name = "id", value = "Userid", required = true, dataType = "Integer")
	@DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Integer id) {
        return toAjax(userService.deleteUserById(id));
    }

    @ApiOperation("UpdatePassword")
    @PostMapping("/updatePwd")
    public AjaxResult add(Integer userId, String password, String oldPassword) {
    	return userService.updatePwd(userId, password, oldPassword);
    }
}
