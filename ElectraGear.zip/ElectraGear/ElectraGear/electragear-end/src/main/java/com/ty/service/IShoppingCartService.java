package com.ty.service;

import java.util.List;
import com.ty.domain.ShoppingCart;


public interface IShoppingCartService {

    public ShoppingCart selectShoppingCartById(Integer cartId);


    public List<ShoppingCart> selectShoppingCartList(ShoppingCart shoppingCart);


    public int insertShoppingCart(ShoppingCart shoppingCart);

    public int updateShoppingCart(ShoppingCart shoppingCart);

//    public int deleteShoppingCartByIds(Integer[] cartIds);


    public int deleteShoppingCartById(Integer cartId);
    
    public Integer getNumByUserId(ShoppingCart shoppingCart);
}
