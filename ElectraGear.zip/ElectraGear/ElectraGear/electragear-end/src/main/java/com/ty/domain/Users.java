package com.ty.domain;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ty.domain.web.BaseEntity;

import lombok.Data;

/**
 *  users
 *
 */
@TableName(value = "users")
@Data
public class Users{
    private static final long serialVersionUID = 1L;

    
    @TableId(value="user_id", type=IdType.AUTO)
    private Long userId;

    
    private String username;

    
    private String password;

    
    private String email;

    
    private String phone;

    
    private String address;

    
    private Integer isMember;

    
    private Double memberDiscount;

    
    private Date registrationDate;

}
