package com.ty.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ty.domain.web.AjaxResult;
import com.ty.service.IAdminsService;
import com.ty.service.IUsersService;
import io.swagger.annotations.Api;

/**
 * 登录
 * 
 * @date 2024-04-11
 */
@RestController
@Api(tags = "登录")
public class LoginController {
	@Autowired
	private IUsersService userService;
	
	@Autowired
	private IAdminsService adminsService;
	 /**
     * 登录方法
     * @return 结果
     */
    @PostMapping("/login")
    public AjaxResult login(String username, String password)
    {
        return userService.login(username, password);
    }
    
    
    /**
     * 登录方法
     * @return 结果
     */
    @PostMapping("/admins/login")
    public AjaxResult adminLogin(String username, String password)
    {
        return adminsService.login(username, password);
    }
}
