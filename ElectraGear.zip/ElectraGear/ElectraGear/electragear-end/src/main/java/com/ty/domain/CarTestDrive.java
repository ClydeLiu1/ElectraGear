package com.ty.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;

import java.sql.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * car_test_drive
 * 
 *
 */
@TableName(value = "car_test_drive")
@Data
public class CarTestDrive {
    private static final long serialVersionUID = 1L;


    @TableId(value="id", type=IdType.AUTO)
    private Integer id;


    private Integer userId;


    private Integer carId;
    

    private Date createTime;
    
    private transient String carName;
    private transient String carType;
    private transient String nickName;
    private transient String mobile;
    
    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("userId", getUserId())
            .append("carId", getCarId())
            .toString();
    }

}
