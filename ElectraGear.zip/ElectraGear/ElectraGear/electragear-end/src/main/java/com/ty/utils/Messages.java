package com.ty.utils;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;


@JsonInclude(Include.NON_NULL)
@Data
public class Messages {
  
  static final int SUCCESS = 0;
  static final int FAILURE = 1;

  public static final int SYSTEM_MAINTENANCE_MODE = 3;

  private int code;
  private JSONObject data;
  private String msg;
  private String debugInfo;

}
