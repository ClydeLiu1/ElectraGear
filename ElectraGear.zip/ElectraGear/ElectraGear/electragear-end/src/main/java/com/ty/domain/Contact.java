package com.ty.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;

/**
 * contact
 *
 */
@TableName(value = "contact")
@Data
public class Contact {
    private static final long serialVersionUID = 1L;

    private Long userId;

    private Date replyTime;

    private String reply;

    private String message;

    private String phone;

    private String email;

    @TableId(value="contact_id", type=IdType.AUTO)
    private Integer contactId;
    
    private Date createTime;

}
