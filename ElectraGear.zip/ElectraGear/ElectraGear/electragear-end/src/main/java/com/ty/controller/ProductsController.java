package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.Products;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IProductsService;


/**
 * 商品管理Controller
 * 
 * @author ty
 * @date 2024-05-01
 */
@RestController
@RequestMapping("/products")
public class ProductsController extends BaseController {
    @Autowired
    private IProductsService productsService;

    /**
     * 查询商品管理列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Products products) {
        startPage();
        List<Products> list = productsService.selectProductsList(products);
        return getDataTable(list);
    }

    /**
     * 导出商品管理列表
     */
//    @GetMapping("/export")
//    public AjaxResult export(Products products) {
//        List<Products> list = productsService.selectProductsList(products);
//        ExcelUtil<Products> util = new ExcelUtil<Products>(Products.class);
//        return util.exportExcel(list, "products");
//    }

    /**
     * 获取商品管理详细信息
     */
    @GetMapping(value = "/{productId}")
    public AjaxResult getInfo(@PathVariable("productId") Long productId) {
        return AjaxResult.success(productsService.selectProductsById(productId));
    }

    /**
     * 新增商品管理
     */
    @PostMapping
    public AjaxResult add(@RequestBody Products products) {
        return toAjax(productsService.insertProducts(products));
    }

    /**
     * 修改商品管理
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Products products) {
        return toAjax(productsService.updateProducts(products));
    }

    /**
     * 删除商品管理
     */
	@DeleteMapping("/{productIds}")
    public AjaxResult remove(@PathVariable Long[] productIds) {
        return toAjax(productsService.deleteProductsByIds(productIds));
    }
}
