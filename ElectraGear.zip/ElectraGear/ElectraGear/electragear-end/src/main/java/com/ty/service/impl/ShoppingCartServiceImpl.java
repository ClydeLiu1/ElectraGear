package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ty.domain.Products;
import com.ty.domain.ShoppingCart;
import com.ty.mapper.ShoppingCartMapper;
import com.ty.service.IProductsService;
import com.ty.service.IShoppingCartService;

/**
 * 购物车管理Service业务层处理
 * 
 * 
 * @date 2024-05-06
 */
@Service
public class ShoppingCartServiceImpl implements IShoppingCartService {
    @Autowired
    private ShoppingCartMapper shoppingCartMapper;
    
    @Autowired
    private IProductsService productsService;

    /**
     * 查询购物车管理
     * 
     * @param cartId 购物车管理ID
     * @return 购物车管理
     */
    @Override
    public ShoppingCart selectShoppingCartById(Integer cartId) {
        return shoppingCartMapper.selectById(cartId);
    }

    /**
     * 查询购物车管理列表
     * 
     * @param shoppingCart 购物车管理
     * @return 购物车管理
     */
    @Override
    public List<ShoppingCart> selectShoppingCartList(ShoppingCart shoppingCart) {
    	QueryWrapper<ShoppingCart> wrapper = new QueryWrapper<>(shoppingCart);
    	List<ShoppingCart> datas = shoppingCartMapper.selectList(wrapper);
    	datas.forEach(cart -> {
    		Products product = productsService.selectProductsById(cart.getProductId());
    		cart.setProducts(product);
    	});
        return datas;
    }

    /**
     * 新增购物车管理
     * 
     * @param shoppingCart 购物车管理
     * @return 结果
     */
    @Override
    public int insertShoppingCart(ShoppingCart shoppingCart) {
    	QueryWrapper<ShoppingCart> wrapper = new QueryWrapper<>();
    	wrapper.eq("user_id", shoppingCart.getUserId());
    	wrapper.eq("product_id", shoppingCart.getProductId());
    	ShoppingCart cart = shoppingCartMapper.selectOne(wrapper);
    	if (cart != null) {
    		cart.setQuantity(cart.getQuantity() + shoppingCart.getQuantity());
    		return shoppingCartMapper.updateById(cart);
    	} else {
    		 return shoppingCartMapper.insert(shoppingCart);
    	}
       
    }

    /**
     * 修改购物车管理
     * 
     * @param shoppingCart 购物车管理
     * @return 结果
     */
    @Override
    public int updateShoppingCart(ShoppingCart shoppingCart) {
        return shoppingCartMapper.updateById(shoppingCart);
    }

    /**
     * 批量删除购物车管理
     * 
     * @param cartIds 需要删除的购物车管理ID
     * @return 结果
     */
//    @Override
//    public int deleteShoppingCartByIds(Integer[] cartIds) {
//    	List<Long> idList = new ArrayList<>(Arrays.asList(cartIds));
//        return shoppingCartMapper.deleteBatchIds(idList);
//    }

    /**
     * 删除购物车管理信息
     * 
     * @param cartId 购物车管理ID
     * @return 结果
     */
    @Override
    public int deleteShoppingCartById(Integer cartId) {
        return shoppingCartMapper.deleteById(cartId);
    }
    
    public Integer getNumByUserId(ShoppingCart shoppingCart) {
    	if (shoppingCart == null || shoppingCart.getUserId() == null) {
    		return 0;
    	}
    	Integer count = shoppingCartMapper.getNumByUserId(shoppingCart.getUserId());
    	return count;
    }
}
