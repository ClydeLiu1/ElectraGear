package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.Contact;


public interface ContactMapper extends BaseMapper<Contact> {
}
