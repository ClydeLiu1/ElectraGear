package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.Admins;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IAdminsService;

import cn.hutool.poi.excel.ExcelUtil;
import lombok.extern.java.Log;

/**
 * 管理员信息管理Controller
 * 
 * @author ty
 * @date 2024-04-30
 */
@RestController
@RequestMapping("/ty/admins")
public class AdminsController extends BaseController {
    @Autowired
    private IAdminsService adminsService;

    /**
     * 查询管理员信息管理列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Admins admins) {
        startPage();
        List<Admins> list = adminsService.selectAdminsList(admins);
        return getDataTable(list);
    }

    /**
     * 获取管理员信息管理详细信息
     */
    @GetMapping(value = "/{adminId}")
    public AjaxResult getInfo(@PathVariable("adminId") Long adminId) {
        return AjaxResult.success(adminsService.selectAdminsById(adminId));
    }

    /**
     * 新增管理员信息管理
     */
    @PostMapping
    public AjaxResult add(@RequestBody Admins admins) {
        return toAjax(adminsService.insertAdmins(admins));
    }

    /**
     * 修改管理员信息管理
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Admins admins) {
        return toAjax(adminsService.updateAdmins(admins));
    }

    /**
     * 删除管理员信息管理
     */
	@DeleteMapping("/{adminIds}")
    public AjaxResult remove(@PathVariable Long[] adminIds) {
        return toAjax(adminsService.deleteAdminsByIds(adminIds));
    }
}
