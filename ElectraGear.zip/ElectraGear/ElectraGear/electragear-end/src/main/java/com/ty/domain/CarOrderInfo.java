package com.ty.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 *  car_order_info
 * 
 *
 */
@TableName(value = "car_order_info")
@Data
public class CarOrderInfo {
    private static final long serialVersionUID = 1L;


    @TableId(value="id", type=IdType.AUTO)
    private Integer id;


    private Long userId;


    private Long carId;


    private Long price;


    private String orderTime;

    private transient String carName;
    private transient String carType;
    private transient String nickName;
    private transient String mobile;
   

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("userId", getUserId())
            .append("carId", getCarId())
            .append("price", getPrice())
            .append("orderTime", getOrderTime())
            .toString();
    }

}
