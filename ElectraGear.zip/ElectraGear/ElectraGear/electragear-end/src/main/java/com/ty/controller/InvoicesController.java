package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.Invoices;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IInvoicesService;

import cn.hutool.poi.excel.ExcelUtil;
import lombok.extern.java.Log;

/**
 * 发票管理Controller
 * 
 * @author ty
 * @date 2024-05-07
 */
@RestController
@RequestMapping("/ty/发票管理")
public class InvoicesController extends BaseController {
    @Autowired
    private IInvoicesService invoicesService;

    /**
     * 查询发票管理列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Invoices invoices) {
        startPage();
        List<Invoices> list = invoicesService.selectInvoicesList(invoices);
        return getDataTable(list);
    }

    /**
     * 导出发票管理列表
     */
//    @GetMapping("/export")
//    public AjaxResult export(Invoices invoices) {
//        List<Invoices> list = invoicesService.selectInvoicesList(invoices);
//        ExcelUtil<Invoices> util = new ExcelUtil<Invoices>(Invoices.class);
//        return util.exportExcel(list, "发票管理");
//    }

    /**
     * 获取发票管理详细信息
     */
    @GetMapping(value = "/{invoiceId}")
    public AjaxResult getInfo(@PathVariable("invoiceId") Long invoiceId) {
        return AjaxResult.success(invoicesService.selectInvoicesById(invoiceId));
    }

    /**
     * 新增发票管理
     */
    @PostMapping
    public AjaxResult add(@RequestBody Invoices invoices) {
        return toAjax(invoicesService.insertInvoices(invoices));
    }

    /**
     * 修改发票管理
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Invoices invoices) {
        return toAjax(invoicesService.updateInvoices(invoices));
    }

    /**
     * 删除发票管理
     */
	@DeleteMapping("/{invoiceId}")
    public AjaxResult remove(@PathVariable Long invoiceId) {
        return toAjax(invoicesService.deleteInvoicesById(invoiceId));
    }
}
