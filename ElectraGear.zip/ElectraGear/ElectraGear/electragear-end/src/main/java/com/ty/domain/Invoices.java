package com.ty.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 *  invoices
 * 
 * @author ty
 * @date 2024-05-07
 */
@TableName(value = "invoices")
public class Invoices {
    private static final long serialVersionUID = 1L;


    @TableId(value="invoice_id", type=IdType.AUTO)
    private Long invoiceId;


    private Long userId;


    private Long orderId;


    private String invoiceContent;


    private Date invoiceDate;


    public void setInvoiceId(Long invoiceId) 
    {
        this.invoiceId = invoiceId;
    }

    public Long getInvoiceId() 
    {
        return invoiceId;
    }
    public void setUserId(Long userId) 
    {
        this.userId = userId;
    }

    public Long getUserId() 
    {
        return userId;
    }
    public void setOrderId(Long orderId) 
    {
        this.orderId = orderId;
    }

    public Long getOrderId() 
    {
        return orderId;
    }
    public void setInvoiceContent(String invoiceContent) 
    {
        this.invoiceContent = invoiceContent;
    }

    public String getInvoiceContent() 
    {
        return invoiceContent;
    }
    public void setInvoiceDate(Date invoiceDate) 
    {
        this.invoiceDate = invoiceDate;
    }

    public Date getInvoiceDate() 
    {
        return invoiceDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("invoiceId", getInvoiceId())
            .append("userId", getUserId())
            .append("orderId", getOrderId())
            .append("invoiceContent", getInvoiceContent())
            .append("invoiceDate", getInvoiceDate())
            .toString();
    }

}
