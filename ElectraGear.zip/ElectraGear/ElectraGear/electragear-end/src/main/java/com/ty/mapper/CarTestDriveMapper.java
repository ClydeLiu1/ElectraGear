package com.ty.mapper;

import java.util.List;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.CarTestDrive;


public interface CarTestDriveMapper extends BaseMapper<CarTestDrive> {
	
	public List<CarTestDrive> selectCarTestDriveList(CarTestDrive carTestDrive);
	
	public CarTestDrive selectCarTestDriveById(Integer id);
}
