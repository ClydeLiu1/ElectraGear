package com.ty.interceptor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.ty.domain.web.AjaxResult;
import com.ty.redis.RedisCache;
import com.ty.utils.ServletUtils;

@Configuration
public class UserHandlerInterceptor extends HandlerInterceptorAdapter {

	

	@Autowired
	private RedisCache redisCache;
	
	private static final String[] IGNORE_URL = {"/login", "/user/add","/swagger-resources/**", "/swagger-ui.html", "/static/**",
			"/*.html", "/**/*.html", "/**/*.css", "/**/*.js"};

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
		String url=request.getRequestURL().toString();
		if (url.contains(".html")) {
			return true;
		}
		for(String s : IGNORE_URL){
			if(url.indexOf(s) != -1){
				return true;
			}
		}
		String token = request.getHeader("Authorization");
		String username = request.getHeader("username");
		System.out.println(token);
		
		if (StringUtils.isNotEmpty(token) && StringUtils.isNotEmpty(username)) {
			String key = "login_" + username;
			if (redisCache.hasKey(key)) {
				Object cacheToken = redisCache.getCacheObject("login_" + username);
				if (token.equals(cacheToken)) {
					return true;
				}
			}
			
		}
		this.handleNotType(request, response, handler);
		return false;
    }
    
    protected void handleNotType(HttpServletRequest request, HttpServletResponse response, Object handler)
  	      throws ServletException, IOException{
    	String msg = String.format("The request parameters are incomplete", request.getRequestURI());
		ServletUtils.renderString(response, JSON.toJSONString(AjaxResult.error(1, msg)));
    }
}
