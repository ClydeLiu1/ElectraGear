package com.ty.controller;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ty.domain.web.AjaxResult;

import cn.hutool.core.lang.UUID;

@RestController
@RequestMapping("/file")
public class FileController extends BaseController {
	
	@PostMapping("/upload")
    public AjaxResult upload(@RequestParam("file") MultipartFile file, @RequestParam Map<String, Object> data) {
		String dir = System.getProperty("user.dir");
		System.out.println("dir:" + dir);
        try {
                String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
               suffix = suffix.toLowerCase();
                 File path = new File(dir, "image");
                 if (!path.exists()) {
                         path.mkdirs();
         }
                
         File uploadDir = new File(path, UUID.randomUUID().toString() + "." + suffix);
         if (!uploadDir.exists()) {
        uploadDir.mkdirs();
         }
         file.transferTo(uploadDir);
                return AjaxResult.success(uploadDir.getAbsolutePath());
        } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }
        return AjaxResult.error("上传失败");
    }
	
}
