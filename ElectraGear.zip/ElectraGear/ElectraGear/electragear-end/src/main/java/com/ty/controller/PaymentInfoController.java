package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.PaymentInfo;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IPaymentInfoService;

import cn.hutool.poi.excel.ExcelUtil;
import lombok.extern.java.Log;

/**
 * 支付详情Controller
 * 
 * @author ty
 * @date 2024-05-07
 */
@RestController
@RequestMapping("/ty/支付详情管理")
public class PaymentInfoController extends BaseController {
    @Autowired
    private IPaymentInfoService paymentInfoService;

    /**
     * 查询支付详情列表
     */
    @GetMapping("/list")
    public TableDataInfo list(PaymentInfo paymentInfo) {
        startPage();
        List<PaymentInfo> list = paymentInfoService.selectPaymentInfoList(paymentInfo);
        return getDataTable(list);
    }

    /**
     * 导出支付详情列表
     */
//    @GetMapping("/export")
//    public AjaxResult export(PaymentInfo paymentInfo) {
//        List<PaymentInfo> list = paymentInfoService.selectPaymentInfoList(paymentInfo);
//        ExcelUtil<PaymentInfo> util = new ExcelUtil<PaymentInfo>(PaymentInfo.class);
//        return util.exportExcel(list, "支付详情管理");
//    }

    /**
     * 获取支付详情详细信息
     */
    @GetMapping(value = "/{paymentInfoId}")
    public AjaxResult getInfo(@PathVariable("paymentInfoId") Long paymentInfoId) {
        return AjaxResult.success(paymentInfoService.selectPaymentInfoById(paymentInfoId));
    }

    /**
     * 新增支付详情
     */
    @PostMapping
    public AjaxResult add(@RequestBody PaymentInfo paymentInfo) {
        return toAjax(paymentInfoService.insertPaymentInfo(paymentInfo));
    }

    /**
     * 修改支付详情
     */
    @PutMapping
    public AjaxResult edit(@RequestBody PaymentInfo paymentInfo) {
        return toAjax(paymentInfoService.updatePaymentInfo(paymentInfo));
    }

    /**
     * 删除支付详情
     */
	@DeleteMapping("/{paymentInfoId}")
    public AjaxResult remove(@PathVariable Long paymentInfoId) {
        return toAjax(paymentInfoService.deletePaymentInfoById(paymentInfoId));
    }
}
