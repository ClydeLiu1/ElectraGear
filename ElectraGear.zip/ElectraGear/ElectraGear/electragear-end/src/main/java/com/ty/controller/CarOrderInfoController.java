package com.ty.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ty.domain.CarOrderInfo;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.ICarOrderInfoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 汽车订购信息管理Controller
 * 
 * @date 2024-04-11
 */
@Api(tags = "汽车订购信息管理")
@RestController
@RequestMapping("/orderInfo")
public class CarOrderInfoController extends BaseController {
    @Autowired
    private ICarOrderInfoService carOrderInfoService;

    /**
     * 查询汽车订购信息列表
     */
    @ApiOperation("汽车订购信息列表")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "pageNum", value = "页码", required = true, dataType = "Integer"),
        @ApiImplicitParam(name = "pageSize", value = "页容量", required = true, dataType = "Integer")})
    @GetMapping("/list")
    public TableDataInfo list(CarOrderInfo carOrderInfo) {
        startPage();
        List<CarOrderInfo> list = carOrderInfoService.selectCarOrderInfoList(carOrderInfo);
        return getDataTable(list);
    }

    /**
     * 获取汽车订购信息详细信息
     */
    @ApiOperation("根据id获取订购详情")
    @ApiImplicitParam(name = "id", value = "用户id", required = true, dataType = "Integer")
    @GetMapping(value = "/getInfo/{id}")
    public AjaxResult getInfo(@PathVariable("id") Integer id) {
        return AjaxResult.success(carOrderInfoService.selectCarOrderInfoById(id));
    }

    /**
     * 新增汽车订购信息
     */
    @ApiOperation("新增订购信息")
    @PostMapping("/add")
    public AjaxResult add(@RequestBody CarOrderInfo carOrderInfo) {
        return toAjax(carOrderInfoService.insertCarOrderInfo(carOrderInfo));
    }

    /**
     * 修改汽车订购信息
     */
    @ApiOperation("修改订购信息")
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody CarOrderInfo carOrderInfo) {
        return toAjax(carOrderInfoService.updateCarOrderInfo(carOrderInfo));
    }

    /**
     * 删除汽车订购信息
     */
    @ApiOperation("删除记录")
    @ApiImplicitParam(name = "id", value = "主键id", required = true, dataType = "Integer")
	@DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Integer id) {
        return toAjax(carOrderInfoService.deleteCarOrderInfoById(id));
    }
}
