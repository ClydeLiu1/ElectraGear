package com.ty.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.User;


@Mapper
public interface UsersMapper extends BaseMapper<User> {
}
