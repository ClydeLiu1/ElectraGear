package com.ty.service;

import java.util.List;

import com.ty.domain.User;
import com.ty.domain.web.AjaxResult;

public interface IUsersService {

    public User selectUserById(Integer id);

    public List<User> selectUserList(User user);


    public int insertUser(User user);


    public int updateUser(User user);


    public int deleteUserByIds(Integer[] ids);


    public int deleteUserById(Integer id);
    

    public AjaxResult login(String username, String password);
    

    public AjaxResult updatePwd(Integer userId, String password, String oldPassword);
}
