package com.ty.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ty.domain.Products;
import com.ty.mapper.ProductsMapper;
import com.ty.service.IProductsService;
import com.ty.utils.Base64;
import com.ty.utils.StringUtils;

/**
 * 商品管理Service业务层处理
 * 
 * @author ty
 * @date 2024-05-01
 */
@Service
public class ProductsServiceImpl implements IProductsService {
    @Autowired
    private ProductsMapper productsMapper;

    /**
     * 查询商品管理
     * 
     * @param productId 商品管理ID
     * @return 商品管理
     */
    @Override
    public Products selectProductsById(Long productId) {
        Products record = productsMapper.selectById(productId);
        if (record != null) {
            String base64str;
			try {
				if (StringUtils.isNotEmpty(record.getImagePath())) {
    				base64str = Base64.encodeFileToBase64Binary(record.getImagePath());
    				record.setBase64str(base64str);
    			}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return record;
    }

    /**
     * 查询商品管理列表
     * 
     * @param products 商品管理
     * @return 商品管理
     */
    @Override
    public List<Products> selectProductsList(Products products) {
    	QueryWrapper<Products> wrapper = new QueryWrapper<>(products);
        List<Products> records = productsMapper.selectList(wrapper);
        records.forEach(record -> {
    		try {
    			String base64str;
				if (StringUtils.isNotEmpty(record.getImagePath())) {
    				base64str = Base64.encodeFileToBase64Binary(record.getImagePath());
    				record.setBase64str(base64str);
    			}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	});
        return records;
    }

    /**
     * 新增商品管理
     * 
     * @param products 商品管理
     * @return 结果
     */
    @Override
    public int insertProducts(Products products) {
        return productsMapper.insert(products);
    }

    /**
     * 修改商品管理
     * 
     * @param products 商品管理
     * @return 结果
     */
    @Override
    public int updateProducts(Products products) {
        return productsMapper.updateById(products);
    }

    /**
     * 批量删除商品管理
     * 
     * @param productIds 需要删除的商品管理ID
     * @return 结果
     */
    @Override
    public int deleteProductsByIds(Long[] productIds) {
    	List<Long> idList = new ArrayList<>(Arrays.asList(productIds));
        return productsMapper.deleteBatchIds(idList);
    }

    /**
     * 删除商品管理信息
     * 
     * @param productId 商品管理ID
     * @return 结果
     */
    @Override
    public int deleteProductsById(Long productId) {
        return productsMapper.deleteById(productId);
    }
}
