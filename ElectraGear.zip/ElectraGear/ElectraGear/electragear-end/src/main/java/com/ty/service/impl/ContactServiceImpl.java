package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ty.domain.Contact;
import com.ty.mapper.ContactMapper;
import com.ty.service.IContactService;
import com.ty.utils.DateUtils;

/**
 * 联系我们Service业务层处理
 * 
 * @author ty
 * @date 2024-05-21
 */
@Service
public class ContactServiceImpl implements IContactService {
    @Autowired
    private ContactMapper contactMapper;

    /**
     * 查询联系我们
     * 
     * @param contactId 联系我们ID
     * @return 联系我们
     */
    @Override
    public Contact selectContactById(Integer contactId) {
        return contactMapper.selectById(contactId);
    }

    /**
     * 查询联系我们列表
     * 
     * @param contact 联系我们
     * @return 联系我们
     */
    @Override
    public List<Contact> selectContactList(Contact contact) {
    	QueryWrapper<Contact> wrapper = new QueryWrapper<>(contact);
        return contactMapper.selectList(wrapper);
    }

    /**
     * 新增联系我们
     * 
     * @param contact 联系我们
     * @return 结果
     */
    @Override
    public int insertContact(Contact contact) {
        contact.setCreateTime(DateUtils.getNowDate());
        return contactMapper.insert(contact);
    }

    /**
     * 修改联系我们
     * 
     * @param contact 联系我们
     * @return 结果
     */
    @Override
    public int updateContact(Contact contact) {
    	contact.setReplyTime(DateUtils.getNowDate());
        return contactMapper.updateById(contact);
    }

    /**
     * 批量删除联系我们
     * 
     * @param contactIds 需要删除的联系我们ID
     * @return 结果
     */
    @Override
    public int deleteContactByIds(Long[] contactIds) {
    	List<Long> idList = new ArrayList<>(Arrays.asList(contactIds));
        return contactMapper.deleteBatchIds(idList);
    }

    /**
     * 删除联系我们信息
     * 
     * @param contactId 联系我们ID
     * @return 结果
     */
    @Override
    public int deleteContactById(Long contactId) {
        return contactMapper.deleteById(contactId);
    }
}
