package com.ty.utils;



public class Constants {

	public static final String WX_APPLET_ACCESS_TOKEN = "wx_applet_access_token:";
	
	
}

