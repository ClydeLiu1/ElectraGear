package com.ty.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.ty.domain.Car;
import com.ty.mapper.CarMapper;
import com.ty.service.ICarService;

/**
 * 汽车信息管理Service业务层处理
 * 
 * @date 2024-04-11
 */
@Service
public class CarServiceImpl implements ICarService {
    @Autowired
    private CarMapper carMapper;

    /**
     * 查询汽车信息管理
     * 
     * @param id 汽车信息管理ID
     * @return 汽车信息管理
     */
    @Override
    public Car selectCarById(Integer id) {
    	Car record = carMapper.selectById(id);
    	if (record != null) {
            String base64str;
			try {
				if (StringUtils.isNotEmpty(record.getImageUrl())) {
    				base64str = encodeFileToBase64Binary(record.getImageUrl());
    				record.setBase64str(base64str);
    			}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return record;
    }
    
    public String encodeFileToBase64Binary(String filePath) throws IOException {
        File file = new File(filePath);
        FileInputStream fileInputStreamReader = new FileInputStream(file);
        try {
            byte[] bytes = new byte[(int) file.length()];
            fileInputStreamReader.read(bytes);
            return Base64.getEncoder().encodeToString(bytes);
        } finally {
            fileInputStreamReader.close();
        }
    }

    /**
     * 查询汽车信息管理列表
     * 
     * @param car 汽车信息管理
     * @return 汽车信息管理
     */
    @Override
    public List<Car> selectCarList(Car car) {
    	QueryWrapper<Car> wrapper = new QueryWrapper<>();
    	if (StringUtils.isNotEmpty(car.getCarName())) {
    		wrapper.like("car_name", car.getCarName());
    	}
    	
    	if (StringUtils.isNotEmpty(car.getCarType())) {
    		wrapper.like("car_type", car.getCarType());
    	}
    	
    	List<Car> records = carMapper.selectList(wrapper);
    	records.forEach(record ->{
    		String base64str;
    		try {
    			if (StringUtils.isNotEmpty(record.getImageUrl())) {
    				base64str = encodeFileToBase64Binary(record.getImageUrl());
    				record.setBase64str(base64str);
    			}
    			
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	});
    	
        return records;
    }

    /**
     * 新增汽车信息管理
     * 
     * @param car 汽车信息管理
     * @return 结果
     */
    @Override
    public int insertCar(Car car) {
        return carMapper.insert(car);
    }

    /**
     * 修改汽车信息管理
     * 
     * @param car 汽车信息管理
     * @return 结果
     */
    @Override
    public int updateCar(Car car) {
        return carMapper.updateById(car);
    }

   

    /**
     * 删除汽车信息管理信息
     * 
     * @param id 汽车信息管理ID
     * @return 结果
     */
    @Override
    public int deleteCarById(Integer id) {
        return carMapper.deleteById(id);
    }
}
