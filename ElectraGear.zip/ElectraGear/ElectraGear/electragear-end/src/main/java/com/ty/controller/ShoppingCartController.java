package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.domain.ShoppingCart;
import com.ty.domain.web.AjaxResult;
import com.ty.page.TableDataInfo;
import com.ty.service.IProductsService;
import com.ty.service.IShoppingCartService;

/**
 *shopping cartController
 * 
 * 
 * @date 2024-05-06
 */
@RestController
@RequestMapping("/ty/cart")
public class ShoppingCartController extends BaseController {
    @Autowired
    private IShoppingCartService shoppingCartService;
   

    @GetMapping("/list")
    public AjaxResult list(ShoppingCart shoppingCart) {
        List<ShoppingCart> list = shoppingCartService.selectShoppingCartList(shoppingCart);
        return AjaxResult.success(list);
    }
    
    @GetMapping("/getCountByUserId")
    public AjaxResult getCountByUserId(ShoppingCart shoppingCart) {
    	Integer num = shoppingCartService.getNumByUserId(shoppingCart);
        return AjaxResult.success(num);
    }
    

    @GetMapping(value = "/{cartId}")
    public AjaxResult getInfo(@PathVariable("cartId") Integer cartId) {
        return AjaxResult.success(shoppingCartService.selectShoppingCartById(cartId));
    }


    @PostMapping
    public AjaxResult add(@RequestBody ShoppingCart shoppingCart) {
        return toAjax(shoppingCartService.insertShoppingCart(shoppingCart));
    }


    @PutMapping
    public AjaxResult edit(@RequestBody ShoppingCart shoppingCart) {
        return toAjax(shoppingCartService.updateShoppingCart(shoppingCart));
    }

	@DeleteMapping("/{cartId}")
    public AjaxResult remove(@PathVariable Integer cartId) {
        return toAjax(shoppingCartService.deleteShoppingCartById(cartId));
    }
}
