package com.ty.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.Admins;

public interface AdminsMapper extends BaseMapper<Admins> {
}
