package com.ty.service;

import java.util.List;
import com.ty.domain.Contact;


public interface IContactService {

    public Contact selectContactById(Integer contactId);


    public List<Contact> selectContactList(Contact contact);


    public int insertContact(Contact contact);

    public int updateContact(Contact contact);


    public int deleteContactByIds(Long[] contactIds);


    public int deleteContactById(Long contactId);
}
