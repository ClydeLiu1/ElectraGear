package com.ty.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@TableName(value = "order_product")
@Data
public class OrderProduct {
    private static final long serialVersionUID = 1L;

    private Long productId;

    private Long orderId;
    
    private Integer num;

    private Date createTime;


}
