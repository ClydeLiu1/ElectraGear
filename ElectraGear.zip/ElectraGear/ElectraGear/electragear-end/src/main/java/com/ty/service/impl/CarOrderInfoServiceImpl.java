package com.ty.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.domain.CarOrderInfo;
import com.ty.mapper.CarOrderInfoMapper;
import com.ty.service.ICarOrderInfoService;
import com.ty.utils.DateUtils;

/**
 * 汽车订购信息管理Service业务层处理
 * 
 * @date 2024-04-11
 */
@Service
public class CarOrderInfoServiceImpl implements ICarOrderInfoService {
    @Autowired
    private CarOrderInfoMapper carOrderInfoMapper;

    /**
     * 查询汽车订购信息管理
     * 
     * @param id 汽车订购信息管理ID
     * @return 汽车订购信息管理
     */
    @Override
    public CarOrderInfo selectCarOrderInfoById(Integer id) {
        return carOrderInfoMapper.selectCarOrderInfoById(id);
    }

    /**
     * 查询汽车订购信息管理列表
     * 
     * @param carOrderInfo 汽车订购信息管理
     * @return 汽车订购信息管理
     */
    @Override
    public List<CarOrderInfo> selectCarOrderInfoList(CarOrderInfo carOrderInfo) {
        return carOrderInfoMapper.selectCarOrderInfoList(carOrderInfo);
    }

    /**
     * 新增汽车订购信息管理
     * 
     * @param carOrderInfo 汽车订购信息管理
     * @return 结果
     */
    @Override
    public int insertCarOrderInfo(CarOrderInfo carOrderInfo) {
    	carOrderInfo.setOrderTime(DateUtils.getTime());
        return carOrderInfoMapper.insert(carOrderInfo);
    }

    /**
     * 修改汽车订购信息管理
     * 
     * @param carOrderInfo 汽车订购信息管理
     * @return 结果
     */
    @Override
    public int updateCarOrderInfo(CarOrderInfo carOrderInfo) {
        return carOrderInfoMapper.updateById(carOrderInfo);
    }


    /**
     * 删除汽车订购信息管理信息
     * 
     * @param id 汽车订购信息管理ID
     * @return 结果
     */
    @Override
    public int deleteCarOrderInfoById(Integer id) {
        return carOrderInfoMapper.deleteById(id);
    }
}
