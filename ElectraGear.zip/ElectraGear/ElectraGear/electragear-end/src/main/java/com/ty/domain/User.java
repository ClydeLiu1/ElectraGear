package com.ty.domain;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;

/**users
 * 
 * @author ty
 * @date 2024-04-30
 */
@TableName(value = "users")
@Data
public class User{
    private static final long serialVersionUID = 1L;

    
    @TableId(value="user_id", type=IdType.AUTO)
    private Long userId;

    
    private String username;

    
    private String password;

    
    private String email;

    
    private String phone;

    
    private String address;

    
    private Integer isMember;

    
    private Double memberDiscount;

    
    private Date registrationDate;

}
