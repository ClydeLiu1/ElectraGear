package com.ty.redis;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DataDictUtil {
  
  public static String getRedisBucket() {
	  return "asm" +":";
  }
}
