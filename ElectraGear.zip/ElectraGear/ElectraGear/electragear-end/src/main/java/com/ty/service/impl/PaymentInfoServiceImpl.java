package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ty.mapper.PaymentInfoMapper;
import com.ty.domain.PaymentInfo;
import com.ty.service.IPaymentInfoService;


@Service
public class PaymentInfoServiceImpl implements IPaymentInfoService {
    @Autowired
    private PaymentInfoMapper paymentInfoMapper;


    @Override
    public PaymentInfo selectPaymentInfoById(Long paymentInfoId) {
        return paymentInfoMapper.selectById(paymentInfoId);
    }


    @Override
    public List<PaymentInfo> selectPaymentInfoList(PaymentInfo paymentInfo) {
    	QueryWrapper<PaymentInfo> wrapper = new QueryWrapper<>(paymentInfo);
        return paymentInfoMapper.selectList(wrapper);
    }

    @Override
    public int insertPaymentInfo(PaymentInfo paymentInfo) {
        return paymentInfoMapper.insert(paymentInfo);
    }


    @Override
    public int updatePaymentInfo(PaymentInfo paymentInfo) {
        return paymentInfoMapper.updateById(paymentInfo);
    }


//    @Override
//    public int deletePaymentInfoByIds(Long[] paymentInfoIds) {
//    	List<Long> idList = new ArrayList<>(Arrays.asList(paymentInfoIds));
//        return paymentInfoMapper.deleteBatchIds(idList);
//    }


    @Override
    public int deletePaymentInfoById(Long paymentInfoId) {
        return paymentInfoMapper.deleteById(paymentInfoId);
    }
}
