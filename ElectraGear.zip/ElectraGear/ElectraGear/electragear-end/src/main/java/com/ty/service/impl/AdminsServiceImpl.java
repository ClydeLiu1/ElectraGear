package com.ty.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.stereotype.Service;
import com.ty.mapper.AdminsMapper;
import com.ty.redis.RedisCache;
import com.ty.domain.Admins;
import com.ty.domain.User;
import com.ty.domain.web.AjaxResult;
import com.ty.service.IAdminsService;
import com.ty.utils.Md5Utils;

import cn.hutool.core.lang.UUID;

/**
 * 管理员信息管理Service业务层处理
 * 
 * @author ty
 * @date 2024-04-30
 */
@Service
public class AdminsServiceImpl implements IAdminsService {
    @Autowired
    private AdminsMapper adminsMapper;
    
    @Autowired
    private RedisCache redisCache;

    /**
     * 查询管理员信息管理
     * 
     * @param adminId 管理员信息管理ID
     * @return 管理员信息管理
     */
    @Override
    public Admins selectAdminsById(Long adminId) {
        return adminsMapper.selectById(adminId);
    }

    /**
     * 查询管理员信息管理列表
     * 
     * @param admins 管理员信息管理
     * @return 管理员信息管理
     */
    @Override
    public List<Admins> selectAdminsList(Admins admins) {
    	QueryWrapper<Admins> wrapper = new QueryWrapper<>(admins);
        return adminsMapper.selectList(wrapper);
    }

    /**
     * 新增管理员信息管理
     * 
     * @param admins 管理员信息管理
     * @return 结果
     */
    @Override
    public int insertAdmins(Admins admins) {
        return adminsMapper.insert(admins);
    }

    /**
     * 修改管理员信息管理
     * 
     * @param admins 管理员信息管理
     * @return 结果
     */
    @Override
    public int updateAdmins(Admins admins) {
        return adminsMapper.updateById(admins);
    }

    /**
     * 批量删除管理员信息管理
     * 
     * @param adminIds 需要删除的管理员信息管理ID
     * @return 结果
     */
    @Override
    public int deleteAdminsByIds(Long[] adminIds) {
    	List<Long> idList = new ArrayList<>(Arrays.asList(adminIds));
        return adminsMapper.deleteBatchIds(idList);
    }

    /**
     * 删除管理员信息管理信息
     * 
     * @param adminId 管理员信息管理ID
     * @return 结果
     */
    @Override
    public int deleteAdminsById(Long adminId) {
        return adminsMapper.deleteById(adminId);
    }
    
    
    /**
     * 登录
     * @param username
     * @param password
     * @return
     */
    public AjaxResult login(String adminName, String password) {
    	AjaxResult ajax = AjaxResult.success();
    	QueryWrapper<Admins> wrapper = new QueryWrapper<>();
    	wrapper.eq("admin_name", adminName);
    	wrapper.eq("password", Md5Utils.hash(password));
    	Admins user = adminsMapper.selectOne(wrapper);
    	if (user == null) {
    		return AjaxResult.error("Username or Password is incorrect");
    	}
    	
    	String token = UUID.fastUUID().toString();
    	//redisCache.setCacheObject("login_admin_" + adminName, token, 30, TimeUnit.DAYS);
    	ajax.put("token", token);
    	ajax.put("user", user);
    	return ajax;
    }
}
