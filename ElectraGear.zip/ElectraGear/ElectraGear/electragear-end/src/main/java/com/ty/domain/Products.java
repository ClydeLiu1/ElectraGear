package com.ty.domain;

import java.util.List;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;

/**
 * Management backend system.   products

 */
@TableName(value = "products")
@Data
public class Products{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private String imagePath;

    /** $column.columnComment */
    private String category;

    /** $column.columnComment */
    private Long stockQuantity;

    /** $column.columnComment */
    private Double price;

    /** $column.columnComment */
    private String productDescription;

    /** $column.columnComment */
    private String productName;

    /** $column.columnComment */
    @TableId(value="product_id", type=IdType.AUTO)
    private Long productId;
    
    private String brandName;
    private transient String base64str;
}
