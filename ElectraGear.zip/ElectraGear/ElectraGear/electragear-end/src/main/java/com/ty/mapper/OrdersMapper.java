package com.ty.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ty.domain.Orders;


public interface OrdersMapper extends BaseMapper<Orders> {
	
	List<Orders> selectOrdersList(Orders orders);
}
