<template>
  <div class="car-header">
    <div class="car-header-content">
      <div class="car-header-logo">
        <router-link to="/" class="no-underline">ElectraGear</router-link>
      </div>
      <div class="car-header-nav">
        <ul>
          <li>
            <el-dropdown class="nav-one">
              <div>BYD</div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="shopNow('BYD', 'ATTO3')">ATTO3</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('BYD', 'DOLPHIN')">DOLPHIN</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('BYD', 'Seal')">Seal</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </li>
          <li>
            <el-dropdown class="nav-one">
              <span>MG</span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="shopNow('MG', 'MG4')">MG4</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('MG', 'MGZSEV')">MG ZS EV</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </li>
          <li>
            <el-dropdown class="nav-one">
              <span>TESLA</span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="shopNow('TESLA', 'MODEL Y')">MODEL Y</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('TESLA', 'MODEL 3')">MODEL 3</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </li>
          <li @click="navigateToService">EV Service</li>
          <li @click="toContactUs">Contact Us</li>
          <li class="shopping-cart" @click="cart">
            <el-badge :value="cartCount" :max="99">
              <svg t="1715011073005" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8122" width="50" height="50">
                <path d="M464 556.8m-432 0a432 432 0 1 0 864 0 432 432 0 1 0-864 0Z" fill="#FFDA00" p-id="8123"></path>
                <path d="M512 0C230.4 0 0 230.4 0 512s230.4 512 512 512 512-230.4 512-512S793.6 0 512 0z m0 976C256 976 48 768 48 512S256 48 512 48 976 256 976 512 768 976 512 976z" fill="#111111" p-id="8124"></path>
                <path d="M595.2 617.6c12.8 0 25.6-9.6 25.6-22.4 0-12.8-9.6-25.6-22.4-25.6l-230.4-6.4c-12.8 0-22.4-9.6-22.4-19.2l-25.6-137.6v-6.4c0-6.4 3.2-12.8 6.4-19.2 3.2-3.2 9.6-6.4 19.2-6.4h256c12.8 0 25.6-9.6 25.6-25.6s-9.6-25.6-25.6-25.6h-256c-19.2 0-38.4 6.4-51.2 22.4-12.8 12.8-22.4 32-22.4 51.2v16l22.4 137.6c6.4 32 35.2 54.4 67.2 57.6l233.6 9.6z" fill="#111111" p-id="8125"></path>
                <path d="M832 236.8h-60.8c-35.2 0-67.2 25.6-73.6 60.8l-60.8 352c-3.2 12.8-12.8 19.2-25.6 19.2H352c-12.8 0-25.6 9.6-25.6 25.6s9.6 25.6 25.6 25.6h259.2c35.2 0 64-25.6 70.4-60.8l60.8-352c3.2-12.8 12.8-22.4 25.6-19.2h60.8c12.8 0 25.6-9.6 25.6-22.4 0-16-9.6-28.8-22.4-28.8z" fill="#111111" p-id="8126"></path>
                <path d="M368 800a41.6 41.6 0 1 0 83.2 0 41.6 41.6 0 1 0-83.2 0Z" fill="#111111" p-id="8127"></path>
                <path d="M624 758.4c-22.4 0-41.6 19.2-41.6 41.6s19.2 41.6 41.6 41.6c22.4 0 41.6-19.2 41.6-41.6s-19.2-41.6-41.6-41.6z" fill="#111111" p-id="8128"></path>
              </svg>
            </el-badge>
          </li>


        </ul>
      </div>
    </div>
  </div>



</template>

<script setup name="Index">
import { getCountByUserId} from "@/api/cart";
import { ref,reactive, toRefs, getCurrentInstance, watch } from 'vue'
const { proxy } = getCurrentInstance();
import { useUserStore } from '@/stores'
import { useRouter } from 'vue-router'
const router = useRouter()

const userStore = useUserStore()
const cartCount = ref(0)

function shopNow(brandName, category) {

  router.push({path: '/product/list', query: {brandName: brandName, category: category}})
  // window.history
}

function getCartCount() {
  console.log("userId", userStore.user.userId)
  let params = {
    userId: userStore.user.userId
  }
  getCountByUserId(params).then(response => {
    cartCount.value = response.data
  });
}

function cart() {
    router.push({path: '/product/cart'})
}

function toContactUs() {
    router.push({path: '/contactUs'})
}
function navigateToService() {
  router.push({ path: '/ev-service' });
}

getCartCount()
</script>

<style>
.wrap {
  width: 100%;


}

.frame .overlap-group {
  height: 100%;
  width: 100%;
}
.car-header {
  width: 100%;
  height: 120px;
  margin-bottom: 80px;
  background-color: #00000025;

}
.car-header-content {
  width: 1200px;
  height: 100%;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  line-height: 120px;
  color: #00000025;

}
@import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');

.car-header-logo {
  font-family: 'Pacifico', cursive;
  font-size: 42px;
  font-weight: 700;
  text-align: left;
  color: #1f8624;
  width: 250px;
  height: 100%;
  transition: all 0.3s ease;
  position: relative;
  left: -20px;
}

.car-header-logo::before {
  content: '🌿';
  position: absolute;
  left: -40px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 30px;
  color: #148017;
}

.car-header-logo::after {
  content: '🔋';
  position: absolute;
  right: -40px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 32px;
  color: #08850b;
}

.car-header-logo:hover {
  transform: scale(1.1);
}


.car-header-nav ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  justify-content: end;
  color: #fff;

}
.car-header-nav li {
  margin-left: 50px;
  font-size: 20px;
  font-weight: 600;


}
.nav-one {
  line-height: 120px;
  height: 100px;
  font-size: 20px;
  color: #fff;
}
.nav-one div {
  font-size: 20px;
}

.car-header-nav li:hover {
  cursor: pointer;
}
.shopping-cart {
  line-height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.frame .logo-title {
  color: #ffffff;
  font-family: "Baskerville", "Garamond", serif;
  font-size: 60px;
  font-weight: 800;
  letter-spacing: 0;
  line-height: normal;
  width: 100%;
  margin: 0 0 0 10%;
  text-align: left;
}




.middle-frame .middle-top-frame {

  padding-bottom: 40px;
}

.recommend-one-info .remommend-img1{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p3.jpg');
  background-size: cover;
  background-position: center;
}.recommend-one-info .remommend-img2{
   width: 370px;
   height: 250px;
   background-image: url('../assets/p4.jpg');
   background-size: cover;
   background-position: center;
 }
.recommend-one-info .remommend-img3{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p5.jpg');
  background-size: cover;
  background-position: center;
}
.recommend-one-info .remommend-img4{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p6.jpg');
  background-size: cover;
  background-position: center;
}
.recommend-one-info .remommend-img5{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p7.jpg');
  background-size: cover;
  background-position: center;
}
.recommend-one-info .remommend-img6{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p8.jpg');
  background-size: cover;
  background-position: center;
}


.recommend-one-info .remommend-img1 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img2 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img3 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img4 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img5 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img6 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img1 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img2 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img3 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img4 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img5 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img6 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.shop-now {
  padding-top: 30px;
  padding-left: 180px;
}
.shop-now:hover {
  transform: scale(102%);
  cursor: pointer;
}
.shop-now span {
  font-size: 18px;
  font-weight: 600;
  color: #000;
  padding: 5px 10px;
  background-color: #fff;
}

.middle-frame .middle-bottom-frame {
  height: 400px;
  background-color: #f5f5f5;
  padding-top: 10px;
}
.middle-bottom-frame .middle-content {
  margin-top: 30px;
}





.no-underline {
  color: white;
  text-decoration: none;
}
</style>
