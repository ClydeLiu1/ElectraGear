<template>
  <heads></heads>
  <div class="shop-cart">
    <div class="shop-cart-detail">
      <div class="shop-cart-header">
        <h1>Cart</h1>
      </div>
      <div class="product-list">
        <el-table :data="cartList" border style="width: 100%">
          <el-table-column prop="name" label="Product">
            <template #default="scope">
              <el-row class="product-list-name">
                <el-col :span="4">
                  <img :src="getImageURL(scope.row.products.base64str)" height="40" width="40" />
                </el-col>
                <el-col :span="20" class="product-name">
                  {{ scope.row.products.productName }} - {{ scope.row.products.brandName
                  }}&nbsp;&nbsp;{{ scope.row.products.category }}
                </el-col>
              </el-row>
            </template>
          </el-table-column>

          <el-table-column prop="products.price" label="Price" width="180">
            <template #default="scope">
              $ {{ (scope.row.products && scope.row.products.price) ? scope.row.products.price : 'N/A' }}
            </template>
          </el-table-column>

          <el-table-column prop="quantity" label="Quantity" width="180" />
          <el-table-column prop="subtotal" label="Subtotal" width="180">
            <template #default="scope">
              <div class="subtotal-style">
                $
                {{ (scope.row.products && scope.row.products.price && scope.row.quantity) ? (scope.row.products.price * scope.row.quantity) : 'N/A' }}
<!--                <el-button type="text" class="delete-button" @click="removeItem(scope.row)">-->
<!--                  <i class="el-icon-circle-close"></i>-->
<!--                </el-button>-->
                <i class="el-icon-circle-close delete-button" @click="removeItem(scope.row)"></i>
              </div>
            </template>
          </el-table-column>
        </el-table>
        <el-row style="margin-top: 20px; text-align: right;">
          <el-col :span="24"></el-col>
        </el-row>
        <el-row>
          <el-col :span="12"></el-col>
          <el-col :span="12">
            <div class="shop-cart-totals">
              <div class="shop-cart-totals-header">
                <h3>Cart totals</h3>
              </div>
              <div class="shop-cart-totals-content">
                <el-row style="padding: 20px;">
                  <el-col class="shop-cart-totals-col" :span="10">Subtotal</el-col>
                  <el-col class="shop-cart-totals-col" :span="14">$ {{ subtotal }}</el-col>
                  <el-col class="shop-cart-totals-col" :span="10">Shipping</el-col>
                  <el-col class="shop-cart-totals-col" :span="14">{{ shippingCostText }}</el-col>
                  <el-col class="shop-cart-totals-col" :span="10">Total</el-col>
                  <el-col class="shop-cart-totals-col" :span="14">
                    ${{ total }}
                  </el-col>
                  <el-col :span="24">
                    <el-button class="shop-cart-totals-btn" type="primary" @click="checkout">Proceed To Checkout
                    </el-button>
                  </el-col>
                </el-row>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, toRefs } from 'vue'
import heads from '../heads.vue'
import { listCart, delCart } from "@/api/cart";
import { useUserStore } from '@/stores'
import { useRouter } from 'vue-router'

const userStore = useUserStore()
const user = userStore.user
const router = useRouter()

const subtotal = ref(0)
const shippingCost = ref(0)
const total = ref(0)
const shippingCostText = ref('Calculate shipping')
const data = reactive({
  queryParams: {
    userId: null,
  }
});

const { queryParams } = toRefs(data);
let cartList = ref([])

function checkout() {
  router.push({ path: '/product/checkout' })
}

function getList() {
  queryParams.value.userId = user.id
  console.log("User ID:", user.id);
  listCart(queryParams.value).then(response => {
    console.log("Cart data:", response.data);
    if (response && response.data) {
      cartList.value = response.data;
      calculateTotals();
    }
  }).catch(error => {
    console.error("Error loading cart data:", error);
  });
}

function calculateTotals() {
  subtotal.value = cartList.value.reduce((sum, item) => {
    if (item.products && item.products.price && item.quantity) {
      return sum + (item.products.price * item.quantity);
    } else {
      return sum;
    }
  }, 0);

  // Calculate shipping cost
  if (subtotal.value > 99) {
    shippingCost.value = 0;
    shippingCostText.value = 'Free shipping';
  } else {
    shippingCost.value = 12.99;
    shippingCostText.value = '$12.99';
  }

  total.value = subtotal.value + shippingCost.value;
}

function removeItem(item) {
  delCart(item.cartId).then(response => {
    if (response.code == 200) {
      // Remove item from cartList
      cartList.value = cartList.value.filter(cartItem => cartItem.cartId !== item.cartId);
      calculateTotals(); // Recalculate totals
    }
  }).catch(error => {
    console.error("Error removing cart item:", error);
  });
}

function getImageURL(path) {
  return "data:image/jpeg;base64," + path
}

getList()
</script>

<style scoped>

.subtotal-style{
  display: flex;
  justify-content: space-between;
}

.shop-cart {
  width: 1200px;
  height: 1200px;
  margin: 0 auto;
  background-color: #fff;
}

.shop-cart-detail {
  padding: 40px;
}

.shop-cart-header {
  width: 100%;
  padding-bottom: 15px;
  text-align: center;
  color: #666;
  font-size: 28px;
}

.product-list-name {
  height: 40px;
  line-height: 40px;
}

.product-name {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.delete-button {
  background: transparent; /* Remove background color */
  color: #000; /* Set color to black */
  border: 1px solid #000; /* Add border */
  border-radius: 50%; /* Make border round */
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-weight: bold; /* Make text bold */
}

.delete-button:hover {
  background-color: transparent; /* Keep background transparent on hover */
  color: #666; /* Change hover color to a darker shade of gray */
  border-color: #666; /* Change border color on hover */
}

.delete-button:before {
  content: '\00D7'; /* Unicode character for a cross (✗) */
  font-size: 18px; /* Adjust the size of the cross */
}

.shop-cart-totals {
  width: 100%;
  margin-top: 20px;
  border: 1px solid #e5e5e5;
}

.shop-cart-totals-header {
  border-bottom: 1px solid #e5e5e5;
}

.shop-cart-totals-header h3 {
  color: #666;
  padding-left: 20px;
}

.shop-cart-totals-content {
  background-color: #f5f5f5;
}

.shop-cart-totals-col {
  margin: 10px 0;
  padding-bottom: 10px;
  border-bottom: 1px solid #e5e5e5;
}

.shop-cart-totals-tips {
  font-size: 12px;
  color: #666;
}

.shop-cart-totals-btn {
  width: 100%;
  height: 50px;
  background-color: #39e17a;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>
