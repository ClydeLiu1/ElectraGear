<template>
  <heads></heads>
  <div class="car-content">
    <div class="car-info-detail">
      <el-row>
        <el-col class="img-wrap" :span="12" style="padding: 10px;">
          <img class="prodect-img" :src="getImageURL(product.base64str)" />
        </el-col>
        <el-col :span="12" style="padding: 10px 25px;">
          <h3>{{ product.productName }} – {{ product.brandName }} {{ product.category }}</h3>
          <div class="color-red">Price: ${{ product.price }}</div>
          <div class="stock">Stock: {{ product.stockQuantity }}</div>
          <el-col  class="car-option" :span="24">
            <el-input-number size="large" v-model="quantity"></el-input-number>
            &nbsp;
            <el-button size="large" style="font-size: 20px;" type="primary" @click="addCarts">Add To Cart</el-button>
          </el-col>
            <el-divider>Description</el-divider>
          <div class="desc">{{ product.productDescription }}</div>
        </el-col>
      </el-row>

    </div>
  </div>


  <Footer />
</template>

<script setup>
import { ref, getCurrentInstance } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { ElMessage } from 'element-plus';
import heads from '../heads.vue';
import Footer from '../user/Footer.vue';
import { useUserStore } from '@/stores';
import { getProducts } from "@/api/products";
import { addCart } from "@/api/cart";

const router = useRouter();
const route = useRoute();
const userStore = useUserStore();
const { proxy } = getCurrentInstance();

const productId = route.query.productId;
const quantity = ref(1);
const activeName = ref("first");
const product = ref({});

function addCarts() {
  if (!userStore.userToken) {
    router.push('/login');
    return;
  } else {
    let form = {
      userId: userStore.user.userId,
      productId: productId,
      quantity: quantity.value
    };
    addCart(form).then(response => {
      ElMessage.success("Success");
    }).catch(error => {
      ElMessage.error("Failed to add to cart");
      console.error(error);
    });
  }
}

function getDetail() {
  getProducts(productId).then(response => {
    product.value = response.data;
    console.log("product", product.value);
  }).catch(error => {
    ElMessage.error("Failed to fetch product details");
    console.error(error);
  });
}

function getImageURL(path) {
  return "data:image/jpeg;base64," + path;
}

getDetail();
</script>
<style scoped>

.img-wrap{
  display: flex;
  justify-content: flex-end;
}
.car-content{
  width: 80%;
  margin: 0 auto;
  padding-bottom: 200px;
}
.prodect-img{
  display: block;
  width: 60%;
  margin-right: 10%;

}
.color-red{
  color: red;
}
.desc{
  margin-top: 20px;
}
.stock{
  margin-top: 15px;
  margin-bottom: 15px;
}
.car-option{
  margin-bottom: 50px;
}
</style>