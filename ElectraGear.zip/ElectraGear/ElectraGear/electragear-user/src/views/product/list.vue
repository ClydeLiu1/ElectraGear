<template>
  <div class="car-header">
    <div class="car-header-content">
      <div class="car-header-logo">
        <router-link to="/" class="no-underline">ElectraGear</router-link>
      </div>
      <div class="car-header-nav">
        <ul>
          <li>
            <el-dropdown class="nav-one">
              <span>BYD</span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="shopNow('BYD', 'ATTO3')">ATTO3</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('BYD', 'DOLPHIN')">DOLPHIN</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </li>
          <li>
            <el-dropdown class="nav-one">
              <span>MG</span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="shopNow('MG', 'MG4')">MG4</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('MG', 'MGZSEV')">MG ZS EV</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </li>
          <li>
            <el-dropdown class="nav-one">
              <span>TESLA</span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="shopNow('TESLA', 'MODEL Y')">MODEL Y</el-dropdown-item>
                  <el-dropdown-item @click="shopNow('TESLA', 'MODEL 3')">MODEL 3</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </li>
          <li>EV Service</li>
          <li @click="toContactUs">CONTACT US</li>
          <li class="shopping-cart" @click="cart">
            <el-badge :value="cartCount" :max="99" class="item">
              <svg t="1715011073005" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8122" width="50" height="50">
                <path d="M464 556.8m-432 0a432 432 0 1 0 864 0 432 432 0 1 0-864 0Z" fill="#FFDA00" p-id="8123"></path>
                <path d="M512 0C230.4 0 0 230.4 0 512s230.4 512 512 512 512-230.4 512-512S793.6 0 512 0z m0 976C256 976 48 768 48 512S256 48 512 48 976 256 976 512 768 976 512 976z" fill="#111111" p-id="8124"></path>
                <path d="M595.2 617.6c12.8 0 25.6-9.6 25.6-22.4 0-12.8-9.6-25.6-22.4-25.6l-230.4-6.4c-12.8 0-22.4-9.6-22.4-19.2l-25.6-137.6v-6.4c0-6.4 3.2-12.8 6.4-19.2 3.2-3.2 9.6-6.4 19.2-6.4h256c12.8 0 25.6-9.6 25.6-25.6s-9.6-25.6-25.6-25.6h-256c-19.2 0-38.4 6.4-51.2 22.4-12.8 12.8-22.4 32-22.4 51.2v16l22.4 137.6c6.4 32 35.2 54.4 67.2 57.6l233.6 9.6z" fill="#111111" p-id="8125"></path>
                <path d="M832 236.8h-60.8c-35.2 0-67.2 25.6-73.6 60.8l-60.8 352c-3.2 12.8-12.8 19.2-25.6 19.2H352c-12.8 0-25.6 9.6-25.6 25.6s9.6 25.6 25.6 25.6h259.2c35.2 0 64-25.6 70.4-60.8l60.8-352c3.2-12.8 12.8-22.4 25.6-19.2h60.8c12.8 0 25.6-9.6 25.6-22.4 0-16-9.6-28.8-22.4-28.8z" fill="#111111" p-id="8126"></path>
                <path d="M368 800a41.6 41.6 0 1 0 83.2 0 41.6 41.6 0 1 0-83.2 0Z" fill="#111111" p-id="8127"></path>
                <path d="M624 758.4c-22.4 0-41.6 19.2-41.6 41.6s19.2 41.6 41.6 41.6c22.4 0 41.6-19.2 41.6-41.6s-19.2-41.6-41.6-41.6z" fill="#111111" p-id="8128"></path>
              </svg>
            </el-badge>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="car-content">
    <div class="car-detail">
      <el-row>
        <el-col :span="6" v-for="(data, index) in productsList" :key="index">
          <div class="car-one">
            <div class="car-image" @click="detail(data)">

              <img :src="getImageURL(data.base64str)" class="car-image" />
            </div>
            <el-row class="car-info">
              <el-col :span="24">
                <p style="font-size: 18px; font-weight: 600;">{{ data.productName }} - {{ data.brandName }} - {{ data.category }}</p>
              </el-col>
              <el-col :span="12">
                <div class="car-text-info">
                  <p style="padding-left: 5px; font-size: 20px; font-weight: 600;">${{ data.price }}</p>
                </div>
              </el-col>

            </el-row>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>


  <Footer />
</template>

<script setup>
import { listProducts, getProducts, delProducts, addProducts, updateProducts } from "@/api/products";
import { ref, reactive, toRefs, getCurrentInstance, watch } from 'vue';
import { useUserStore } from '@/stores';
import request from "@/utils/request";
import { listCart, getCart, getCountByUserId, addCart, updateCart } from "@/api/cart";
import heads from '../heads.vue';
import { useRouter, useRoute } from 'vue-router';
import Footer from '../user/Footer.vue';

const router = useRouter();
const route = useRoute();
const brandName = ref(undefined);
const category = ref(undefined);
brandName.value = route.query.brandName;
category.value = route.query.category;

const userStore = useUserStore();
const productsList = ref([]);
const data = reactive({
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    carCompatibility: null,
    category: null,
    stockQuantity: null,
    price: null,
    productDescription: null,
    productName: null,
    brandName: undefined,
    category: undefined
  },
});
const { queryParams } = toRefs(data);
const cartCount = ref(0);


function getList() {
  queryParams.value.brandName = brandName;
  queryParams.value.category = category;

  listProducts(queryParams.value).then(response => {
    productsList.value = response.rows;
  });
}

function detail(data) {
  router.push({ path: '/product/detail', query: { productId: data.productId } });
}


function getImageURL(path) {
  return "data:image/jpeg;base64," + path;
}

function shopNow(a, b) {
  brandName.value = a;
  category.value = b;
  getList();
}

function getCartCount() {
  console.log("userId", userStore.user.userId);
  let params = {
    userId: userStore.user.userId
  };
  getCountByUserId(params).then(response => {
    cartCount.value = response.data;
  });
}

function cart() {
  router.push({ path: '/product/cart' });
}

getCartCount();
getList();

function toContactUs() {
  router.push({ path: '/contactUs' });
}
</script>

<style scoped>
.car-header-nav li{
  color:#333;
}
.car-content {
  width: 1200px;
  margin: 0 auto;
}

.car-detail {
  padding: 20px;

}

.car-info {
  padding: 5px;
}

.car-one {
  padding: 10px;
}

.car-image img {
  height: 100%;
  width: 100%;
  border-radius: 8px;
}

.car-image img:hover {
  cursor: pointer;
}

.car-info h3 {
  margin: 0;
  font-size: 24px;
  color: #333;
  margin: 15px 0;
}

.car-info p {
  margin: 5px 0;
  font-size: 16px;
  color: #666;
  margin-bottom: 10px;
}


@media (max-width: 768px) {
  .car-detail {
    flex-direction: column;
    align-items: flex-start;
  }

  .car-image {
    margin-bottom: 20px;
  }
}

.buttons {
  height: 100%;
  display: flex;
  align-items: end;
  justify-content: right;
}

.btnDriver,
.btnOrder {
  padding: 5px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  width: auto;
}


.btnDriver {
  position: relative;
  background-color: #007bff;
  color: white;
  margin-right: 10px;
}


.btnOrder {
  background-color: #28a745;
  color: white;
}

.btnDriver:hover,
.btnOrder:hover {
  filter: brightness(0.9);
}

.car-header {
  width: 100%;
  height: 120px;
  background-color: #fff;
  margin-bottom: 60px;
}

.car-header-content {
  width: 1300px;
  height: 100%;
  margin: 0 auto;
  display: flex;
  line-height: 120px;
}

.car-header-logo {
  font-size: 28px;
  font-weight: 600;
  text-align: center;
  color: #333;
  width: 200px;
  height: 100%;
}

.car-header-nav {
  width: 1100px;
  height: 100%;
  text-align: right;
}

.car-header-nav ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  justify-content: end;
}

.car-header-nav li {
  margin-left: 50px;
  font-size: 16px;
  font-weight: 600;
}

.nav-one {
  line-height: 120px;
  color: #333;
  font-size: 16px;
  height: 80px;
}

.car-header-nav li:hover {
  cursor: pointer;
}

.shopping-cart {
  line-height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.no-underline {
  color: #333;
  text-decoration: none;
}
</style>
