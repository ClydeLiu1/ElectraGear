<template>
  <heads></heads>
  <div class="shop-checkout">
    <div class="shop-checkout-detail">
      <div class="shop-checkout-header">
        <h1>Checkout</h1>
      </div>
      <div class="shop-checkout-content">
        <el-row>
          <el-col :span="24">
          </el-col>
        </el-row>
        <el-form
          ref="ordersRef"
          :model="ruleForm"
          label-position="top"
          label-width="auto"
          class="demo-ruleForm"
          :size="formSize"
          status-icon>
          <el-row class="shop-checkout-form">

            <el-col :span="24">
              <el-row style="padding-right: 30px;">
                <el-col :span="13">
                  <div class="shop-checkout-form-title">Billing details</div>
                  <div class="shop-checkout-form-div">

                    <el-row>
                      <el-col :span="12">
                        <el-form-item class="form-item" label="First Name" prop="firstName" required>
                          <el-input v-model="ruleForm.firstName" />
                        </el-form-item>
                      </el-col>
                      <el-col :span="1"></el-col>
                      <el-col :span="11">
                        <el-form-item class="form-item" label="Last Name" prop="lastName" required>
                          <el-input v-model="ruleForm.lastName" />
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-form-item class="form-item" label="Phone Number" prop="phone" required>
                      <el-input v-model="ruleForm.phone" />
                    </el-form-item>
                    <el-form-item class="form-item" label="Delivery Address" prop="deliveryAddress" required>
                      <el-input v-model="ruleForm.deliveryAddress"/>
                    </el-form-item>



                    <el-form-item class="form-item" label="Order notes(optional)" prop="remark">
                      <el-input v-model="ruleForm.remark" type="textarea" rows="3" placeholder="Please specify if you DO NOT want to use a particular courier company. All orders are shipped on a Signature Required basis. If you would like to add a comment or delivery instructions, please write it here." />
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="1"></el-col>
                <el-col :span="10" class="shop-checkout-order">
                  <el-col :span="24" style="padding: 20px; font-size: 18px; font-weight: 600;">
                    Your order
                  </el-col>
                  <el-row style="margin-top: 10px; width: 100%;">
                    <el-row>
                      <el-col class="shop-checkout-order-col" :span="10" style="font-weight: 600;">Product</el-col>
                      <el-col class="shop-checkout-order-col" :span="1"></el-col>
                      <el-col class="shop-checkout-order-col" :span="13" style="text-align: right; font-weight: 600;">Subtotal</el-col>
                      <template v-for="(item, index) in cartList" :key="index">
                        <el-col class="shop-checkout-order-col" :span="10">{{ item.products.productName }} - {{ item.products.brandName }} {{  item.products.category }}</el-col>
                        <el-col class="shop-checkout-order-col" :span="1">x{{ item.quantity }}</el-col>
                        <el-col class="shop-checkout-order-col" :span="13" style="text-align: right;">${{ item.products.price * item.quantity }}</el-col>
                      </template>


                      <el-col class="shop-checkout-order-col" :span="10">Subtotal</el-col>
                      <el-col class="shop-checkout-order-col" :span="1"></el-col>
                      <el-col class="shop-checkout-order-col" :span="13" style="text-align: right;">${{subtotal}}</el-col>
                      <el-col class="shop-checkout-order-col" :span="10">Total</el-col>
                      <el-col class="shop-checkout-order-col" :span="1"></el-col>
                      <el-col class="shop-checkout-order-col" :span="13" style="text-align: right;">${{subtotal}} <span style="font-size: 12px; color: #666;">(includes ${{ gst }} GST)</span></el-col>
                    </el-row>
                    <el-row style="width: 100%;">
                      <el-col :span="24">
                        <el-radio-group v-model="radio1" class="ml-4" style="width: 100%;">
                          <el-col :span="24">
                            <el-radio value="1" size="large">Credit / Debit Card</el-radio>
                            <div class="shop-checkout-order-card">

                              <el-form-item label="Card number" prop="cardNumber">
                                <el-input
                                  v-model="ruleForm.cardNumber"
                                  style="width: 100%;"
                                  placeholder="1234 1234 1234 1234"/>
                              </el-form-item>
                              <el-row>
                                <el-col :span="11">
                                  <el-form-item label="Expiration" prop="expirationDate">
                                    <el-input
                                      v-model="ruleForm.expirationDate"
                                      placeholder="MM / YY"/>
                                  </el-form-item>
                                </el-col>
                                <el-col :span="2"></el-col>
                                <el-col :span="11">
                                  <el-form-item label="CVC" prop="securityCode">
                                    <el-input
                                      v-model="ruleForm.securityCode"
                                      placeholder="CVC"/>
                                  </el-form-item>
                                </el-col>
                              </el-row>
                            </div>
                          </el-col>
                        </el-radio-group>
                      </el-col>
                      <el-col :span="24">
                        <el-form-item>
                          <el-button style="  width: 100%; height: 50px;background-color: #39e17a;color: #fff;border: none;border-radius: 4px;cursor: pointer;" type="primary" @click="submitForm">Place Order</el-button>
                        </el-form-item>
                      </el-col>
                    </el-row>
                  </el-row>
                </el-col>
              </el-row>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref,reactive, toRefs, getCurrentInstance, watch } from 'vue'
import heads from '../heads.vue'
import { computed } from 'vue'
import { listCart, getCart, delCart, addCart, updateCart } from "@/api/cart";
import { listOrders, getOrders, delOrders, addOrders, updateOrders } from "@/api/orders";
import { useUserStore } from '@/stores'
const { proxy } = getCurrentInstance();
const userStore = useUserStore()
const user = userStore.user

const subtotal = ref(0)
let cartList = ref([])
const ruleForm = ref({});
const productsCartList = ref([])
const data = reactive({
  queryParams: {
    userId: null,  }
});
const { queryParams} = toRefs(data);

function getList() {
  queryParams.value.userId = user.userId
  listCart(queryParams.value).then(response => {
    cartList.value = response.data;
    cartList.value.forEach(item => {
      subtotal.value += item.products.price * item.quantity

      let obj = {
      }
      obj.productId = item.productId
      obj.num = item.quantity
      productsCartList.value.push(obj)
    })
  });
}
const gst = computed(() => {
  return (subtotal.value * 0.15).toFixed(2)
})
// submit part
function submitForm() {
  proxy.$refs["ordersRef"].validate(valid => {
    if (valid) {
      ruleForm.value.userId = user.userId
      ruleForm.value.subtotal = subtotal.value
      ruleForm.value.productsCartList = productsCartList.value
      addOrders(ruleForm.value).then(response => {
        ElMessage.success("success");
      });
    }
  });
}

getList()
</script>

<style scoped>
.shop-checkout {
  width: 1200px;
  height: 1400px;
  margin: 0 auto;
  background-color: #fff;
}
.shop-checkout-detail {
  padding: 40px;
}
.shop-checkout-header {
  width: 100%;
  padding-bottom: 15px;
  text-align: center;
  color: #666;
  font-size: 28px;
}


.shop-checkout-form {
  margin-top: 20px;
}

.shop-checkout-form-title {
  font-size: 18px;
  font-weight: 600;
  margin-top: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid #e5e5e5;
}
.form-item {
  margin-top: 10px;
}
.shop-checkout-form-div {
  margin-top: 30px;
}
.shop-checkout-order {
  border: 1px solid #e5e5e5;
  padding: 20px;
}
.shop-checkout-order-col {
  margin: 10px 0;
  padding: 20px 0;
  border-bottom: 1px solid #e5e5e5;
}
.shop-checkout-order-card {
  padding: 20px;
  background-color: #eeeeee;
}




.shop-cart-totals-header h3 {
  color: #666;
  padding-left: 20px;
}

</style>