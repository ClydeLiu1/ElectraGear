<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { UserFilled } from '@element-plus/icons-vue'

const activeIndex = ref('1')

const router = useRouter()


const tocarShow = () => {
  router.push('/cardetails/carshow')
}
const toPurchase = () => {
  router.push('/cardetails/carpurchase')
}
const toTestdrive = () => {
  router.push('/cardetails/testdrive')
}
const tocarService = () => {
  router.push('/cardetails/service')
}

const toProfile = () => {
  router.push('/user/profile')
}

const toPassword = () => {
  router.push('/user/password')
}

const toEvaluate = () => {
  router.push('/user/evaluate')
}

const toLogin = async () => {
  // exit
  await ElMessageBox.confirm('Are you sure you want to exit', 'Reminder', {
    type: 'warning',
    confirmButtonText: 'confirm',
    cancelButtonText: 'cancel'
  })
// Clear local data (token + user information)

  router.push('/login')
}
</script>

<template>
  <div class="layoutcontainer">
    <el-container>

      <el-header class="header bg1">
        <el-menu
          :default-active="activeIndex"
          class="navigationbar"
          mode="horizontal"
          @select="handleSelect"
          text-color="#fff"
          active-text-color="#ffd04b"
          active-color="grey"
        >
          <el-menu-item index="1" @click="tocarShow">汽车展示</el-menu-item>
          <el-menu-item index="2" @click="toPurchase">订购详情</el-menu-item>
          <el-menu-item index="3" @click="toTestdrive">预约试驾</el-menu-item>
          <el-menu-item index="4" @click="tocarService">售后服务</el-menu-item>
        </el-menu>
        <el-dropdown>
          <span class="userarea">
            personal center&nbsp;
            <el-icon class="usericon">
              <UserFilled />
            </el-icon>
          </span>
          <template #dropdown>
            <el-dropdown-menu>

              <el-dropdown-item @click="toLogin">exit login</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </el-header>

      <el-main class="main bg2">
        <router-view></router-view>
      </el-main>

      <el-footer class="footer bg1">
        <section class="loader">
          <div class="slider" style="--i: 0"></div>
          <div class="slider" style="--i: 1"></div>
          <div class="slider" style="--i: 2"></div>
          <div class="slider" style="--i: 3"></div>
          <div class="slider" style="--i: 4"></div>
        </section>
      </el-footer>
    </el-container>
  </div>
</template>

<style lang="scss" scoped>

.bg1 {
  /* Basic dimensions and centering */
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  /* Dark mode colors and gradient */
  background: #121212; /* Fallback for browsers that don't support gradients */
  background: linear-gradient(
    135deg,
    #121212 25%,
    #1a1a1a 25%,
    #1a1a1a 50%,
    #121212 50%,
    #121212 75%,
    #1a1a1a 75%,
    #1a1a1a
  );
  background-size: 40px 40px;

  /* Animation */
  animation: move 4s linear infinite;
}

@keyframes move {
  0% {
    background-position: 0 0;
  }
  100% {
    background-position: 40px 40px;
  }
}

/*header*/
.header {
  display: flex;
  height: 15vh;
  background-color: #fff;
  justify-content: space-between;
  .el-menu .el-menu-item:hover {
    background: rgba(255, 255, 255, 0) !important;
  }
  .el-menu .el-menu-item.is-active {
    background: rgba(255, 255, 255, 0) !important;
  }
  .header .el-submenu__title:hover {
    background: rgba(255, 255, 255, 0) !important;
  }

  .navigationbar {
    width: 28.1rem;
    background-color: rgba(255, 255, 255, 0);
  }
}

.userarea {
  cursor: pointer;
  color: #fff;
  display: flex;
  align-items: center;
}
.userarea:hover {
  border-color: translate;
}

/*main*/
.bg2 {
  width: 100%;
  height: 100%;
  --color: #e1e1e1;
  background-color: #f3f3f3;
  background-image: linear-gradient(
      0deg,
      transparent 24%,
      var(--color) 25%,
      var(--color) 26%,
      transparent 27%,
      transparent 74%,
      var(--color) 75%,
      var(--color) 76%,
      transparent 77%,
      transparent
    ),
    linear-gradient(
      90deg,
      transparent 24%,
      var(--color) 25%,
      var(--color) 26%,
      transparent 27%,
      transparent 74%,
      var(--color) 75%,
      var(--color) 76%,
      transparent 77%,
      transparent
    );
  background-size: 55px 55px;
}

.main {
  index: 1;
  height: 70vh;
}

.footer {
  height: 15vh;
}

.loader {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: row;
}

.slider {
  overflow: hidden;
  background-color: white;
  margin: 0 15px;
  height: 80px;
  width: 20px;
  border-radius: 30px;
  box-shadow: 15px 15px 20px rgba(0, 0, 0, 0.1), -15px -15px 30px #fff,
    inset -5px -5px 10px rgba(0, 0, 255, 0.1), inset 5px 5px 10px rgba(0, 0, 0, 0.1);
  position: relative;
}

.slider::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  border-radius: 100%;
  box-shadow: inset 0px 0px 0px rgba(0, 0, 0, 0.3), 0px 420px 0 400px #2697f3,
    inset 0px 0px 0px rgba(0, 0, 0, 0.1);
  animation: animate_2 2.5s ease-in-out infinite;
  animation-delay: calc(-0.5s * var(--i));
}

@keyframes animate_2 {
  0% {
    transform: translateY(250px);
    filter: hue-rotate(0deg);
  }

  50% {
    transform: translateY(0);
  }

  100% {
    transform: translateY(250px);
    filter: hue-rotate(180deg);
  }
}
</style>
