<template>
  <heads></heads>

  <div class="contact-container">
    <div v-if="successMessage" class="success-message">
      You succeeded, we will contact you later
    </div>
    <div class="contact-header">
      <h1>Contact Us</h1>
    </div>
    <div class="contact-content">
      <el-row>
        <el-col :span="12">
          <div class="contact-text-info">
            <div class="contact-info-title">
              <h1>ElectraGear</h1>
            </div>
            <div class="contact-info-list">
              <ul>
                <li>Shipping & Delivery</li>
                <li>Returns & Refunds</li>
                <li>All warranty claims must be submitted via email, see details here.</li>
              </ul>
            </div>
          </div>
          <div class="contact-way">
            <div class="contact-email">
              <span style="padding-right: 10px;">
                <svg t="1716221044525" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1703" width="32" height="32"><path d="M928.193561 226.179122H95.806439c-20.87961 0-31.369366 10.489756-31.369366 33.367415v33.367414l331.776 214.890147c1.998049 0 1.998049 0 1.998049 2.097951l33.367415 20.87961c54.247024 33.367415 106.396098 33.367415 160.643122 0l31.369365-20.87961c2.097951 0 4.195902 0 4.195903-1.998049l331.776-214.890146v-33.467317c0-20.87961-10.489756-33.367415-31.369366-33.367415z m-319.188293 331.676098l27.073561-16.78361 323.384195 208.696195v14.585756c0 22.877659-10.489756 33.367415-31.369365 33.367415H95.806439c-20.87961 0-31.369366-10.489756-31.369366-33.367415v-14.585756l323.384195-208.696195 27.173464 16.78361c64.636878 41.75922 129.373659 41.75922 194.010536 0zM959.562927 712.30439L667.448195 522.389854l292.114732-189.814634V712.30439z m-895.125854-379.72917l292.114732 189.814634L64.437073 712.30439V332.57522z" p-id="1704"></path></svg>
              </span>
              <span>support@electragear.co.nz
              </span>
            </div>
            <div class="contact-phone">
              <span style="padding-right: 10px;">
                <svg t="1716221208277" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5535" width="32" height="32"><path d="M876.76 879.07l25-25a82 82 0 0 0 0-115.63l-86.33-65.37c-4.84-3.66-9.5-7.55-14.15-11.45a71.8 71.8 0 0 0-96.58 4.23l-39.8 38.86a52.71 52.71 0 0 1-64.9 7.68c-85.36-52.59-217.33-185.14-266.22-264.16a52.85 52.85 0 0 1 7.47-65.23l43.63-41.35a71.79 71.79 0 0 0 2.88-98.15c-4.1-4.6-8-9.4-11.83-14.2l-61.5-76.64c-19-23.72-49.57-35.56-79.43-29.81a81.16 81.16 0 0 0-42.18 22.36l-21.1 21.1a164.41 164.41 0 0 0-44.23 153.11C182 555.2 495.86 877.24 728.33 924.29c53.86 10.9 109.58-6.37 148.43-45.22z" fill="#303030" p-id="5536"></path><path d="M740.57 912.62a167.59 167.59 0 0 1-33.26-3.34c-56.79-11.49-119.37-39-186-81.9-61.88-39.78-125.41-92.05-183.73-151.14C279.64 617.52 227.71 553 187.42 489.56c-42.93-67.56-71.47-131.12-84.83-188.92a168.66 168.66 0 0 1 2.41-84.75 170.84 170.84 0 0 1 43.19-73l21.1-21.1A86.07 86.07 0 0 1 214 98c31.49-6.06 63.78 6 84.28 31.59 0 0 69.21 86.2 73.17 90.65a76.62 76.62 0 0 1-3.08 105l-0.1 0.09-43.59 41.31a47.69 47.69 0 0 0-6.71 59c50.23 81.17 181.29 211.21 264.59 262.53a47.53 47.53 0 0 0 58.74-7l39.81-38.85c27.77-27.77 73.15-29.75 103.28-4.49 4.24 3.56 77.18 59.12 96.26 73.65a62.31 62.31 0 0 1 10.86 10.49 86.89 86.89 0 0 1-6.32 115.66l-25 25a169.23 169.23 0 0 1-119.62 49.99zM230.14 106.5a75.19 75.19 0 0 0-14.22 1.36 76.12 76.12 0 0 0-39.58 21l-21.1 21.1c-39.27 39.27-55.3 94.76-42.9 148.45 25.57 110.66 112.44 249.28 232.36 370.8 120.83 122.44 257.13 208.52 364.6 230.27 52.1 10.55 105.9-5.85 143.9-43.85l25-25a76.88 76.88 0 0 0 7.44-99.94 61.1 61.1 0 0 0-12.18-12.17c-19.67-15-91.12-69.37-95.42-73-26.19-22-65.65-20.24-89.83 3.94l-39.81 38.85a57.48 57.48 0 0 1-71 8.36C536.79 671.76 483 627 429.65 573.86 377.07 521.47 333.27 469.38 309.49 431a57.65 57.65 0 0 1 8.19-71.39l0.1-0.09 43.58-41.31a66.61 66.61 0 0 0 2.64-91.28c-4.12-4.63-73.5-91-73.5-91a77.53 77.53 0 0 0-60.36-29.43z" fill="#EDA545" p-id="5537"></path></svg>
              </span>
              <span>02100000</span>
            </div>
          </div>
          <div class="contact-address">
            <span style="font-weight: 600;">Warehouse Opening Hours</span> – for Pick-up, Return & Exchange only<br>
            14/12 Harrison Road,Mt Wellington,Auckland Central,Auckland<br>
            Mon to Fri 10AM – 3PM<br>
            Except for public holidays<br>
          </div>
        </el-col>
        <el-col :span="12" class="contact-form">
          <h1>Leave a Message  </h1>
          <el-form :model="ruleForm" :rules="rules" label-position="top" ref="contactRef" label-width="100px" class="demo-ruleForm">
            <el-form-item label="Name" prop="name" required>
              <el-input v-model="ruleForm.name"></el-input>
            </el-form-item>
            <el-form-item label="Email" prop="email" required>
              <el-col>
                <el-input placeholder="Email address" v-model="ruleForm.email"></el-input>
              </el-col>
            </el-form-item>
            <el-form-item label="Phone" prop="phone">
              <el-col >
                <el-input v-model="ruleForm.phone"></el-input>
              </el-col>
            </el-form-item>
            <el-form-item label="Message" prop="message" required>
              <el-input type="textarea" v-model="ruleForm.message" rows="5"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm()">Submit</el-button>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
    </div>
    <Footer>   </Footer>
  </div>
</template>

<script setup>
import { ref,reactive, toRefs, getCurrentInstance, watch } from 'vue'
import heads from './heads.vue'
import Footer from '@/views/user/Footer.vue';
const { proxy } = getCurrentInstance();
import { listContact, getContact, delContact, addContact, updateContact } from "@/api/contact";
import { useUserStore } from '@/stores'
import { useRouter, useRoute } from 'vue-router'
import { Message } from '@element-plus/icons-vue'
const userStore = useUserStore()
const user = userStore.user
const router = useRouter()
const cart = ref([
  {
    id: 1,
    name: 'Silicone Key Fob Cover - BYD',
    price: 1.95,
    quantity: 13,
    subtotal: 25.35
  }
]);

const ruleForm = ref({
});

const rules = ref(
  {
    name: [
      { required: true, message: "This field is required.", trigger: "blur" }
    ],
    phone: [
      { required: true, message: "This field is required.", trigger: "blur" }
    ],
    email: [
      { required: true, message: "This field is required.", trigger: "blur" }
    ],
    message: [
      { required: true, message: "This field is required.", trigger: "blur" }
    ],
  })

const cartTotal = cart.value.reduce((sum, item) => sum + item.subtotal, 0);

function contactUs() {
  alert('Contact Us button clicked!');
}

function checkout() {
  alert('Checkout button clicked!');
}

function submitForm() {
  proxy.$refs["contactRef"].validate(valid => {
    if (valid) {
      ruleForm.value.userId = user.userId
      addContact(ruleForm.value).then(response => {
        ElMessage.success("success");
        router.push({path: '/'})
      });
    }
  });
}

</script>

<style scoped>
.contact-container {
  margin: 0 auto;
}
.contact-header {
  width: 100%;
  padding-bottom: 15px;
  text-align: center;
  color: #666;
  font-size: 28px;
}
button {
  width: 100%;
  padding: 10px;
  background-color: #39e17a;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #070a07;
}

.contact-content {
  padding: 90px;
}
.contact-content .contact-info-list {
  padding-left: 10px;
}
.contact-content .contact-info-list li {
  margin: 10px 0;
}
.contact-way {
  padding: 20px 0;
}
.contact-way .contact-email, .contact-phone {
  padding: 8px 0;
  display: flex;
  align-items: center;
}
.contact-address {
  line-height: 30px;
}


.contact-form {
  background-color: #fff;
  padding: 40px 20px;
  box-shadow: 0 0 15px 10px #e1e1e1;
  border-radius: 5px;
}
</style>
