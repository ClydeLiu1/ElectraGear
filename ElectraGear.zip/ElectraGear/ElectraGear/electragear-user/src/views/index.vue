<template>
  <div class="wrap">
    <div class="frame">
      <div class="overlap-group">
        <div class="car-header">
          <div class="car-header-content">
              <div class="car-header-logo">
                <router-link to="/" class="no-underline">ElectraGear</router-link>
              </div>
              <div class="car-header-nav">
                  <ul>
                      <li>
                          <el-dropdown class="nav-one">
                              <div>BYD</div>
                              <template #dropdown>
                                  <el-dropdown-menu>
                                    <el-dropdown-item @click="shopNow('BYD', 'ATTO3')">ATTO3</el-dropdown-item>
                                    <el-dropdown-item @click="shopNow('BYD', 'DOLPHIN')">DOLPHIN</el-dropdown-item>
                                    <el-dropdown-item @click="shopNow('BYD', 'Seal')">Seal</el-dropdown-item>
                                  </el-dropdown-menu>
                              </template>
                          </el-dropdown>
                      </li>
                      <li>
                        <el-dropdown class="nav-one">
                            <span>MG</span>
                            <template #dropdown>
                                <el-dropdown-menu>
                                    <el-dropdown-item @click="shopNow('MG', 'MG4')">MG4</el-dropdown-item>
                                    <el-dropdown-item @click="shopNow('MG', 'MGZSEV')">MG ZS EV</el-dropdown-item>
                                </el-dropdown-menu>
                            </template>
                        </el-dropdown>
                      </li>
                      <li>
                        <el-dropdown class="nav-one">
                            <span>TESLA</span>
                            <template #dropdown>
                                <el-dropdown-menu>
                                    <el-dropdown-item @click="shopNow('TESLA', 'MODEL Y')">MODEL Y</el-dropdown-item>
                                    <el-dropdown-item @click="shopNow('TESLA', 'MODEL 3')">MODEL 3</el-dropdown-item>
                                </el-dropdown-menu>
                            </template>
                        </el-dropdown>
                      </li>
                      <li @click="toEVService">EV Service</li>
                      <li @click="toContactUs">Contact Us</li>
                      <li class="shopping-cart" @click="cart">
                        <el-badge :value="cartCount" :max="99">
                          <svg t="1715011073005" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8122" width="50" height="50">
                            <path d="M464 556.8m-432 0a432 432 0 1 0 864 0 432 432 0 1 0-864 0Z" fill="#FFDA00" p-id="8123"></path>
                            <path d="M512 0C230.4 0 0 230.4 0 512s230.4 512 512 512 512-230.4 512-512S793.6 0 512 0z m0 976C256 976 48 768 48 512S256 48 512 48 976 256 976 512 768 976 512 976z" fill="#111111" p-id="8124"></path>
                            <path d="M595.2 617.6c12.8 0 25.6-9.6 25.6-22.4 0-12.8-9.6-25.6-22.4-25.6l-230.4-6.4c-12.8 0-22.4-9.6-22.4-19.2l-25.6-137.6v-6.4c0-6.4 3.2-12.8 6.4-19.2 3.2-3.2 9.6-6.4 19.2-6.4h256c12.8 0 25.6-9.6 25.6-25.6s-9.6-25.6-25.6-25.6h-256c-19.2 0-38.4 6.4-51.2 22.4-12.8 12.8-22.4 32-22.4 51.2v16l22.4 137.6c6.4 32 35.2 54.4 67.2 57.6l233.6 9.6z" fill="#111111" p-id="8125"></path>
                            <path d="M832 236.8h-60.8c-35.2 0-67.2 25.6-73.6 60.8l-60.8 352c-3.2 12.8-12.8 19.2-25.6 19.2H352c-12.8 0-25.6 9.6-25.6 25.6s9.6 25.6 25.6 25.6h259.2c35.2 0 64-25.6 70.4-60.8l60.8-352c3.2-12.8 12.8-22.4 25.6-19.2h60.8c12.8 0 25.6-9.6 25.6-22.4 0-16-9.6-28.8-22.4-28.8z" fill="#111111" p-id="8126"></path>
                            <path d="M368 800a41.6 41.6 0 1 0 83.2 0 41.6 41.6 0 1 0-83.2 0Z" fill="#111111" p-id="8127"></path>
                            <path d="M624 758.4c-22.4 0-41.6 19.2-41.6 41.6s19.2 41.6 41.6 41.6c22.4 0 41.6-19.2 41.6-41.6s-19.2-41.6-41.6-41.6z" fill="#111111" p-id="8128"></path>
                          </svg>
                        </el-badge>
                      </li>
                    <ul>

                      <template v-if="userStore.userToken">
                        <li @click="logout">Logout</li>
                      </template>
                      <template v-else>
                        <li @click="redirectToLogin">Login</li>
                      </template>
                    </ul>
                  </ul>
              </div>
          </div>
        </div>
        <div class="logo-title">NZ EV Accessories</div>
      </div>
    </div>

    <div class="middle-frame">
      <el-row>
        <el-col :span="24">
          <div class="middle-top-frame">
            <div class="middle-content">
              <el-row style="padding: 20px;">
                <el-col class="recommend-one" :span="8">
                  <div class="recommend-one-info">
                    <div class="remommend-img1">
                      <el-row class="remommend-one-text">
                        <el-col :span="24" class="title">BYD</el-col>
                        <el-col :span="24" class="title">Atto 3</el-col>
                        <el-col :span="24" @click="shopNow('BYD', 'ATTO3')" class="shop-now">
                          <span>Shop Now</span>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </el-col>
                <el-col class="recommend-one" :span="8">
                  <div class="recommend-one-info">
                    <div class="remommend-img2">
                      <el-row class="remommend-one-text">
                        <el-col :span="24" class="title">BYD</el-col>
                        <el-col :span="24" class="title">Seal</el-col>
                        <el-col :span="24" @click="shopNow('BYD', 'Dolphin')" class="shop-now">
                          <span>Shop Now</span>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </el-col>

                <el-col class="recommend-one" :span="8">
                  <div class="recommend-one-info">
                    <div class="remommend-img3">
                      <el-row class="remommend-one-text">
                        <el-col :span="24" class="title">MG</el-col>
                        <el-col :span="24" class="title">MG4</el-col>
                        <el-col :span="24" @click="shopNow('MG', 'MG4')" class="shop-now">
                          <span>Shop Now</span>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="middle-bottom-frame">
            <div class="middle-content">
              <el-row style="padding: 20px;">
                <el-col class="recommend-one" :span="8">
                  <div class="recommend-one-info">
                    <div class="remommend-img4">
                      <el-row class="remommend-one-text">
                        <el-col :span="24" class="title">MG</el-col>
                        <el-col :span="24" class="title">ZS EV</el-col>
                        <el-col :span="24" @click="shopNow('MG', 'MGZSEV')" class="shop-now">
                          <span>Shop Now</span>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </el-col>
                <el-col class="recommend-one" :span="8">
                  <div class="recommend-one-info">
                    <div class="remommend-img5">
                      <el-row class="remommend-one-text">
                        <el-col :span="24" class="title">BYD</el-col>
                        <el-col :span="24" class="title">Dolphin</el-col>
                        <el-col :span="24" @click="shopNow('BYD', 'Dolphin')" class="shop-now">
                          <span>Shop Now</span>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </el-col>
                <el-col class="recommend-one" :span="8">
                  <div class="recommend-one-info">
                    <div class="remommend-img6">
                      <el-row class="remommend-one-text">
                        <el-col :span="24" class="title">Tesla</el-col>
                        <el-col :span="24" class="title">Model 3/Y</el-col>
                        <el-col :span="24" @click="shopNow('TESLA', 'MODEL Y')" class="shop-now">
                          <span>Shop Now</span>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>

    <div class="bottom-frame">
      <div class="bottom">
        <div class="box">
          <div class="bottom-one">
            <p class="one-style">EV Models</p>
            <p @click="shopNow('BYD', 'ATTO3')">BYD Atto3</p>
            <p @click="shopNow('BYD', 'Seal')">BYD Seal</p>
            <p @click="shopNow('MG', 'MG4')">MG4</p>
            <P @click="shopNow('MG', 'MGZSEV')">MG ZS EV</P>
            <P @click="shopNow('KIA', 'KIA')">Kia EV6</P>
            <p @click="shopNow('TESLA', 'MODEL Y')">Tesla ModelY / Model3</p>
          </div>
          <div class="bottom-two">
            <P class="two-style">EV Charging</P>
            <P>Charging Cables</P>
            <p>Charging Accessories</p>
          </div>
          <div class="bottom-three">
            <p class="three-style">Info & Help</p>
            <p>Shipping</p>
            <p>Click & Collect</p>
            <p>Returns & Refunds</p>
            <p>Privacy Policy</p>
            <p>Terns & Conditions</p>
            <p>Contact Us</p>
          </div>
          <div class="bottom-four">
            <div class="font-top">
              <h3>Free shipping for order</h3>
              <h3>over $99 new Zealand wide <h1>      🚚</h1></h3>

            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

</template>

<script setup name="Index">
import { listProducts, getProducts, delProducts, addProducts, updateProducts } from "@/api/products";
import { getCountByUserId} from "@/api/cart";
import { ref,reactive, toRefs, getCurrentInstance, watch } from 'vue';
const { proxy } = getCurrentInstance();
import { useUserStore } from '@/stores'
import request from "@/utils/request";
import { useRouter } from 'vue-router'
const router = useRouter()
import { ElMessage } from 'element-plus'
const userStore = useUserStore()

const productsList = ref([]);
const logout = () => {
  userStore.removeToken()
  ElMessage.success('Logout successful!')
  }
const redirectToLogin = () => {
  router.push('/login')
}
const cartCount = ref(0)
const data = reactive({
  queryParams: {
      pageNum: 1,
      pageSize: 10,
      carCompatibility: null,
      category: null,
      stockQuantity: null,
      price: null,
      productDescription: null,
      productName: null
    },
  });
const { queryParams} = toRefs(data);


function getList() {
  listProducts(queryParams.value).then(response => {
    productsList.value = response.rows;
    console.log("productsList", productsList.value)
  });
}

function shopNow(brandName, category) {
  router.push({path: '/product/list', query: {brandName: brandName, category: category}})
}

function getCartCount() {
  console.log("userId", userStore.user.userId)
  let params = {
    userId: userStore.user.userId
  }
  getCountByUserId(params).then(response => {
    cartCount.value = response.data
  });
}
function cart() {
  router.push({path: '/product/cart'})
}

// getList()
function toContactUs() {
    router.push({path: '/contactUs'})
}
function toEVService() {
  router.push({path: '/ev-service'})
}
getCartCount()
</script>

<style>
.wrap {
  width: 100%;

  background-color: #f5f5f5;
}
.frame {
  height: 680px;
  overflow: hidden;
  background-image: url('../assets/p1.jpg');
  background-size: cover;
  margin: 0 auto;
}
.frame .overlap-group {
  height: 100%;
  width: 100%;
}
.car-header {
  width: 100%;
  height: 120px;
  margin-bottom: 80px;
  background-color: #00000025;
}
.car-header-content {
  width: 1200px;
  height: 100%;
  margin: 0 auto;
  display: flex;
  line-height: 120px;
}
@import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');

.car-header-logo {
  font-family: 'Pacifico', cursive;
  font-size: 42px;
  font-weight: 700;
  text-align: left;
  color: #1f8624;
  width: 250px;
  height: 100%;
  transition: all 0.3s ease;
  position: relative;
  left: -20px;
}

.car-header-logo::before {
  content: '🌿';
  position: absolute;
  left: -40px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 30px;
  color: #148017;
}

.car-header-logo::after {
  content: '🔋';
  position: absolute;
  right: -40px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 32px;
  color: #08850b;
}

.car-header-logo:hover {
  transform: scale(1.1);
}

.car-header-nav {
  width: 1100px;
  height: 100%;
  text-align: right;
}
.car-header-nav ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  justify-content: end;
}
.car-header-nav li {
  margin-left: 50px;
  font-size: 20px;
  font-weight: 600;
  color: #fff;
}
.nav-one {
  line-height: 120px;
  height: 100px;
  font-size: 20px;
  color: #fff;
}
.nav-one div {
  font-size: 20px;
}

.car-header-nav li:hover {
  cursor: pointer;
}
.shopping-cart {
    line-height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.frame .logo-title {
  color: #ffffff;
  font-family: "Baskerville", "Garamond", serif;
  font-size: 60px;
  font-weight: 800;
  letter-spacing: 0;
  line-height: normal;
  width: 100%;
  margin: 0 0 0 10%;
  text-align: left;
}



.middle-frame {
  background-color: #fff;
  margin: 0 auto;
}
.middle-frame .middle-top-frame {
  background-color: #fff;
  padding-bottom: 40px;
}
.middle-content {
  width: 1210px;
  margin: 80px auto 0 auto;
}
.recommend-one {
  padding: 10px;
}
.recommend-one-info {
  width: 100%;
}
.recommend-one-info .remommend-img1{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p3.jpg');
  background-size: cover;
  background-position: center;
}.recommend-one-info .remommend-img2{
   width: 370px;
   height: 250px;
   background-image: url('../assets/p4.jpg');
   background-size: cover;
   background-position: center;
 }
.recommend-one-info .remommend-img3{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p5.jpg');
  background-size: cover;
  background-position: center;
}
.recommend-one-info .remommend-img4{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p6.jpg');
  background-size: cover;
  background-position: center;
}
.recommend-one-info .remommend-img5{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p7.jpg');
  background-size: cover;
  background-position: center;
}
.recommend-one-info .remommend-img6{
  width: 370px;
  height: 250px;
  background-image: url('../assets/p8.jpg');
  background-size: cover;
  background-position: center;
}


.recommend-one-info .remommend-img1 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img2 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img3 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img4 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img5 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img6 .remommend-one-text {
  padding: 20px;
  font-family: "Inika-Regular", Helvetica;
  color: #fff;
  padding-top: 60px;
}
.recommend-one-info .remommend-img1 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img2 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img3 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img4 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img5 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.recommend-one-info .remommend-img6 .remommend-one-text .title {
  font-size: 34px;
  font-weight: 600;
  margin: 5px;
}
.shop-now {
  padding-top: 30px;
  padding-left: 180px;
}
.shop-now:hover {
  transform: scale(102%);
  cursor: pointer;
}
.shop-now span {
  font-size: 18px;
  font-weight: 600;
  color: #000;
  padding: 5px 10px;
  background-color: #fff;
}

.middle-frame .middle-bottom-frame {
  height: 400px;
  background-color: #f5f5f5;
  padding-top: 10px;
}
.middle-bottom-frame .middle-content {
  margin-top: 30px;
}
.bottom-frame {
  background-color: #fff;
}

.bottom {
  padding-top: 40px;
  width: 1200px;
  height: 320px;
  margin: 0 auto;
  background-color: #fff;
  font-family: "Inter-Black", Helvetica;
}

.box {
  width: 96%;
  margin: 0 auto;
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.bottom-one{
  width: 200px;
  height: 360px;
  font-size: 14px;
  font-weight: bold;
  color: gray;
}
.bottom-two{
  width: 200px;
  height: 360px;
  font-size: 14px;
  font-weight: bold;
  color: gray;
}
.bottom-three{
  width: 200px;
  height: 360px;
  font-size: 14px;
  font-weight: bold;
  color: gray;
}
.bottom-four {
  width: 200px;
  height: 360px;
  font-size: 14px;
  font-weight: bold;
  color: gray;

}

.font-top {
  width: 100%;
  text-align: center;
  position: relative;
  top: 30px;
}


.one-style,
.two-style,
.three-style {
  font-size: 18px;
  color: gray;
}




.no-underline {
  color: white;
  text-decoration: none;
}
</style>
