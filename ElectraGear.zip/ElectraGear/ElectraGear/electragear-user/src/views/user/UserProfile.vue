<script setup>
import { ref,reactive, toRefs, getCurrentInstance } from 'vue'
import { Delete } from '@element-plus/icons-vue'
import { listUser, getUser, delUser, addUser, updateUser  } from '@/api/user'
const { proxy } = getCurrentInstance();
import { useUserStore } from '@/stores'
const userStore = useUserStore()
const user = userStore.user
const formRef = ref()

const data = reactive({
  form: {},
  rules: {
        username: [
      { required: true, message: "用户名不能为空", trigger: "blur" }
    ],    password: [
      { required: true, message: "密码不能为空", trigger: "blur" }
    ],    nickname: [
      { required: true, message: "密码不能为空", trigger: "blur" }
    ],    mobile: [
      { required: true, message: "手机号不能为空", trigger: "blur" }
    ],  }
});

const { form, rules } = toRefs(data);

// 表单重置
function reset() {
  form.value = {
    id: null,    
    username: null,    
    password: null,    
    nickname: null,    
    mobile: null,    
    services: null,    
    evaluation: null
  };
  resetForm("userRef");
}

// 表单重置
function resetForm(refName) {
  if (proxy.$refs[refName]) {
    proxy.$refs[refName].resetFields();
  }
}
/** 提交按钮 */
function submitForm() {
  proxy.$refs["userRef"].validate(valid => {
    if (valid) {
      updateUser(form.value).then(response => {
        ElMessage.success("修改成功");
      });
    }
  });
}
reset()
form.value = user
</script>
<template>
  <page-container title="基本资料">
    <!-- 表单部分 -->
    <el-form ref="userRef" :model="form" :rules="rules" label-width="100px">
      <el-form-item label="登录账号">
        <el-input v-model="form.username" prop="username" disabled></el-input>
      </el-form-item>
      <el-form-item label="用户昵称" prop="nickname">
        <el-input v-model="form.nickname"></el-input>
      </el-form-item>
      <el-form-item label="手机号" prop="mobile">
        <el-input v-model="form.mobile"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm">提交修改</el-button>
      </el-form-item>
    </el-form>
  </page-container>
</template>
