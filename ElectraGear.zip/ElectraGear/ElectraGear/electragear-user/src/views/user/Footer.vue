<template>
  <div class="bottom-frame">
    <div class="bottom">
      <div class="box">
        <div class="bottom-one">
          <p class="one-style">EV Models</p>
          <p @click="shopNow('BYD', 'ATTO3')">BYD Atto3</p>
          <p @click="shopNow('BYD', 'Seal')">BYD Seal</p>
          <p @click="shopNow('MG', 'MG4')">MG4</p>
          <p @click="shopNow('MG', 'MGZSEV')">MG ZS EV</p>
          <p @click="shopNow('KIA', 'KIA')">Kia EV6</p>
          <p @click="shopNow('TESLA', 'MODEL Y')">Tesla ModelY / Model3</p>
        </div>
        <div class="bottom-two">
          <p class="two-style">EV Charging</p>
          <p>Charging Cables</p>
          <p>Charging Accessories</p>
        </div>
        <div class="bottom-three">
          <p class="three-style">Info & Help</p>
          <p>Shipping</p>
          <p>Click & Collect</p>
          <p>Returns & Refunds</p>
          <p>Privacy Policy</p>
          <p>Terms & Conditions</p>
          <p @click="toContactUs">Contact Us</p>
        </div>
        <div class="bottom-four">
          <div class="font-top">
            <h3>Free shipping for orders</h3>
            <h3>over $99 New Zealand wide <span>🚚</span></h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Footer',
  methods: {
    shopNow(brandName, category) {
      this.$router.push({ path: '/product/list', query: { brandName, category } });
    },
    toContactUs() {
      this.$router.push({ path: '/contactUs' });
    }
  }
}
</script>

<style scoped>
/* Add your footer styles here */
.bottom-frame {
  background-color: #fff;
  margin: 0 auto;
  width: 100%;
}
.bottom {
  padding-top: 40px;
  width: 1200px;
  height: 320px;
  margin: 0 auto;
  background-color: #fff;
  font-family: "Inter-Black", Helvetica;
}
.box {
  width: 96%;
  margin: 0 auto;
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.bottom-one, .bottom-two, .bottom-three, .bottom-four {
  width: 200px;
  height: 360px;
  font-size: 14px;
  font-weight: bold;
  color: gray;
}

</style>
