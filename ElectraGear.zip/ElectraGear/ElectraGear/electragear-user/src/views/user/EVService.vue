<template>
  <div class="wrap">
    <Heads />

    <div class="content">
      <div class="service-content">
        <h1>EV Service</h1>
        <p>Welcome to the EV Service. Here you can find information about our services, maintenance tips, and make appointment</p>

        <div class="service-details">
          <h2>Maintenance Tips</h2>
          <ul>
            <li>Regularly check your tire pressure.</li>
            <li>Keep your battery charged.</li>
            <li>Schedule regular check-ups with our service team.</li>
          </ul>

          <h2>Our Services</h2>
          <p>We offer a wide range of services for your electric vehicle, including:</p>
          <ul>
            <li>Battery replacement</li>
            <li>Charging station installation</li>
            <li>Software updates</li>
            <li>General maintenance and repairs</li>
          </ul>
        </div>
      </div>

      <div class="ev-service">
        <div v-if="successMessage" class="success-message">
          Your reservation is successful, we will contact you shortly.
        </div>
        <form @submit.prevent="handleSubmit">
          <div>
            <label>Name *</label>
            <input v-model="form.name" type="text" required />
          </div>
          <div>
            <label>Email Address *</label>
            <input v-model="form.email" type="email" required />
          </div>
          <div>
            <label>Phone Number *</label>
            <input v-model="form.phone" type="tel" required />
          </div>
          <div>
            <label>Vehicle Registration *</label>
            <input v-model="form.vehicleRegistration" type="text" required />
          </div>
          <div>
            <label>Vehicle Make *</label>
            <input v-model="form.vehicleMake" type="text" required />
          </div>
          <div>
            <label>Vehicle Model *</label>
            <input v-model="form.vehicleModel" type="text" required />
          </div>
          <div>
            <label>Vehicle Year *</label>
            <input v-model="form.vehicleYear" type="number" required />
          </div>
          <div>
            <label>Type of Service *</label>
            <select v-model="form.serviceType" required>
              <option value="" disabled>Please select type of service</option>
              <option value="service1">Filter change </option>
              <option value="service2">Battery maintenance</option>
              <option value="service3">Battery replacement</option>
            </select>
          </div>
          <div>
            <label>Preferred Date of Service *</label>
            <input v-model="form.preferredDate" type="date" required />
          </div>
          <div>
            <label>Preferred Time of Service *</label>
            <select v-model="form.preferredTime" required>
              <option value="" disabled>Please select</option>
              <option value="morning">Morning</option>
              <option value="afternoon">Afternoon</option>
            </select>
          </div>
          <div>
            <label>Your Message</label>
            <textarea v-model="form.message"></textarea>
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>



    <div class="box">
      <div class="list">
        <img :src="s1" alt="">
        <div class="tips">
          <h3>General Maintenance</h3>
          <p>EV Filter Change</p>
        </div>
      </div>
      <div class="list">
        <img :src="s2" alt="">
        <div class="tips">
          <h3>Battery Maintenance</h3>
          <p>A routine inspection at least once a year is recommended to maintain optimum performance.</p>

        </div>
      </div>
      <div class="list">
        <img :src="s3" alt="">
        <div class="tips">
          <h3>Battery Replacement</h3>
          <p>Electric car battery repair & replacement </p>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import { ref } from 'vue';
import Heads from '../heads.vue';
import Footer from '../user/Footer.vue';
import s1 from '@/assets/1.png';
import s2 from '@/assets/2.png';
import s3 from '@/assets/3.png';

export default {
  components: {
    Heads,
    Footer
  },
  setup() {
    const form = ref({
      name: '',
      email: '',
      phone: '',
      vehicleRegistration: '',
      vehicleMake: '',
      vehicleModel: '',
      vehicleYear: '',
      serviceType: '',
      pitStopLocation: '',
      preferredDate: '',
      preferredTime: '',
      wofExpiryDate: '',
      message: ''
    });

    const successMessage = ref(false);

    const handleSubmit = () => {
      console.log('Form submitted:', form.value);
      successMessage.value = true;
    };

    return {
      form,
      successMessage,
      handleSubmit,
      s1,
      s2,
      s3
    };
  }
};
</script>

<style scoped>
.content {
  display: flex;
  padding: 30px;
}

.service-content {
  padding: 20px;
}

.service-content h1 {
  font-size: 36px;
  margin-bottom: 20px;
}

.service-content p {
  font-size: 18px;
  line-height: 1.6;
  margin-bottom: 20px;
}

.service-details h2 {
  font-size: 24px;
  margin-top: 20px;
}

.service-details ul {
  list-style-type: disc;
  padding-left: 20px;
}

.service-details li {
  margin-bottom: 10px;
}

.ev-service {
  flex: 1;
  max-width: 700px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

form div {
  margin-bottom: 15px;
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
}

input,
select,
textarea {
  width: 93%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #39e17a;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #070a07;
}

.success-message {
  padding: 10px;
  background-color: #4caf50;
  color: white;
  border-radius: 4px;
  margin-bottom: 20px;
}

.ev-services {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 40px 0;
}

.ev-services .flex {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.ev-services .flex .flex-col {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.ev-services .flex .flex-col div {
  display: flex;
  justify-content: center;
  align-items: center;
}
.box {
  width: 90%;
  margin: 0 auto;
  display: flex;
  justify-content: space-around;
  margin-top: 50px;
}

.list {
  width: 30%;
  height: 336px;
  overflow: hidden;
  position: relative;
  cursor: pointer;
}

.list img {
  width: 100%;
  height: 100%;
  transition: all .3s ease-in-out;

}

.list img:hover {
  transform: scale(1.1);
}

.tips {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 10;
  background: rgba(26, 26, 26, .7);
  padding: 10px 20px;
}

.tips h3 {
  font-size: 22px;
  font-weight: 700;
  margin: 0 0 5px 0;
  color: #fff;
}

.tips p {
  color: #fff;
  font-weight: 400;
  font-size: 16px;
}
</style>
