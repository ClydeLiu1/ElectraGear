import { userGetInfoService } from '@/api/user'
import { defineStore } from 'pinia'
import { ref } from 'vue'

// token setToken removeToken
export const useUserStore = defineStore(
  'ecar-user',
  () => {
    const userToken = ref('')
    const setToken = (newToken) => {
      userToken.value = newToken
    }
    const removeToken = () => {
      userToken.value = ''
      user.value = {}
    }
    const user = ref({})
    const getUser = async () => {
      const res = await userGetInfoService()
      user.value = res.data.data
    }
    const setUser = (obj) => {
      user.value = obj
    }

    return {
      userToken,
      setToken,
      removeToken,
      user,
      getUser,
      setUser
    }
  },
  {
    persist: true
  }
)
