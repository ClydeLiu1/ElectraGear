import request from '@/utils/request'

// login port
export function userLoginService({ username, password }) {
  return request({
    url: '/admins/login',
    method: 'post',
    params: {
      username,
      password
    }
  })
}

//Query the administrator information management list
export function listAdmins(query) {
  return request({
    url: '/ty/admins/list',
    method: 'get',
    params: query
  })
}
//Query administrator information management details
export function getAdmins(adminId) {
  return request({
    url: '/ty/admins/' + adminId,
    method: 'get'
  })
}

// Add administrator information management
export function addAdmins(data) {
  return request({
    url: '/ty/admins',
    method: 'post',
    data: data
  })
}

// fix administrator information management
export function updateAdmins(data) {
  return request({
    url: '/ty/admins',
    method: 'put',
    data: data
  })
}

// delete administrator information management
export function delAdmins(adminId) {
  return request({
    url: '/ty/admins/' + adminId,
    method: 'delete'
  })
}

// export administrator information management
export function exportAdmins(query) {
  return request({
    url: '/ty/admins/export',
    method: 'get',
    params: query
  })
}