import request from '@/utils/request'

// Query the shopping cart management list
export function listCart(query) {
  return request({
    url: '/ty/cart/list',
    method: 'get',
    params: query
  })
}

// Get the number of items in the specified customer's shopping cart
export function getCountByUserId(query) {
  return request({
    url: '/ty/cart/getCountByUserId',
    method: 'get',
    params: query
  })
}

// Query the shopping cart management detail
export function getCart(cartId) {
  return request({
    url: '/ty/cart/' + cartId,
    method: 'get'
  })
}
// Add shopping cart management
export function addCart(data) {
  return request({
    url: '/ty/cart',
    method: 'post',
    data: data
  })
}

// fix shopping cart management
export function updateCart(data) {
  return request({
    url: '/ty/cart',
    method: 'put',
    data: data
  })
}

// delete shopping cart management
export function delCart(cartId) {
  return request({
    url: '/ty/cart/' + cartId,
    method: 'delete'
  })
}

// export shopping cart management
export function exportCart(query) {
  return request({
    url: '/ty/cart/export',
    method: 'get',
    params: query
  })
}
