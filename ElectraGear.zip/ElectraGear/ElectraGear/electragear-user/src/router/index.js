import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', component: () => import('@/views/index.vue') },
    { path: '/login', component: () => import('@/views/login/LoginPage.vue') },
    { path: '/product/list', component: () => import('@/views/product/list.vue') },
    { path: '/product/detail', component: () => import('@/views/product/detail.vue') },
    { path: '/product/cart', component: () => import('@/views/product/cart.vue') },
    { path: '/product/checkout', component: () => import('@/views/product/checkout.vue') },
    { path: '/contactUs', component: () => import('@/views/contact-us.vue') },
    { path: '/ev-service', component: () => import('@/views/user/EVService.vue') }

    // { path: '/product/checkout', component: () => import('@/views/product/checkout.vue') },
    // {
    //   path: '/',
    //   component: () => import('@/views/layout/LayoutContainer.vue'),
    //   redirect: '/cardetails/carshow',
    //   children: [
    //     {
    //       path: '',
    //       component: () => import('@/views/index.vue')
    //     },
    //     {
    //       path: '/user/password',
    //       component: () => import('@/views/user/UserPassword.vue')
    //     },
    //     {
    //       path: '/user/evaluate',
    //       component: () => import('@/views/user/UserEvaluate.vue')
    //     },
    //   ]
    // }
  ]
})
const whiteList = ['/login', '/', '/regist', '/product/list', '/product/detail', '/product/checkout']
// Login access interception
router.beforeEach((to, from, next) => {
  // If there is no token and the page being visited is not a login page, intercept the login request. Otherwise, allow the request to proceed normally.
  const userStore = useUserStore()
  if (userStore.userToken) {
    if (to.path === '/login') {
      next({ path: '/' })
      // NProgress.done()
    } else {
      next()
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
// In the login-free whitelist, enter directly
      next()
    } else {
      next(`/login?redirect=${to.path}`) // otherwise bring to login page
      
      // NProgress.done()
    }
  }
  // if (!userStore.token && (to.path !== '/login' || to.path !== '/')) return 'login'
})
export default router
